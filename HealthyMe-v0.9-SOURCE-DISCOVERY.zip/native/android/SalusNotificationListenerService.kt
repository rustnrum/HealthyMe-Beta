package com.rustnrum.healthyme.beta03

import android.service.notification.NotificationListenerService

class SalusNotificationListenerService : NotificationListenerService()
