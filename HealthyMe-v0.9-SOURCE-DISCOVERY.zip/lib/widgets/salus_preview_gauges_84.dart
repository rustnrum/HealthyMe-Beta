import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'salus_preview_theme_84.dart';

/// Presentation-only vector gauge. No measurement values are generated.
/// A complete accent arc illustrates the intended visual treatment; the
/// centre explicitly says that the measurement is not connected.
class SalusPreviewGauge extends StatelessWidget {
  final double diameter;
  final Color accent;
  final String label;

  const SalusPreviewGauge({
    super.key,
    this.diameter = 150,
    this.accent = SalusColor.green,
    this.label = 'Awaiting data',
  });

  @override
  Widget build(BuildContext context) => SizedBox.square(
        dimension: diameter,
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              painter: _PreviewRingPainter(accent: accent),
              child: const SizedBox.expand(),
            ),
            Padding(
              padding: const EdgeInsets.all(23),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('—', style: salusText(
                    diameter * 0.30,
                    weight: FontWeight.w800,
                  )),
                  Text(label,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      style: salusText(
                        diameter < 100 ? 8 : 10,
                        color: SalusColor.muted,
                      )),
                ],
              ),
            ),
          ],
        ),
      );
}

class _PreviewRingPainter extends CustomPainter {
  final Color accent;
  const _PreviewRingPainter({required this.accent});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final stroke = math.max(8.0, size.width * .10);
    final radius = (math.min(size.width, size.height) - stroke) / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);

    canvas.drawCircle(center, radius,
        Paint()
          ..color = SalusColor.border.withValues(alpha: .7)
          ..style = PaintingStyle.stroke
          ..strokeWidth = stroke);

    final gradient = SweepGradient(
      startAngle: -math.pi / 2,
      endAngle: math.pi * 1.5,
      colors: [accent.withValues(alpha: .66), accent, SalusColor.cyan, accent],
    );
    canvas.drawArc(rect, -math.pi / 2, 2 * math.pi, false,
        Paint()
          ..shader = gradient.createShader(rect)
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = stroke * .89);
  }

  @override
  bool shouldRepaint(covariant _PreviewRingPainter oldDelegate) =>
      oldDelegate.accent != accent;
}

/// Scalable line treatment for an explicitly empty time-series state.
/// No fabricated sample points or implied time-series are drawn.
class SalusEmptyTimeline extends StatelessWidget {
  final double height;
  const SalusEmptyTimeline({super.key, this.height = 128});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: height,
        width: double.infinity,
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              painter: const _EmptyGridPainter(),
              child: const SizedBox.expand(),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              decoration: BoxDecoration(
                color: SalusColor.cardDeep.withValues(alpha: .94),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: SalusColor.border),
              ),
              child: Text('Timeline appears when measurements are available',
                  textAlign: TextAlign.center,
                  style: salusText(11, color: SalusColor.muted)),
            ),
          ],
        ),
      );
}

class _EmptyGridPainter extends CustomPainter {
  const _EmptyGridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = SalusColor.border.withValues(alpha: .46)
      ..strokeWidth = 1;
    for (var i = 1; i <= 4; i++) {
      final y = size.height * i / 5;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
    }
    for (var i = 1; i <= 5; i++) {
      final x = size.width * i / 6;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), linePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _EmptyGridPainter oldDelegate) => false;
}
