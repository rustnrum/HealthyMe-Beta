import 'package:flutter/material.dart';

abstract final class SalusColor {
  static const background = Color(0xFF050C15);
  static const card = Color(0xFF101D2C);
  static const cardDeep = Color(0xFF0A1420);
  static const border = Color(0xFF2A4558);
  static const white = Color(0xFFF2F8FF);
  static const muted = Color(0xFFA4BECE);
  static const cyan = Color(0xFF39DFF2);
  static const blue = Color(0xFF4299FF);
  static const green = Color(0xFF19E1AC);
  static const purple = Color(0xFFBD78F2);
  static const rose = Color(0xFFFF668E);
  static const amber = Color(0xFFFFBD52);
}

TextStyle salusText(double size, {
  FontWeight weight = FontWeight.w400,
  Color color = SalusColor.white,
  double? letterSpacing,
  double? height,
}) => TextStyle(
  fontSize: size,
  fontWeight: weight,
  color: color,
  letterSpacing: letterSpacing,
  height: height,
);
