import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme/app_theme.dart';
import '../services/source_name_service.dart';
import '../state/app_state.dart';
import '../state/health_sync_provider.dart';

const bool _showHealthConnectDiagnostics = bool.fromEnvironment(
  'SALUS_SHOW_DEVICE_DEBUG',
  defaultValue: true,
);

class HealthConnectScreen extends ConsumerWidget {
  const HealthConnectScreen({super.key});

  static const _metrics = <String>[
    'Steps',
    'Sleep',
    'Heart rate',
    'Resting heart rate',
    'HRV',
    'SpO2',
    'Respiratory rate',
    'Weight',
    'Body fat',
    'Body water',
    'Lean body mass',
    'Workouts',
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final app = ref.watch(appStateProvider);
    final sync = ref.watch(healthSyncProvider);
    final health = app.health;

    final providerIds = <String>{
      ...health.detectedSources.where((id) => !id.startsWith('ble:')),
      for (final entry in health.availableSources.entries)
        for (final source in entry.value)
          if (!source.startsWith('ble:')) source,
    }.toList()
      ..sort((a, b) => _label(health.sourceLabels, a)
          .compareTo(_label(health.sourceLabels, b)));

    return Scaffold(
      appBar: AppBar(title: const Text('Health Connect')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 34),
        children: [
          _GlassCard(
            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppTheme.blue.withValues(alpha: 0.10),
                  ),
                  child: const Icon(
                    Icons.health_and_safety_outlined,
                    color: AppTheme.blue,
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        health.authorized ? 'Connected' : 'Not connected',
                        style: TextStyle(
                          color: health.authorized
                              ? AppTheme.mint
                              : AppTheme.textPrimary,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 3),
                      const Text(
                        'Choose one provider for each metric. Salus never blends providers for a metric.',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12.7,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: sync.isLoading
                  ? null
                  : () async {
                      if (health.authorized) {
                        await ref.read(healthSyncProvider.notifier).sync();
                      } else {
                        await ref
                            .read(healthSyncProvider.notifier)
                            .connectAndSync();
                      }
                    },
              icon: sync.isLoading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(
                      health.authorized
                          ? Icons.sync_rounded
                          : Icons.link_rounded,
                    ),
              label: Text(
                sync.isLoading
                    ? 'Working…'
                    : health.authorized
                        ? 'Sync Health Connect'
                        : 'Connect Health Connect',
              ),
            ),
          ),
          const SizedBox(height: 22),
          const _SectionTitle(
            title: 'Data providers',
            subtitle: 'Apps currently supplying readable health data.',
          ),
          const SizedBox(height: 10),
          if (providerIds.isEmpty)
            const _GlassCard(
              child: Text(
                'No Health Connect providers have supplied readable data yet.',
                style: TextStyle(color: AppTheme.textSecondary),
              ),
            )
          else
            for (final provider in providerIds) ...[
              _ProviderCard(
                name: _label(health.sourceLabels, provider),
                metrics: _metrics
                    .where(
                      (metric) => (health.availableSources[metric] ?? const [])
                          .contains(provider),
                    )
                    .toList(),
              ),
              const SizedBox(height: 9),
            ],
          const SizedBox(height: 18),
          const _SectionTitle(
            title: 'Metric sources',
            subtitle: 'Tap a metric to choose exactly where Salus reads it from.',
          ),
          const SizedBox(height: 10),
          _GlassCard(
            child: Column(
              children: [
                for (var i = 0; i < _metrics.length; i++) ...[
                  _MetricSourceRow(
                    metric: _metrics[i],
                    selected: app.metricSources[_metrics[i]],
                    resolved: health.resolvedSources[_metrics[i]],
                    labels: health.sourceLabels,
                    onChoose: () => _chooseSource(
                      context,
                      ref,
                      metric: _metrics[i],
                      current: app.metricSources[_metrics[i]],
                      available:
                          (health.availableSources[_metrics[i]] ?? const [])
                              .where((source) => !source.startsWith('ble:'))
                              .toList(),
                      labels: health.sourceLabels,
                    ),
                  ),
                  if (i != _metrics.length - 1)
                    Divider(
                      height: 1,
                      color: AppTheme.border.withValues(alpha: 0.65),
                    ),
                ],
              ],
            ),
          ),
          if (_showHealthConnectDiagnostics) ...[
            const SizedBox(height: 24),
            Center(
              child: TextButton.icon(
                onPressed: () =>
                    Navigator.of(context).pushNamed('/sources-debug'),
                icon: const Icon(Icons.bug_report_outlined, size: 17),
                label: const Text('Diagnostics'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  static Future<void> _chooseSource(
    BuildContext context,
    WidgetRef ref, {
    required String metric,
    required String? current,
    required List<String> available,
    required Map<String, String> labels,
  }) async {
    if (available.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No Health Connect source is available for $metric yet.')),
      );
      return;
    }

    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppTheme.surfaceHigh,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                metric,
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 5),
              const Text(
                'Use one provider for this metric.',
                style: TextStyle(color: AppTheme.textSecondary),
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.auto_awesome_rounded),
                title: const Text('Automatic'),
                subtitle: const Text('Salus chooses one provider, never a blend.'),
                trailing: current == null
                    ? const Icon(Icons.check_rounded, color: AppTheme.mint)
                    : null,
                onTap: () => Navigator.pop(context, 'Auto'),
              ),
              for (final source in available)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.health_and_safety_outlined),
                  title: Text(_label(labels, source)),
                  trailing: current == source
                      ? const Icon(Icons.check_rounded, color: AppTheme.mint)
                      : null,
                  onTap: () => Navigator.pop(context, source),
                ),
            ],
          ),
        ),
      ),
    );

    if (selected == null) return;
    ref.read(appStateProvider.notifier).setMetricSource(metric, selected);
    await ref.read(healthSyncProvider.notifier).sync();
  }

  static String _label(Map<String, String> labels, String id) =>
      labels[id] ?? SourceNameService.friendly(id);
}

class _MetricSourceRow extends StatelessWidget {
  final String metric;
  final String? selected;
  final String? resolved;
  final Map<String, String> labels;
  final VoidCallback onChoose;

  const _MetricSourceRow({
    required this.metric,
    required this.selected,
    required this.resolved,
    required this.labels,
    required this.onChoose,
  });

  @override
  Widget build(BuildContext context) {
    final source = selected ?? resolved;
    final sourceLabel = source == null
        ? 'Choose source'
        : selected == null
            ? 'Automatic • ${labels[source] ?? SourceNameService.friendly(source)}'
            : labels[source] ?? SourceNameService.friendly(source);

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1),
      title: Text(
        metric,
        style: const TextStyle(
          color: AppTheme.textPrimary,
          fontWeight: FontWeight.w700,
        ),
      ),
      subtitle: Text(
        sourceLabel,
        style: const TextStyle(color: AppTheme.textSecondary),
      ),
      trailing: const Icon(
        Icons.chevron_right_rounded,
        color: AppTheme.textMuted,
      ),
      onTap: onChoose,
    );
  }
}

class _ProviderCard extends StatelessWidget {
  final String name;
  final List<String> metrics;

  const _ProviderCard({required this.name, required this.metrics});

  @override
  Widget build(BuildContext context) {
    return _GlassCard(
      child: Row(
        children: [
          const Icon(
            Icons.mobile_friendly_rounded,
            color: AppTheme.cyan,
            size: 22,
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontWeight: FontWeight.w800,
                    fontSize: 15.5,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  metrics.isEmpty ? 'Connected' : metrics.join(' • '),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          subtitle,
          style: const TextStyle(
            color: AppTheme.textSecondary,
            fontSize: 12.7,
            height: 1.35,
          ),
        ),
      ],
    );
  }
}

class _GlassCard extends StatelessWidget {
  final Widget child;

  const _GlassCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: AppTheme.surfaceHigh.withValues(alpha: 0.78),
        borderRadius: BorderRadius.circular(21),
        border: Border.all(
          color: AppTheme.border.withValues(alpha: 0.88),
        ),
      ),
      child: child,
    );
  }
}
