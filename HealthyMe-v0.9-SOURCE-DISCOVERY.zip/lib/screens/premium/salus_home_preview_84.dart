import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../widgets/salus_preview_gauges_84.dart';
import '../../widgets/salus_preview_theme_84.dart';

/// Salus milestone 1: HOME VISUALS ONLY.
/// No health-record access, manufacturer protocol, sample metrics, or scoring.
class SalusHomePage extends StatelessWidget {
  final DateTime? previewTime;
  final VoidCallback onViewLive;
  const SalusHomePage({super.key, this.previewTime, required this.onViewLive});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final compact = width < 370;
    final wide = width >= 680;
    return ColoredBox(
      color: SalusColor.background,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          _SalusHero(compact: compact, wide: wide, now: previewTime ?? DateTime.now(), onViewLive: onViewLive),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 850),
              child: Padding(
                padding: EdgeInsets.fromLTRB(wide ? 24 : 16, 8, wide ? 24 : 16, 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const _RecoveryPreview(),
                    const SizedBox(height: 14),
                    const _InsightPreview(),
                    const SizedBox(height: 20),
                    Text('TODAY AT A GLANCE',
                        style: salusText(12,
                            weight: FontWeight.w800,
                            color: SalusColor.muted,
                            letterSpacing: 1.6)),
                    const SizedBox(height: 10),
                    if (compact) ...[
                      const _PreviewMetricCard(
                        title: 'Activity',
                        subtitle: 'Steps and movement',
                        icon: Icons.directions_walk_rounded,
                        accent: SalusColor.green,
                      ),
                      const SizedBox(height: 10),
                      const _PreviewMetricCard(
                        title: 'Nutrition',
                        subtitle: 'Food and daily energy',
                        icon: Icons.restaurant_menu_rounded,
                        accent: SalusColor.amber,
                      ),
                    ] else
                      const Row(
                        children: [
                          Expanded(child: _PreviewMetricCard(
                            title: 'Activity',
                            subtitle: 'Steps and movement',
                            icon: Icons.directions_walk_rounded,
                            accent: SalusColor.green,
                          )),
                          SizedBox(width: 12),
                          Expanded(child: _PreviewMetricCard(
                            title: 'Nutrition',
                            subtitle: 'Food and daily energy',
                            icon: Icons.restaurant_menu_rounded,
                            accent: SalusColor.amber,
                          )),
                        ],
                      ),
                    const SizedBox(height: 20),
                    _SalusCard(
                      accent: SalusColor.cyan,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            const Icon(Icons.show_chart_rounded,
                                color: SalusColor.cyan, size: 20),
                            const SizedBox(width: 9),
                            Expanded(child: Text('Health trends',
                                style: salusText(16, weight: FontWeight.w800))),
                            Text('PREVIEW', style: salusText(10,
                                color: SalusColor.muted,
                                weight: FontWeight.w700)),
                          ]),
                          const SizedBox(height: 14),
                          const SalusEmptyTimeline(height: 132),
                          const SizedBox(height: 8),
                          Text('Future charts will use actual timestamps and source labels.',
                              style: salusText(11, color: SalusColor.muted)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SalusHero extends StatelessWidget {
  final bool compact;
  final bool wide;
  final DateTime now;
  final VoidCallback onViewLive;
  const _SalusHero({required this.compact, required this.wide, required this.now, required this.onViewLive});

  @override
  Widget build(BuildContext context) {
    // Outer legacy HomeShell already applies the system top safe area.
    const top = 0.0;
    final width = MediaQuery.sizeOf(context).width;
    final heroHeight = math.min(405.0, math.max(275.0, width * .73));
    final timeOfDay = now.hour < 12 ? 'Good morning' :
        now.hour < 17 ? 'Good afternoon' : 'Good evening';
    return SizedBox(
      height: heroHeight + top,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/premium/salus_home_preview_84.png',
              fit: BoxFit.cover, alignment: Alignment.center),
          const DecoratedBox(decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xD0050C15), Color(0x18050C15),
                Color(0x44050C15), SalusColor.background],
              stops: [0, .36, .7, 1],
            ),
          )),
          Positioned(
            left: wide ? 28 : 21,
            right: wide ? 28 : 21,
            top: top + 19,
            child: Row(
              children: [
                Expanded(child: Text('S A L U S',
                    maxLines: 1,
                    style: salusText(compact ? 20 : 23,
                        letterSpacing: 3,
                        weight: FontWeight.w900))),
                TextButton(
                  onPressed: onViewLive,
                  style: TextButton.styleFrom(
                    backgroundColor: const Color(0xCC071824),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(99),
                      side: const BorderSide(color: SalusColor.border)),
                  ),
                  child: Text('CURRENT HOME',
                    style: salusText(9, color: SalusColor.cyan,
                      weight: FontWeight.w800, letterSpacing: .4)),
                ),
              ],
            ),
          ),
          Positioned(
            left: wide ? 32 : 22,
            right: wide ? 32 : 22,
            bottom: 31,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('${now.month}/${now.day}/${now.year}',
                    style: salusText(12, color: SalusColor.muted)),
                const SizedBox(height: 9),
                Text(timeOfDay,
                    style: salusText(compact ? 28 : 34,
                        weight: FontWeight.w800, height: 1.1)),
                const SizedBox(height: 9),
                Text('Your health, beautifully clear.',
                    style: salusText(compact ? 13 : 15,
                        color: const Color(0xFFDAF0FF), height: 1.3)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SalusCard extends StatelessWidget {
  final Widget child;
  final Color accent;
  const _SalusCard({required this.child, this.accent = SalusColor.border});

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(23),
          border: Border.all(color: accent.withValues(alpha: .5), width: 1),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [SalusColor.card, SalusColor.cardDeep],
          ),
          boxShadow: [BoxShadow(
            color: accent.withValues(alpha: .075),
            blurRadius: 25,
          )],
        ),
        child: child,
      );
}

class _RecoveryPreview extends StatelessWidget {
  const _RecoveryPreview();
  @override
  Widget build(BuildContext context) => _SalusCard(
        accent: SalusColor.green,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.shield_outlined, color: SalusColor.green, size: 23),
            const SizedBox(width: 9),
            Expanded(child: Text('Recovery',
                style: salusText(18, weight: FontWeight.w800))),
            Text('NOT CONNECTED', style: salusText(9,
                color: SalusColor.muted, weight: FontWeight.w800)),
          ]),
          const SizedBox(height: 12),
          LayoutBuilder(builder: (context, constraints) {
            final gaugeSize = constraints.maxWidth < 300 ? 124.0 : 148.0;
            return Row(children: [
              SalusPreviewGauge(diameter: gaugeSize),
              const SizedBox(width: 10),
              Expanded(child: Column(children: const [
                _SignalPreview(Icons.bedtime_rounded, 'Sleep', SalusColor.purple),
                _SignalPreview(Icons.monitor_heart_rounded, 'HRV', SalusColor.cyan),
                _SignalPreview(Icons.favorite_rounded, 'Resting HR', SalusColor.rose),
                _SignalPreview(Icons.bolt_rounded, 'Energy', SalusColor.amber),
                _SignalPreview(Icons.fitness_center_rounded, 'Activity', SalusColor.blue),
              ])),
            ]);
          }),
          const SizedBox(height: 6),
          Text('The Recovery score will appear only when supported data is available.',
              style: salusText(11, color: SalusColor.muted, height: 1.35)),
        ]),
      );
}

class _SignalPreview extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color accent;
  const _SignalPreview(this.icon, this.label, this.accent);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5.5),
        child: Row(children: [
          Icon(icon, color: accent, size: 15),
          const SizedBox(width: 6),
          Expanded(child: Text(label,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: salusText(11, color: SalusColor.muted))),
          const SizedBox(width: 5),
          Text('—', style: salusText(13, weight: FontWeight.w800)),
        ]),
      );
}

class _InsightPreview extends StatelessWidget {
  const _InsightPreview();
  @override
  Widget build(BuildContext context) => _SalusCard(
        accent: SalusColor.purple,
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.auto_awesome_rounded,
              color: SalusColor.purple, size: 28),
          const SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Salus Insight',
                  style: salusText(16, weight: FontWeight.w800)),
              const SizedBox(height: 7),
              Text('Insights will appear here after we build and validate the health-data pipeline.',
                  style: salusText(12, color: SalusColor.muted, height: 1.45)),
            ],
          )),
        ]),
      );
}

class _PreviewMetricCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  const _PreviewMetricCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) => _SalusCard(
        accent: accent,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon, color: accent, size: 20),
              const SizedBox(width: 7),
              Expanded(child: Text(title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: salusText(13, weight: FontWeight.w800))),
            ]),
            const SizedBox(height: 13),
            Center(child: SalusPreviewGauge(
              diameter: 92,
              accent: accent,
              label: 'No records',
            )),
            const SizedBox(height: 13),
            Text(subtitle,
                maxLines: 2, overflow: TextOverflow.ellipsis,
                style: salusText(11, color: SalusColor.muted)),
          ],
        ),
      );
}
