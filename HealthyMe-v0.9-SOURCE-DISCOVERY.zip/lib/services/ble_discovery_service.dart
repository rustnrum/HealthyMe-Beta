import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';
import 'package:permission_handler/permission_handler.dart';

import 'ble_protocol_profiles.dart';

class BleDeviceCandidate {
  final String id;
  final String name;
  final int rssi;
  final List<String> advertisedServices;
  final List<String> capabilities;
  final String? protocolProfile;
  final String? protocolNote;
  final String manufacturerDataHex;

  const BleDeviceCandidate({
    required this.id,
    required this.name,
    required this.rssi,
    required this.advertisedServices,
    required this.capabilities,
    required this.protocolProfile,
    required this.protocolNote,
    required this.manufacturerDataHex,
  });

  bool get hasKnownCapabilities =>
      capabilities.isNotEmpty || protocolProfile != null;
}

class BleServiceInspection {
  final String serviceUuid;
  final List<String> characteristicDetails;

  const BleServiceInspection({
    required this.serviceUuid,
    required this.characteristicDetails,
  });
}

class BleDeviceInspection {
  final List<BleServiceInspection> services;
  final List<String> capabilities;
  final String? protocolProfile;
  final String? protocolNote;

  const BleDeviceInspection({
    required this.services,
    required this.capabilities,
    required this.protocolProfile,
    required this.protocolNote,
  });
}

class BleDiscoveryService {
  final FlutterReactiveBle _ble;

  BleDiscoveryService({FlutterReactiveBle? ble})
      : _ble = ble ?? FlutterReactiveBle();

  Future<void> _requestPermissions() async {
    if (!Platform.isAndroid) return;

    final statuses = await <Permission>[
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
    ].request();

    if (statuses[Permission.bluetoothScan] != PermissionStatus.granted ||
        statuses[Permission.bluetoothConnect] != PermissionStatus.granted) {
      throw StateError(
        'Bluetooth scan/connect permission is required to discover nearby health devices.',
      );
    }
  }

  Future<List<BleDeviceCandidate>> scan({
    Duration duration = const Duration(seconds: 8),
  }) async {
    await _requestPermissions();

    final currentStatus = _ble.status;
    if (currentStatus == BleStatus.poweredOff) {
      throw StateError('Bluetooth is turned off.');
    }
    if (currentStatus == BleStatus.unauthorized) {
      throw StateError('Bluetooth permission is not authorized.');
    }
    if (currentStatus == BleStatus.unsupported) {
      throw StateError('Bluetooth LE is not supported on this device.');
    }

    final seen = <String, DiscoveredDevice>{};
    Object? scanError;

    final subscription = _ble
        .scanForDevices(
          withServices: const [],
          scanMode: ScanMode.lowLatency,
          requireLocationServicesEnabled: false,
        )
        .listen(
          (device) => seen[device.id] = device,
          onError: (Object error) => scanError = error,
        );

    await Future<void>.delayed(duration);
    await subscription.cancel();

    if (scanError != null && seen.isEmpty) {
      throw StateError('Bluetooth scan failed: $scanError');
    }

    final devices = seen.values.map(_candidateFromDevice).toList()
      ..sort((a, b) {
        if (a.hasKnownCapabilities != b.hasKnownCapabilities) {
          return a.hasKnownCapabilities ? -1 : 1;
        }
        return b.rssi.compareTo(a.rssi);
      });

    return devices;
  }

  Future<BleDeviceInspection> inspect(BleDeviceCandidate device) async {
    await _requestPermissions();

    final connected = Completer<void>();
    late final StreamSubscription<ConnectionStateUpdate> subscription;

    subscription = _ble
        .connectToDevice(
          id: device.id,
          connectionTimeout: const Duration(seconds: 10),
        )
        .listen(
          (update) {
            if (update.connectionState == DeviceConnectionState.connected &&
                !connected.isCompleted) {
              connected.complete();
            } else if (update.connectionState ==
                    DeviceConnectionState.disconnected &&
                !connected.isCompleted) {
              connected.completeError(
                StateError('Device disconnected before GATT inspection.'),
              );
            }
          },
          onError: (Object error) {
            if (!connected.isCompleted) {
              connected.completeError(StateError('Could not connect: $error'));
            }
          },
        );

    try {
      await connected.future.timeout(const Duration(seconds: 12));
      await _ble.discoverAllServices(device.id);
      final discovered = await _ble.getDiscoveredServices(device.id);

      final serviceUuids =
          discovered.map((service) => service.serviceId.toString()).toList();
      final report = BleProtocolProfiles.analyze(serviceUuids);

      final services = discovered.map((service) {
        final chars = service.characteristics.map((characteristic) {
          final flags = <String>[
            if (characteristic.isReadable) 'read',
            if (characteristic.isNotifiable) 'notify',
            if (characteristic.isIndicatable) 'indicate',
            if (characteristic.isWritableWithResponse) 'write',
            if (characteristic.isWritableWithoutResponse) 'write-no-response',
          ];
          return '${characteristic.characteristicId} • '
              '${flags.isEmpty ? 'no exposed properties' : flags.join(', ')}';
        }).toList();

        return BleServiceInspection(
          serviceUuid: service.serviceId.toString(),
          characteristicDetails: chars,
        );
      }).toList();

      return BleDeviceInspection(
        services: services,
        capabilities: report.allCapabilities,
        protocolProfile: report.protocolProfile?.label,
        protocolNote: report.protocolProfile?.note,
      );
    } finally {
      await subscription.cancel();
    }
  }

  BleDeviceCandidate _candidateFromDevice(DiscoveredDevice device) {
    final services = device.serviceUuids.map((uuid) => uuid.toString()).toList();
    final report = BleProtocolProfiles.analyze(services);

    return BleDeviceCandidate(
      id: device.id,
      name: device.name.trim().isEmpty ? 'Unnamed BLE device' : device.name,
      rssi: device.rssi,
      advertisedServices: services,
      capabilities: report.allCapabilities,
      protocolProfile: report.protocolProfile?.label,
      protocolNote: report.protocolProfile?.note,
      manufacturerDataHex: _hex(device.manufacturerData),
    );
  }

  String _hex(Uint8List bytes) =>
      bytes.map((value) => value.toRadixString(16).padLeft(2, '0')).join();
}
