import 'dart:math' as math;

import '../models/models.dart';
import 'sleep_guidance_service.dart';

class SleepScoreReport {
  final int? score;
  final int confidence;
  final String summary;

  const SleepScoreReport({
    required this.score,
    required this.confidence,
    required this.summary,
  });
}

class SleepScoreService {
  static SleepScoreReport build(
    HealthSnapshot health,
    SleepGuidance guidance, {
    required bool stageSourceMatchesSleep,
  }) {
    if (health.sleepMinutes <= 0 || guidance.minimumMinutes <= 0) {
      return const SleepScoreReport(
        score: null,
        confidence: 0,
        summary: 'Not enough sleep data yet.',
      );
    }

    final targetMin = guidance.minimumMinutes.toDouble();
    final targetMax =
        (guidance.upperMinutes ?? guidance.minimumMinutes + 120).toDouble();
    final targetMid = (targetMin + targetMax) / 2.0;
    final sleep = health.sleepMinutes.toDouble();

    double durationScore;
    if (sleep < targetMin) {
      durationScore = (35 + 55 * (sleep / targetMin)).clamp(35, 90).toDouble();
    } else if (sleep <= targetMax) {
      final halfRange = math.max(1.0, (targetMax - targetMin) / 2.0);
      final distance = (sleep - targetMid).abs() / halfRange;
      durationScore = (100 - distance * 10).clamp(90, 100).toDouble();
    } else {
      durationScore =
          (90 - ((sleep - targetMax) / 90.0) * 18).clamp(55, 90).toDouble();
    }

    var weighted = durationScore * 50.0;
    var availableWeight = 50.0;

    final stageMinutes = health.sleepAwakeMinutes +
        health.sleepRemMinutes +
        health.sleepLightMinutes +
        health.sleepDeepMinutes;
    final hasStages = stageSourceMatchesSleep && stageMinutes > 0;

    if (hasStages) {
      final timeInBed = math.max(
        1.0,
        health.sleepMinutes.toDouble() + health.sleepAwakeMinutes.toDouble(),
      );
      final continuity = health.sleepMinutes / timeInBed;
      final continuityScore =
          (((continuity - 0.70) / 0.25) * 65 + 35).clamp(35, 100).toDouble();
      weighted += continuityScore * 25.0;
      availableWeight += 25.0;

      final restorative =
          (health.sleepRemMinutes + health.sleepDeepMinutes) /
              math.max(1.0, health.sleepMinutes.toDouble());
      final restorativeScore =
          (((restorative - 0.15) / 0.25) * 65 + 35).clamp(35, 100).toDouble();
      weighted += restorativeScore * 15.0;
      availableWeight += 15.0;
    }

    final recent = health.sleepMinutes7
        .where((minutes) => minutes > 0)
        .map((value) => value.toDouble())
        .toList();
    if (recent.length >= 4) {
      final mean = recent.reduce((a, b) => a + b) / recent.length;
      final variance = recent
              .map((value) => math.pow(value - mean, 2).toDouble())
              .reduce((a, b) => a + b) /
          recent.length;
      final deviation = math.sqrt(variance);
      final consistencyScore =
          (100 - ((deviation - 20).clamp(0, 120) / 120) * 60)
              .clamp(40, 100)
              .toDouble();
      weighted += consistencyScore * 10.0;
      availableWeight += 10.0;
    }

    final raw = weighted / availableWeight;
    final confidence = availableWeight.round().clamp(0, 100);
    final adjusted = raw * (availableWeight / 100.0) +
        65.0 * (1.0 - availableWeight / 100.0);
    final score = adjusted.round().clamp(0, 100);

    final summary = !hasStages
        ? 'Sleep duration is available; stage quality is still missing from this sleep source.'
        : score >= 85
            ? 'Sleep duration and quality signals were strong.'
            : score >= 70
                ? 'Sleep was mixed. Duration, interruptions, or restorative stages can improve.'
                : 'Sleep quality was below your usual goal.';

    return SleepScoreReport(
      score: score,
      confidence: confidence,
      summary: summary,
    );
  }
}
