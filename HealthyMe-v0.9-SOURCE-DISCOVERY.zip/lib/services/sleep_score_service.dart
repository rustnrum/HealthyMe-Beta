import 'dart:math' as math;

import '../models/models.dart';
import 'sleep_guidance_service.dart';

class SleepScoreReport {
  final int? score;
  final int confidence;
  final String summary;
  final List<String> components;

  const SleepScoreReport({
    required this.score,
    required this.confidence,
    required this.summary,
    this.components = const [],
  });
}

class SleepScoreService {
  static SleepScoreReport build(
    HealthSnapshot health,
    SleepGuidance guidance, {
    required bool stageSourceMatchesSleep,
  }) {
    if (health.sleepMinutes <= 0 || guidance.minimumMinutes <= 0) {
      return const SleepScoreReport(
        score: null,
        confidence: 0,
        summary: 'Not enough sleep data yet.',
      );
    }

    final weighted = <({double score, double weight, String label})>[];
    final minimum = guidance.minimumMinutes.toDouble();
    final maximum =
        (guidance.upperMinutes ?? guidance.minimumMinutes + 120).toDouble();
    final sleep = health.sleepMinutes.toDouble();

    double durationScore;
    if (sleep < minimum) {
      durationScore = (sleep / minimum * 100).clamp(20, 94);
    } else if (sleep <= maximum) {
      final midpoint = (minimum + maximum) / 2;
      final halfRange = math.max(1.0, (maximum - minimum) / 2);
      final distance = (sleep - midpoint).abs() / halfRange;
      durationScore = (96 - distance * 6).clamp(90, 96);
    } else {
      durationScore =
          (90 - ((sleep - maximum) / 90) * 18).clamp(55, 90);
    }
    weighted.add((score: durationScore, weight: 55, label: 'duration'));

    final stagesReported = stageSourceMatchesSleep &&
        (health.sleepLightMinutes > 0 ||
            health.sleepDeepMinutes > 0 ||
            health.sleepRemMinutes > 0);

    if (stagesReported && health.sleepAwakeMinutes > 0) {
      final timeInBed =
          health.sleepMinutes.toDouble() + health.sleepAwakeMinutes.toDouble();
      final efficiency = health.sleepMinutes / math.max(1.0, timeInBed);
      final score = (((efficiency - 0.65) / 0.30) * 70 + 30).clamp(30, 100);
      weighted.add((score: score, weight: 20, label: 'interruptions'));
    }

    // Zero can mean "not reported"; never punish a missing stage as zero sleep.
    if (stagesReported && health.sleepDeepMinutes > 0) {
      final pct = health.sleepDeepMinutes / math.max(1.0, sleep);
      final score = (100 - ((pct - 0.18).abs() / 0.18) * 45).clamp(45, 100);
      weighted.add((score: score, weight: 10, label: 'deep sleep'));
    }
    if (stagesReported && health.sleepRemMinutes > 0) {
      final pct = health.sleepRemMinutes / math.max(1.0, sleep);
      final score = (100 - ((pct - 0.22).abs() / 0.20) * 45).clamp(45, 100);
      weighted.add((score: score, weight: 10, label: 'REM sleep'));
    }

    final recent =
        health.sleepMinutes7.where((v) => v > 0).map((v) => v.toDouble()).toList();
    if (recent.length >= 4) {
      final mean = recent.reduce((a, b) => a + b) / recent.length;
      final variance = recent
              .map((v) => math.pow(v - mean, 2).toDouble())
              .reduce((a, b) => a + b) /
          recent.length;
      final deviation = math.sqrt(variance);
      final consistency = (100 - deviation / 2).clamp(40, 100);
      weighted.add((score: consistency, weight: 5, label: 'consistency'));
    }

    final totalWeight =
        weighted.fold<double>(0, (sum, item) => sum + item.weight);
    final score = (weighted.fold<double>(
              0,
              (sum, item) => sum + item.score * item.weight,
            ) /
            math.max(1.0, totalWeight))
        .round()
        .clamp(0, 100);

    final confidence = totalWeight.round().clamp(0, 100);
    final summary = confidence <= 55
        ? 'Score is based mainly on sleep duration because this source did not provide enough quality detail.'
        : score >= 85
            ? 'Sleep duration and available quality signals were strong.'
            : score >= 70
                ? 'Sleep was mixed. Duration, interruptions, or stages can improve.'
                : 'Available sleep signals were below your usual goal.';

    return SleepScoreReport(
      score: score,
      confidence: confidence,
      summary: summary,
      components: weighted.map((item) => item.label).toList(),
    );
  }
}
