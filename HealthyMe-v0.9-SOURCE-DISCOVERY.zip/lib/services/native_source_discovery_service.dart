import 'dart:io';

import 'package:flutter/services.dart';

class VisibleHealthApp {
  final String packageName;
  final String label;

  const VisibleHealthApp({
    required this.packageName,
    required this.label,
  });
}

class HealthDeviceDataType {
  final String type;
  final bool available;
  final bool enabled;

  const HealthDeviceDataType({
    required this.type,
    required this.available,
    required this.enabled,
  });
}

class HealthDeviceSource {
  final String origin;
  final String displayName;
  final String manufacturer;
  final String model;
  final List<HealthDeviceDataType> dataTypes;

  const HealthDeviceSource({
    required this.origin,
    required this.displayName,
    required this.manufacturer,
    required this.model,
    required this.dataTypes,
  });
}

class HealthDiscoveryStatus {
  final bool matchmakingSupported;
  final bool matchmakingPossible;
  final bool deviceProvidersSupported;
  final int healthExtensionVersion;
  final List<VisibleHealthApp> visibleApps;
  final String message;

  const HealthDiscoveryStatus({
    required this.matchmakingSupported,
    required this.matchmakingPossible,
    required this.deviceProvidersSupported,
    required this.healthExtensionVersion,
    required this.visibleApps,
    required this.message,
  });
}

class NativeSourceDiscoveryService {
  static const MethodChannel _channel =
      MethodChannel('com.rustnrum.healthyme/source_discovery');

  Future<HealthDiscoveryStatus> status() async {
    if (!Platform.isAndroid) {
      return const HealthDiscoveryStatus(
        matchmakingSupported: false,
        matchmakingPossible: false,
        deviceProvidersSupported: false,
        healthExtensionVersion: 0,
        visibleApps: [],
        message: 'Android source discovery is not available on this platform.',
      );
    }

    try {
      final raw =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('discoveryStatus');
      return _statusFromMap(raw ?? const {});
    } on PlatformException catch (error) {
      return HealthDiscoveryStatus(
        matchmakingSupported: false,
        matchmakingPossible: false,
        deviceProvidersSupported: false,
        healthExtensionVersion: 0,
        visibleApps: const [],
        message: error.message ?? error.code,
      );
    }
  }

  Future<bool> launchMatchmaking() async {
    final raw =
        await _channel.invokeMethod<Map<dynamic, dynamic>>('launchMatchmaking');
    return raw?['granted'] == true;
  }

  Future<List<HealthDeviceSource>> deviceDataSources() async {
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>('deviceDataSources');
      return (raw ?? const [])
          .whereType<Map<dynamic, dynamic>>()
          .map(_deviceSourceFromMap)
          .toList();
    } on PlatformException {
      return const [];
    }
  }

  HealthDiscoveryStatus _statusFromMap(Map<dynamic, dynamic> raw) {
    final apps = (raw['visibleApps'] as List<dynamic>? ?? const [])
        .whereType<Map<dynamic, dynamic>>()
        .map(
          (app) => VisibleHealthApp(
            packageName: app['packageName']?.toString() ?? '',
            label: app['label']?.toString() ?? 'Health app',
          ),
        )
        .where((app) => app.packageName.isNotEmpty)
        .toList();

    return HealthDiscoveryStatus(
      matchmakingSupported: raw['matchmakingSupported'] == true,
      matchmakingPossible: raw['matchmakingPossible'] == true,
      deviceProvidersSupported: raw['deviceProvidersSupported'] == true,
      healthExtensionVersion:
          (raw['healthExtensionVersion'] as num?)?.toInt() ?? 0,
      visibleApps: apps,
      message: raw['message']?.toString() ?? '',
    );
  }

  HealthDeviceSource _deviceSourceFromMap(Map<dynamic, dynamic> raw) {
    final types = (raw['dataTypes'] as List<dynamic>? ?? const [])
        .whereType<Map<dynamic, dynamic>>()
        .map(
          (type) => HealthDeviceDataType(
            type: type['type']?.toString() ?? 'Unknown',
            available: type['available'] == true,
            enabled: type['enabled'] == true,
          ),
        )
        .toList();

    return HealthDeviceSource(
      origin: raw['origin']?.toString() ?? '',
      displayName: raw['displayName']?.toString() ?? '',
      manufacturer: raw['manufacturer']?.toString() ?? '',
      model: raw['model']?.toString() ?? '',
      dataTypes: types,
    );
  }
}
