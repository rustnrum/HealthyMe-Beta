import 'package:flutter_test/flutter_test.dart';
import 'package:healthy_me/models/models.dart';
import 'package:healthy_me/services/sleep_guidance_service.dart';
import 'package:healthy_me/services/sleep_score_service.dart';

void main() {
  const guidance = SleepGuidance(
    minimumMinutes: 420,
    upperMinutes: 540,
    label: '7–9 hr',
    note: 'test',
  );

  test('duration-only score is not perfect and is low-confidence', () {
    const health = HealthSnapshot(sleepMinutes: 480);
    final report = SleepScoreService.build(
      health,
      guidance,
      stageSourceMatchesSleep: false,
    );
    expect(report.score, isNotNull);
    expect(report.score!, lessThan(100));
    expect(report.confidence, 55);
  });

  test('four hours of sleep is meaningfully penalized', () {
    const health = HealthSnapshot(sleepMinutes: 240);
    final report = SleepScoreService.build(
      health,
      guidance,
      stageSourceMatchesSleep: false,
    );
    expect(report.score!, lessThan(65));
  });

  test('missing REM is not treated as zero REM', () {
    const health = HealthSnapshot(
      sleepMinutes: 480,
      sleepAwakeMinutes: 25,
      sleepLightMinutes: 330,
      sleepDeepMinutes: 125,
      sleepRemMinutes: 0,
    );
    final report = SleepScoreService.build(
      health,
      guidance,
      stageSourceMatchesSleep: true,
    );
    expect(report.components, isNot(contains('REM sleep')));
  });
}
