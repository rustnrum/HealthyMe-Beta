import 'package:flutter_test/flutter_test.dart';
import 'package:healthy_me/models/models.dart';
import 'package:healthy_me/services/sleep_guidance_service.dart';
import 'package:healthy_me/services/sleep_score_service.dart';

void main() {
  const guidance = SleepGuidance(
    minimumMinutes: 420,
    upperMinutes: 540,
    label: '7–9 hr',
    note: 'test',
  );

  test('duration alone does not create a perfect sleep score', () {
    const health = HealthSnapshot(
      sleepMinutes: 480,
      sleepMinutes7: [470, 480, 490, 475, 485],
    );
    final report = SleepScoreService.build(
      health,
      guidance,
      stageSourceMatchesSleep: false,
    );
    expect(report.score, isNotNull);
    expect(report.score!, lessThan(100));
    expect(report.confidence, lessThan(100));
  });

  test('fragmented sleep scores lower than consolidated sleep', () {
    const consolidated = HealthSnapshot(
      sleepMinutes: 480,
      sleepAwakeMinutes: 20,
      sleepRemMinutes: 100,
      sleepLightMinutes: 270,
      sleepDeepMinutes: 110,
      sleepMinutes7: [470, 480, 490, 475, 485],
    );
    const fragmented = HealthSnapshot(
      sleepMinutes: 480,
      sleepAwakeMinutes: 150,
      sleepRemMinutes: 50,
      sleepLightMinutes: 390,
      sleepDeepMinutes: 40,
      sleepMinutes7: [470, 480, 490, 475, 485],
    );
    final good = SleepScoreService.build(
      consolidated,
      guidance,
      stageSourceMatchesSleep: true,
    );
    final poor = SleepScoreService.build(
      fragmented,
      guidance,
      stageSourceMatchesSleep: true,
    );
    expect(good.score, isNotNull);
    expect(poor.score, isNotNull);
    expect(poor.score!, lessThan(good.score!));
  });
}
