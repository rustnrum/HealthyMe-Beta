import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/rendering.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:healthy_me/screens/premium/salus_home_85.dart';

void main() {
  test('Build 85 uses the Home mountain candidate and unchanged original ring', () {
    expect(File('assets/premium/salus_mountain_85.webp').existsSync(), isTrue);
    expect(File('assets/preview84/img/ring_recovery.png').existsSync(), isTrue);
    final home = File('lib/screens/premium/salus_home_85.dart').readAsStringSync();
    final shell = File('lib/screens/home_shell.dart').readAsStringSync();
    expect(home, contains('assets/premium/salus_mountain_85.webp'));
    expect(home, contains('assets/preview84/img/ring_recovery.png'));
    expect(shell, contains('SalusHome85()'));
    expect(shell, contains('index == 0'));
  });

  for (final size in const [
    Size(320, 720),
    Size(360, 800),
    Size(412, 920),
    Size(650, 850),
    Size(820, 960),
    Size(1100, 980),
  ]) {
    testWidgets('Approved Home layout has no exceptions at ${size.width} x ${size.height}',
        (tester) async {
      await tester.binding.setSurfaceSize(size);
      addTearDown(() => tester.binding.setSurfaceSize(null));
      await tester.pumpWidget(
        MaterialApp(
          home: const Scaffold(body: RepaintBoundary(
            key: Key('salus-home-render-review'),
            child: SalusHome85(),
          )),
          routes: {
            '/workout': (_) => const Scaffold(body: Text('Workout module')),
          },
        ),
      );
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.text('Recovery Score'), findsOneWidget);
      expect(find.text('DESIGN PREVIEW  ·  SAMPLE DATA'), findsOneWidget);
      expect(find.byType(Image), findsWidgets);
      // Save a REAL Flutter widget-test rendering for visual inspection
      // once GitHub Actions has passed. This is not an Android screenshot;
      // test fonts and the device status bar may differ from the Fold.
      if (size.width == 320 || size.width == 412 || size.width == 820) {
        try {
          final boundary = tester.renderObject<RenderRepaintBoundary>(
            find.byKey(const Key('salus-home-render-review')),
          );
          final image = await boundary.toImage(pixelRatio: 1.0);
          try {
            final png = await image.toByteData(format: ui.ImageByteFormat.png);
            if (png != null) {
              await Directory('design_review').create(recursive: true);
              await File('design_review/home_${size.width.toInt()}x${size.height.toInt()}.png')
                  .writeAsBytes(png.buffer.asUint8List(
                    png.offsetInBytes, png.lengthInBytes,
                  ));
            }
          } finally {
            image.dispose();
          }
        } catch (error) {
          // A renderer that cannot export images must not conceal real
          // layout regressions or block the normal widget and APK tests.
          debugPrint('Optional Home review capture unavailable: $error');
        }
      }
      // Explicitly verify the available width of the actual two-column
      // Recovery card, not just the absence of a framework error.
      if (size.width == 320) {
        expect(tester.getSize(find.byKey(const Key('home-recovery-ring'))).width,
            lessThanOrEqualTo(120));
        expect(tester.getSize(find.byKey(const Key('home-recovery-metrics'))).width,
            greaterThanOrEqualTo(135));
        // At 320px the fixed icon and gap leave <260px for the CTA text.
        expect(tester.getSize(find.byKey(const Key('home-plan-button-label'))).width,
            lessThanOrEqualTo(259));
      }
      // Content should remain scrollable and no fixed-height full-screen
      // Stack should clip the main cards on shorter folded viewports.
      await tester.drag(find.byType(ListView), const Offset(0, -500));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.text("View Today's Plan"), findsOneWidget);
    });
  }
}
