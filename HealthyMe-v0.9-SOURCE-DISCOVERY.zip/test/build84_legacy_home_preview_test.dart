import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:healthy_me/screens/premium/salus_home_preview_84.dart';

void main() {
  test('New Home preview is non-destructive and keeps the old app intact', () {
    final home = File('lib/screens/premium/salus_home_77.dart').readAsStringSync();
    final shell = File('lib/screens/home_shell.dart').readAsStringSync();
    final app = File('pubspec.yaml').readAsStringSync();
    expect(home, contains('_showNewHomeDesign'));
    expect(home, contains('SalusHomePage(onViewLive:'));
    expect(home, contains("S77Section('Recovery Score'"));
    expect(shell, contains('SalusHome77()'));
    expect(app, contains('name: healthy_me'));
    expect(app, contains('version: 0.21.46+84'));
    expect(File('assets/premium/salus_home_preview_84.png').existsSync(), isTrue);
  });

  testWidgets('Compact preview renders and returns to original Home', (tester) async {
    bool switched = false;
    tester.view.physicalSize = const Size(340, 840);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(home: Scaffold(
      body: SafeArea(child: SalusHomePage(onViewLive: () => switched = true)),
    )));
    await tester.pumpAndSettle();
    expect(find.text('CURRENT HOME'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('CURRENT HOME'));
    expect(switched, isTrue);
  });

  testWidgets('Unfolded 820px preview has no obvious layout overflow', (tester) async {
    tester.view.physicalSize = const Size(820, 920);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(home: Scaffold(
      body: SafeArea(child: SalusHomePage(onViewLive: () {})),
    )));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });
}
