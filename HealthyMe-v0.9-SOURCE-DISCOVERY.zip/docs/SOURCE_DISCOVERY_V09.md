# Healthy Me Beta 0.9 — Source Discovery

This beta corrects the v0.8 source-discovery gap.

## Discovery paths

1. Health Connect record origins already supplying data.
2. Health Connect Matchmaking using AndroidX Health Connect 1.2.0-alpha06.
3. Direct Bluetooth LE scan plus GATT inspection, independent of Health Connect.

The build deliberately avoids the unreleased Android SDK 37 platform package. Google documents AndroidX Health Connect 1.2.0-alpha06 as the current integration path for Matchmaking.

The Bluetooth layer remains manufacturer-neutral in the UI/core. Standard health services map to universal metrics. Proprietary protocols stay isolated behind service fingerprints, including the `ring-uart-v1` profile.

This build discovers and inspects BLE devices. It does not yet convert proprietary ring packets into health-history readings.
