# Healthy Me Beta 0.9 — Source Discovery

This beta corrects the v0.8 source-discovery gap.

## Visible behavior

The Data Sources page identifies itself as:

**Beta 0.9.0+13 • Source Discovery**

It separates three different concepts:

1. **Health Connect records** — providers that have already supplied readable records.
2. **Android source discovery** — Health Connect matchmaking and device-provider APIs, when supported by the phone's Health Connect extension.
3. **Nearby Bluetooth health devices** — direct BLE scan and GATT inspection, independent of Health Connect records.

## Neutral architecture

The core remains metric-first. Standard Bluetooth health services are mapped to universal capabilities such as heart rate, SpO2, weight, and body composition.

Non-standard protocols are isolated behind protocol fingerprints. The first known fingerprint is named `ring-uart-v1`; the UI does not branch on a manufacturer name.

This beta detects and inspects the protocol. It does not yet write Bluetooth-derived readings into Healthy Me's health history. The next protocol-decoder step can be implemented after the real device's GATT services are verified on-device.

## Health Connect platform requirements

The Android platform matchmaking API requires U extension 21 or newer. Health Connect device-provider discovery requires U extension 22 or newer. The Sources page shows the actual extension version and whether each API is available.
