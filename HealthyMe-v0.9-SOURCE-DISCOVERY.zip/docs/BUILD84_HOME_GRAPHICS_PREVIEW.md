# Salus Build 84 graphics-only Home preview — OLD REPOSITORY

Target: `rustnrum/HealthyMe-Beta` (NOT `rustnrum/Salus`).

Upload the ZIP as `HealthyMe-v0.9-SOURCE-DISCOVERY.zip` to the root
of the legacy repository and commit. Its existing workflow unpacks the
patch and builds/signs with the existing permanent beta key.

Build 84 adds a design-only Home screen within the existing app.
- New Home graphic preview shows by default.
- Tap **CURRENT HOME** in the new graphic header to return to the original
  live-data Home in the same session.
- Tap **S A L U S** in the old Home header to return to the preview.
- Existing app modules and bottom navigation remain available.
- **No new devices or medical readings** are added; placeholder values show
  unavailable, not fabricated scores.
- No app ID changes, signing-key changes, Health Connect or BLE changes.

This is **not** the separate new `Salus` repository. It is an additive
visual experiment inside the original existing beta app. Do not uninstall
any existing application to install the resulting APK.

Tests: archived test contracts are upgraded to the new version, with new
compact/unfolded widget rendering tests. GitHub still must analyze, run tests,
compile, and sign; local Dart/Flutter tools are unavailable.
