#!/usr/bin/env bash
set -euo pipefail
python3 scripts/native_source_registry_patch.py
python3 scripts/direct_device_native_patch.py
python3 scripts/direct_metric_native_patch.py
python3 scripts/protocol_metric_native_patch.py

fail(){ echo "SOURCE CONTRACT FAILURE: $1" >&2; exit 1; }
MAIN="$(find android/app/src/main/kotlin -name MainActivity.kt -print -quit)"
test -n "$MAIN" || fail MainActivity
PKG="$(dirname "$MAIN")"
PROTO="$PKG/SalusProtocolReader.kt"
LISTENER="$PKG/SalusNotificationListenerService.kt"
test -s "$PROTO" || fail protocol
test -s "$LISTENER" || fail listener
grep -Fq '"isCpapPairingPending" ->' "$MAIN" || fail pairing-state
grep -Fq '"resetCpapPairing" ->' "$MAIN" || fail re-pair
if grep -Fq 'starting a fresh pairing exchange' "$PROTO"; then fail automatic-repair; fi
for forbidden in '"Set"' '"EnterTherapy"' '"EnterStandby"' '"EnterMaskFit"' '"EraseData"' '"ResetDevice"'; do
  if grep -Fq "$forbidden" "$PROTO"; then fail "forbidden $forbidden"; fi
done

mkdir -p native/android
cp "$MAIN" native/android/MainActivity.kt
cp "$PROTO" native/android/SalusProtocolReader.kt
cp "$LISTENER" native/android/SalusNotificationListenerService.kt
cp android/app/src/main/AndroidManifest.xml native/android/AndroidManifest.xml
if [ -f android/app/build.gradle.kts ]; then
  cp android/app/build.gradle.kts native/android/build.gradle.kts
else
  cp android/app/build.gradle native/android/build.gradle
fi
cp android/gradle.properties native/android/gradle.properties

rm -f scripts/build{26,27,28,29,30,31,32,33,34,35,36}*.py
rm -f scripts/direct_device_native_patch.py scripts/direct_device_patch.py
rm -f scripts/direct_metric_native_patch.py scripts/native_source_registry_patch.py
rm -f scripts/protocol_metric_native_patch.py scripts/salus_brand_patch.py
rm -f scripts/source_hub_patch.py scripts/source_registry_patch.py
rm -f scripts/build37_migration.py scripts/ui_contract_check.sh
rm -rf scripts/__pycache__
mv scripts/prepare_android.next.sh scripts/prepare_android.sh
rm -f scripts/source_discovery_contract.sh
echo "Build 37 cleanup complete."
