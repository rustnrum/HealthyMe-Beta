#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "SOURCE DISCOVERY CONTRACT FAILURE: $1" >&2
  exit 1
}

SOURCES="lib/screens/sources_screen.dart"
BLE="lib/services/ble_discovery_service.dart"
PROFILES="lib/services/ble_protocol_profiles.dart"
NATIVE="lib/services/native_source_discovery_service.dart"
ANDROID="scripts/prepare_android.sh"
PUBSPEC="pubspec.yaml"

for required in \
  "Beta 0.9.0+13 • Source Discovery" \
  "Find compatible sources" \
  "Nearby Bluetooth health devices" \
  "Scan nearby BLE" \
  "Protocol profile" \
  "Health Connect device providers"; do
  grep -q "$required" "$SOURCES" || fail "Sources screen missing: $required"
done

grep -q "flutter_reactive_ble: 5.6.0" "$PUBSPEC" \
  || fail "BLE dependency missing or not pinned to 5.6.0"
grep -q "scanForDevices" "$BLE" || fail "BLE scanner missing"
grep -q "discoverServices" "$BLE" || fail "GATT inspection missing"
grep -q "ring-uart-v1" "$PROFILES" || fail "protocol-profile registry missing"
grep -q "6e40fff0-b5a3-f393-e0a9-e50e24dcca9e" "$PROFILES" \
  || fail "ring protocol fingerprint missing"
grep -q "com.rustnrum.healthyme/source_discovery" "$NATIVE" \
  || fail "native source-discovery channel missing"
grep -q "isMatchmakingPossible" "$ANDROID" \
  || fail "Health Connect matchmaking check missing"
grep -q "createMatchmakingIntent" "$ANDROID" \
  || fail "Health Connect matchmaking flow missing"
grep -q "getDeviceDataSources" "$ANDROID" \
  || fail "Health Connect device-provider discovery missing"
grep -q "BLUETOOTH_SCAN" "$ANDROID" || fail "Bluetooth scan permission missing"
grep -q "compileSdk = 37" "$ANDROID" || fail "SDK 37 build configuration missing"

echo "Healthy Me v0.9 source-discovery contract passed."
