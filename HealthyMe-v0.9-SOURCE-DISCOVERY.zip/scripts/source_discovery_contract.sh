#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "SOURCE DISCOVERY CONTRACT FAILURE: $1" >&2
  exit 1
}

SOURCES="lib/screens/sources_screen.dart"
BLE="lib/services/ble_discovery_service.dart"
PROFILES="lib/services/ble_protocol_profiles.dart"
NATIVE="lib/services/native_source_discovery_service.dart"
ANDROID="scripts/prepare_android.sh"
PUBSPEC="pubspec.yaml"

for required in \
  "Beta 0.9.0+13 • Source Discovery" \
  "Find compatible sources" \
  "Nearby Bluetooth health devices" \
  "Scan nearby BLE" \
  "Protocol profile"; do
  grep -q "$required" "$SOURCES" || fail "Sources screen missing: $required"
done

grep -q "scanForDevices" "$BLE" || fail "BLE scanner missing"
grep -q "discoverServices(device.id)" "$BLE" \
  || fail "BLE 5.5 discoverServices call missing"
grep -q "ignore: deprecated_member_use" "$BLE" \
  || fail "BLE 5.5 compatibility suppression missing"
grep -q "service\.serviceId" "$BLE" \
  || fail "BLE 5.5 serviceId mapping missing"
grep -q "characteristic\.characteristicId" "$BLE" \
  || fail "BLE 5.5 characteristicId mapping missing"

grep -q "ring-uart-v1" "$PROFILES" || fail "protocol profile registry missing"
grep -q "6e40fff0-b5a3-f393-e0a9-e50e24dcca9e" "$PROFILES" \
  || fail "ring UART fingerprint missing"

grep -q "com.rustnrum.healthyme/source_discovery" "$NATIVE" \
  || fail "native source-discovery channel missing"
grep -q 'Class.forName("android.health.connect.HealthConnectManager")' "$ANDROID" \
  || fail "runtime HealthConnectManager discovery missing"
grep -q 'Class.forName("android.health.connect.MatchmakingRequest\\\$Builder")' "$ANDROID" \
  || fail "runtime MatchmakingRequest builder missing"
grep -q 'it.name == "isMatchmakingPossible"' "$ANDROID" \
  || fail "runtime matchmaking availability check missing"
grep -q 'it.name == "createMatchmakingIntent"' "$ANDROID" \
  || fail "runtime matchmaking launcher missing"
grep -q "MATCHMAKING_EXTENSION_VERSION = 21" "$ANDROID" \
  || fail "U-extension matchmaking gate missing"
grep -q "BLUETOOTH_SCAN" "$ANDROID" \
  || fail "Bluetooth scan permission missing"

grep -q "flutter_reactive_ble: 5.5.0" "$PUBSPEC" \
  || fail "flutter_reactive_ble must stay pinned to 5.5.0"
grep -q "reactive_ble_mobile: 5.5.0" "$PUBSPEC" \
  || fail "reactive_ble_mobile must stay pinned to 5.5.0"
grep -q "reactive_ble_platform_interface: 5.5.0" "$PUBSPEC" \
  || fail "reactive_ble_platform_interface must stay pinned to 5.5.0"

# The whole point of this revision: NO SDK-37 matchmaking AAR may be added.
if grep -q "androidx.health.connect:connect-client:1.2.0-alpha" "$ANDROID"; then
  fail "SDK-37 Health Connect matchmaking AAR must not be present"
fi
if grep -q "compileSdk = 37" "$ANDROID"; then
  fail "SDK 37 must not be required"
fi
if grep -q "flutter_reactive_ble: 5.6" "$PUBSPEC"; then
  fail "BLE 5.6 requires Android SDK 37"
fi
if grep -q "reactive_ble_mobile: 5.6" "$PUBSPEC"; then
  fail "reactive_ble_mobile 5.6 requires Android SDK 37"
fi

echo "Healthy Me v0.9 runtime-matchmaking source-discovery contract passed."
