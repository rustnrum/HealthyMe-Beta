#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "SOURCE DISCOVERY CONTRACT FAILURE: $1" >&2
  exit 1
}

SOURCES="lib/screens/sources_screen.dart"
BLE="lib/services/ble_discovery_service.dart"
PROFILES="lib/services/ble_protocol_profiles.dart"
NATIVE="lib/services/native_source_discovery_service.dart"
ANDROID="scripts/prepare_android.sh"
PUBSPEC="pubspec.yaml"

# Visible v0.9 UI
for required in \
  "Beta 0.9.0+13 • Source Discovery" \
  "Find compatible sources" \
  "Nearby Bluetooth health devices" \
  "Scan nearby BLE" \
  "Protocol profile"; do
  grep -q "$required" "$SOURCES" || fail "Sources screen missing: $required"
done

# BLE scanning/capability layer
grep -q "scanForDevices" "$BLE" || fail "BLE scanner missing"
grep -q "discoverServices(device.id)" "$BLE" \
  || fail "BLE 5.5 discoverServices call missing"
grep -q "service\.serviceId" "$BLE" \
  || fail "BLE 5.5 DiscoveredService.serviceId mapping missing"
grep -q "characteristic\.characteristicId" "$BLE" \
  || fail "BLE 5.5 DiscoveredCharacteristic.characteristicId mapping missing"

grep -q "ring-uart-v1" "$PROFILES" || fail "protocol profile registry missing"
grep -q "6e40fff0-b5a3-f393-e0a9-e50e24dcca9e" "$PROFILES" \
  || fail "ring UART service fingerprint missing"

# Native Health Connect matchmaking bridge
grep -q "com.rustnrum.healthyme/source_discovery" "$NATIVE" \
  || fail "native source-discovery channel missing"
grep -q "HealthConnectFeatures.FEATURE_MATCHMAKING" "$ANDROID" \
  || fail "Health Connect matchmaking feature check missing"
grep -q "checkIfMatchmakingIsPossible" "$ANDROID" \
  || fail "Health Connect matchmaking check missing"
grep -q "createMatchmakingIntent" "$ANDROID" \
  || fail "Health Connect matchmaking flow missing"
grep -q "BLUETOOTH_SCAN" "$ANDROID" \
  || fail "Bluetooth scan permission missing"

# SDK-36 dependency lock.
grep -q "flutter_reactive_ble: 5.5.0" "$PUBSPEC" \
  || fail "flutter_reactive_ble must be pinned to 5.5.0"
grep -q "reactive_ble_mobile: 5.5.0" "$PUBSPEC" \
  || fail "reactive_ble_mobile must be pinned to 5.5.0"
grep -q "reactive_ble_platform_interface: 5.5.0" "$PUBSPEC" \
  || fail "reactive_ble_platform_interface must be pinned to 5.5.0"

grep -q "connect-client:1.2.0-alpha04" "$ANDROID" \
  || fail "Health Connect must be pinned to 1.2.0-alpha04"

# Explicitly block the two versions proven by CI to require SDK 37.
if grep -q "flutter_reactive_ble: 5.6" "$PUBSPEC"; then
  fail "flutter_reactive_ble 5.6 requires Android SDK 37"
fi
if grep -q "reactive_ble_mobile: 5.6" "$PUBSPEC"; then
  fail "reactive_ble_mobile 5.6 requires Android SDK 37"
fi
if grep -q "connect-client:1.2.0-alpha06" "$ANDROID"; then
  fail "Health Connect alpha06 requires Android SDK 37"
fi
if grep -q "compileSdk = 37" "$ANDROID"; then
  fail "SDK 37 must not be required by this build"
fi

echo "Healthy Me v0.9 source-discovery contract passed."
