#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="android/app/src/main/kotlin/com/rustnrum/healthyme/beta03"
CANON="native/android"
test -d "$CANON"
mkdir -p "$PKG_DIR"
cp "$CANON/MainActivity.kt" "$PKG_DIR/MainActivity.kt"
cp "$CANON/SalusProtocolReader.kt" "$PKG_DIR/SalusProtocolReader.kt"
cp "$CANON/SalusNotificationListenerService.kt" "$PKG_DIR/SalusNotificationListenerService.kt"
cp "$CANON/AndroidManifest.xml" android/app/src/main/AndroidManifest.xml
if [ -f "$CANON/build.gradle.kts" ]; then
  cp "$CANON/build.gradle.kts" android/app/build.gradle.kts
else
  cp "$CANON/build.gradle" android/app/build.gradle
fi
cp "$CANON/gradle.properties" android/gradle.properties
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  src="branding/android/mipmap-${density}/ic_launcher.png"
  dst="android/app/src/main/res/mipmap-${density}/ic_launcher.png"
  if [ -f "$src" ]; then mkdir -p "$(dirname "$dst")"; cp "$src" "$dst"; fi
done
grep -q 'package com.rustnrum.healthyme.beta03' "$PKG_DIR/MainActivity.kt"
grep -q 'SalusProtocolReader' "$PKG_DIR/MainActivity.kt"
echo "Canonical Android source copied; no patch chain."
