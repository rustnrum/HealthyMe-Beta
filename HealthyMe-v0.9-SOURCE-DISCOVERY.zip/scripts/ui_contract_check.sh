#!/usr/bin/env bash
set -euo pipefail

python3 scripts/direct_device_patch.py
python3 scripts/salus_brand_patch.py
python3 scripts/build27_patch.py

fail() { echo "UI CONTRACT FAILURE: $1" >&2; exit 1; }

grep -q '^version: 0.14.0+27$' pubspec.yaml || fail "build 27 version missing"
grep -q "protocolId == 'ring-uart-v1'" lib/services/source_hub_service.dart || fail "ring/watch identity fix missing"
grep -q 'refreshInspection' lib/services/direct_device_store.dart || fail "saved device identity refresh missing"
grep -q 'Read data to sync' lib/screens/sources_screen.dart || fail "direct reader status copy missing"
grep -q 'DirectMetricService' lib/screens/sources_screen.dart || fail "direct reader UI missing"

grep -q 'class _SalusLandscapePainter' lib/widgets/salus_widgets.dart || fail "landscape visual missing"
grep -q 'class SalusWeekStrip' lib/widgets/salus_widgets.dart || fail "weekday strip missing"
grep -q 'child: SalusWeekStrip()' lib/screens/home_shell.dart || fail "weekday strip not pinned"
grep -q "Today’s Focus" lib/screens/home_screen.dart || fail "Today’s Focus missing"

echo "Salus build 27 UI contract passed."
