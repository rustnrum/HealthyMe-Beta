#!/usr/bin/env bash
set -euo pipefail
python3 scripts/build37_cleanup_patch.py
fail() { echo "UI CONTRACT FAILURE: $1" >&2; exit 1; }
grep -q '^version: 0.20.0+37$' pubspec.yaml || fail "build 37 version missing"
grep -q 'SALUS_BUILD37_CLEANUP' lib/app.dart || fail "build 37 marker missing"
grep -q 'class HealthConnectScreen' lib/screens/health_connect_screen.dart || fail "Health Connect user screen missing"
grep -q 'class SleepScoreService' lib/services/sleep_score_service.dart || fail "sleep score service missing"
grep -q '_SalusSignalFieldPainter' lib/widgets/salus_widgets.dart || fail "abstract home background missing"
grep -q 'Typical pressure' lib/screens/cpap_screen.dart || fail "plain CPAP pressure label missing"
grep -q '_awaitingPasskey' lib/screens/cpap_screen.dart || fail "conditional CPAP pairing UI missing"
grep -q 'Re-pair device' lib/screens/cpap_screen.dart || fail "explicit CPAP re-pair action missing"
grep -q 'Compatibility built on Bluetooth standards' lib/screens/connections_screen.dart || fail "Bluetooth attribution footer missing"
grep -q 'Needs identification' lib/screens/connections_screen.dart || fail "unknown-device visibility missing"
grep -q 'ido-veryfit-family' lib/services/ble_protocol_profiles.dart || fail "IDO/VeryFit family missing"
echo "Salus Build 37 UI contract passed."
