#!/usr/bin/env bash
set -euo pipefail

python3 scripts/direct_device_patch.py
python3 scripts/salus_brand_patch.py
python3 scripts/build26_fix_patch.py

fail() { echo "UI CONTRACT FAILURE: $1" >&2; exit 1; }

grep -q '^version: 0.14.0+26$' pubspec.yaml || fail "build 26 version missing"
grep -q 'SALUS_BUILD26_ACTIVE_SOURCES' lib/services/source_hub_service.dart || fail "active-source pruning missing"
grep -q 'SALUS_BUILD26_CURRENT_SOURCE_STATE' lib/state/health_sync_provider.dart || fail "current-source sync missing"
grep -q 'DirectMetricService' lib/screens/sources_screen.dart || fail "direct metric reader UI missing"
grep -q "'Read data'" lib/screens/sources_screen.dart || fail "Read data action missing"
grep -q "'Pair'" lib/screens/sources_screen.dart || fail "truthful Pair action missing"
grep -q "'vívoactive'," lib/services/ble_protocol_profiles.dart || fail "Vivoactive accented identity missing"
grep -q 'height: 170' lib/screens/sources_screen.dart || fail "device card viewport height fix missing"
grep -q 'height: 66' lib/widgets/salus_widgets.dart || fail "device card art height fix missing"
grep -q 'overflow: TextOverflow.ellipsis' lib/widgets/salus_widgets.dart || fail "device card text overflow guard missing"

# Preserve the build-25 visual direction and weekday/home work.
for required in "SalusRecoveryOrb" "_WeekStrip" "Today’s Focus"; do
  grep -q "$required" lib/screens/home_screen.dart || fail "build 25 home visual missing: $required"
done

echo "Salus build 26 UI contract passed."
