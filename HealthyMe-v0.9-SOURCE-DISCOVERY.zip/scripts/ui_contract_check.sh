#!/usr/bin/env bash
set -euo pipefail
python3 scripts/build37_migration.py
fail(){ echo "UI CONTRACT FAILURE: $1" >&2; exit 1; }
grep -q '^version: 0.20.0+37$' pubspec.yaml || fail version
grep -q 'salusShowDeviceDebug' lib/app.dart || fail debug
grep -q "routeMetric: 'Sleep'" lib/services/direct_metric_service.dart || fail sleep-routing
grep -q 'More recovery signals are needed' lib/services/recovery_service.dart || fail recovery-coverage
grep -q 'Typical pressure' lib/screens/cpap_screen.dart || fail cpap-label
grep -q 'DeviceCategoryService' lib/screens/connections_screen.dart || fail category-service
grep -q '_SalusSignalFieldPainter' lib/widgets/salus_widgets.dart || fail background
echo "Build 37 direct-source migration passed."
