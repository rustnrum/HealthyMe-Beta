from pathlib import Path

MARKER = 'SALUS_BUILD37_CLEANUP'


def fail(message: str) -> None:
    raise SystemExit(f'build37 migration: {message}')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        fail(f'{label} anchor missing')
    return text.replace(old, new, 1)

# App route.
path = Path('lib/app.dart')
text = path.read_text()
if "screens/health_connect_screen.dart" not in text:
    text = replace_once(
        text,
        "import 'screens/health/health_shell.dart';\n",
        "import 'screens/health/health_shell.dart';\nimport 'screens/health_connect_screen.dart';\n",
        'health connect import',
    )
if "'/health-connect':" not in text:
    text = replace_once(
        text,
        "        '/health': (_) => const HealthShell(),\n",
        "        '/health': (_) => const HealthShell(),\n        '/health-connect': (_) => const HealthConnectScreen(),\n",
        'health connect route',
    )
if MARKER not in text:
    text = text.replace(
        "const bool _showDeviceDebug = bool.fromEnvironment(",
        f"// {MARKER}\nconst bool _showDeviceDebug = bool.fromEnvironment(",
        1,
    )
path.write_text(text)

# Central diagnostics flag.
path = Path('lib/app.dart')
text = path.read_text()
if "core/debug_flags.dart" not in text:
    text = replace_once(
        text,
        "import 'core/theme/app_theme.dart';\n",
        "import 'core/theme/app_theme.dart';\nimport 'core/debug_flags.dart';\n",
        'app debug import',
    )
text = text.replace(
    """const bool _showDeviceDebug = bool.fromEnvironment(
  'SALUS_SHOW_DEVICE_DEBUG',
  defaultValue: true,
);

""",
    '',
    1,
)
if '_showDeviceDebug' in text:
    text = text.replace('_showDeviceDebug', 'salusShowDeviceDebug')
path.write_text(text)

# One source per metric; Sleep owns stages.
path = Path('lib/state/app_state.dart')
text = path.read_text()
old = """  void setMetricSource(String metric, String source) {
    final next = Map<String, String>.from(state.metricSources);
    if (source == 'Auto') {
      next.remove(metric);
    } else {
      next[metric] = source;
    }
    _set(state.copyWith(metricSources: next));
  }
"""
new = """  void setMetricSource(String metric, String source) {
    final next = Map<String, String>.from(state.metricSources);
    final routingMetric = metric == 'Sleep Stages' ? 'Sleep' : metric;
    if (source == 'Auto') {
      next.remove(routingMetric);
      if (routingMetric == 'Sleep') next.remove('Sleep Stages');
    } else {
      next[routingMetric] = source;
      if (routingMetric == 'Sleep') next['Sleep Stages'] = source;
    }
    _set(state.copyWith(metricSources: next));
  }
"""
if old not in text:
    fail('metric source routing anchor missing')
text = text.replace(old, new, 1)
path.write_text(text)

path = Path('lib/services/health_connect_service.dart')
text = path.read_text()
old = """    final sleepResolved = resolvedOrigin('Sleep', sleepTypes);
    final sleepStageResolved = resolvedOrigin('Sleep Stages', sleepStageTypes);
"""
new = """    final sleepResolved = resolvedOrigin('Sleep', sleepTypes);
    // One sleep provider owns duration and stages. Never combine providers.
    final sleepStageResolved = sleepResolved;
    if (sleepResolved != null) {
      resolvedSources['Sleep Stages'] = sleepResolved;
    }
"""
if old not in text:
    fail('Health Connect sleep source anchor missing')
text = text.replace(old, new, 1)
path.write_text(text)

path = Path('lib/services/direct_metric_service.dart')
text = path.read_text()
for old, new in [
    ("final sleepLight = chosen('Sleep light', routeMetric: 'Sleep Stages');", "final sleepLight = chosen('Sleep light', routeMetric: 'Sleep');"),
    ("final sleepDeep = chosen('Sleep deep', routeMetric: 'Sleep Stages');", "final sleepDeep = chosen('Sleep deep', routeMetric: 'Sleep');"),
    ("final sleepRem = chosen('Sleep REM', routeMetric: 'Sleep Stages');", "final sleepRem = chosen('Sleep REM', routeMetric: 'Sleep');"),
    ("final sleepAwake = chosen('Sleep awake', routeMetric: 'Sleep Stages');", "final sleepAwake = chosen('Sleep awake', routeMetric: 'Sleep');"),
]:
    if old not in text:
        fail(f'direct sleep routing anchor missing: {old}')
    text = text.replace(old, new, 1)

if 'Future<bool> isCpapPairingPending' not in text:
    anchor = '  static bool isTherapyOnlyProtocol(String? protocolId) =>\n'
    idx = text.find(anchor)
    if idx < 0:
        fail('direct metric CPAP helper anchor')
    addition = """  Future<bool> isCpapPairingPending(String deviceId) async {
    if (deviceId.isEmpty || !Platform.isAndroid) return false;
    final pending = await _channel.invokeMethod<bool>(
      'isCpapPairingPending',
      <String, dynamic>{'deviceId': deviceId},
    );
    return pending ?? false;
  }

  Future<bool> resetCpapPairing(String deviceId) async {
    if (deviceId.isEmpty || !Platform.isAndroid) return false;
    final cleared = await _channel.invokeMethod<bool>(
      'resetCpapPairing',
      <String, dynamic>{'deviceId': deviceId},
    );
    return cleared ?? false;
  }

"""
    text = text[:idx] + addition + text[idx:]
path.write_text(text)

# Sleep score UI.
path = Path('lib/screens/sleep_screen.dart')
text = path.read_text()
if "sleep_score_service.dart" not in text:
    text = replace_once(
        text,
        "import '../services/sleep_guidance_service.dart';\n",
        "import '../services/sleep_guidance_service.dart';\nimport '../services/sleep_score_service.dart';\n",
        'sleep score import',
    )
old = """    final score = guidance.minimumMinutes <= 0 || h.sleepMinutes <= 0
        ? null
        : min(100, ((h.sleepMinutes / guidance.minimumMinutes) * 100).round());
"""
new = """    final stageSourceMatchesSleep =
        sleepSourceKey != null && sleepSourceKey == stageSourceKey;
    final sleepScore = SleepScoreService.build(
      h,
      guidance,
      stageSourceMatchesSleep: stageSourceMatchesSleep,
    );
    final score = sleepScore.score;
"""
if old in text:
    text = text.replace(old, new, 1)
# dart:math no longer needed by this screen after score replacement.
if 'min(' not in text and 'max(' not in text and 'pow(' not in text:
    text = text.replace("import 'dart:math';\n\n", '')
path.write_text(text)

# Recovery uses the same sleep score and pulls incomplete telemetry toward neutral.
path = Path('lib/services/recovery_service.dart')
text = path.read_text()
if "sleep_score_service.dart" not in text:
    text = replace_once(
        text,
        "import 'sleep_guidance_service.dart';\n",
        "import 'sleep_guidance_service.dart';\nimport 'sleep_score_service.dart';\n",
        'recovery sleep score import',
    )
start = text.find('  static RecoveryContributor _sleepContributor(HealthyMeState app) {')
end = text.find('  static RecoveryContributor _hrvContributor(HealthSnapshot h) {', start)
if start < 0 or end < 0:
    fail('recovery sleep contributor block')
replacement = """  static RecoveryContributor _sleepContributor(HealthyMeState app) {
    final h = app.health;
    final guidance = SleepGuidanceService.forAge(app.profile.age);
    final sleepSource = h.resolvedSources['Sleep'];
    final stageSource = h.resolvedSources['Sleep Stages'];
    final report = SleepScoreService.build(
      h,
      guidance,
      stageSourceMatchesSleep:
          sleepSource != null && sleepSource == stageSource,
    );
    if (report.score == null) {
      return const RecoveryContributor(
        name: 'Sleep',
        score: null,
        detail: 'No usable sleep data',
        available: false,
        weight: _sleepWeight,
      );
    }
    return RecoveryContributor(
      name: 'Sleep',
      score: report.score,
      detail:
          '${_minutes(h.sleepMinutes)} • sleep quality confidence ${report.confidence}%',
      weight: _sleepWeight,
    );
  }

"""
text = text[:start] + replacement + text[end:]
old = """    final objectiveScore = objectiveScored.isEmpty
        ? null
        : (objectiveWeighted / max(1, objectiveWeight))
            .round()
            .clamp(0, 100)
            .toInt();
"""
if old not in text:
    fail('recovery objective score anchor missing')
# Missing signals stay excluded. Confidence communicates coverage.
text = text.replace(old, old, 1)

coverage_anchor = """    final objectiveConfidence =
        (objectiveWeight / 100 * 100).round().clamp(0, 100).toInt();
"""
coverage_new = coverage_anchor + """
    if (dailyScore == null && objectiveWeight < 50) {
      return RecoveryReport(
        score: null,
        confidence: objectiveConfidence,
        band: RecoveryBand.noData,
        label: 'Building',
        summary: 'More recovery signals are needed before Salus shows a reliable recovery number.',
        contributors: contributors,
      );
    }
"""
if coverage_anchor not in text:
    fail('recovery confidence anchor missing')
text = text.replace(coverage_anchor, coverage_new, 1)
path.write_text(text)

# Home order: metrics before Today plan and device batteries.
path = Path('lib/screens/home_screen.dart')
text = path.read_text()
plan_start = text.find('            const SizedBox(height: 16),\n            _TodayPlanCard(')
if plan_start >= 0:
    metrics_start = text.find('            Row(\n              children: [', plan_start)
    if metrics_start < 0:
        fail('home metrics start')
    moved = text[plan_start:metrics_start]
    text = text[:plan_start] + '            const SizedBox(height: 16),\n' + text[metrics_start:]
    actions_marker = '            const SizedBox(height: 18),\n            SalusPaper(\n'
    insert_at = text.find(actions_marker, plan_start)
    if insert_at < 0:
        fail('home actions marker')
    text = text[:insert_at] + moved + text[insert_at:]
path.write_text(text)

# Abstract background matching the supplied reference direction, no literal mountains.
path = Path('lib/widgets/salus_widgets.dart')
text = path.read_text()
text = text.replace(
    'CustomPaint(painter: _SalusLandscapePainter())',
    'CustomPaint(painter: _SalusSignalFieldPainter())',
    1,
)
if 'class _SalusSignalFieldPainter' not in text:
    anchor = 'class SalusWeekStrip extends StatelessWidget {'
    idx = text.find(anchor)
    if idx < 0:
        fail('SalusWeekStrip anchor')
    painter = r'''class _SalusSignalFieldPainter extends CustomPainter {
  const _SalusSignalFieldPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final bounds = Offset.zero & size;
    canvas.drawRect(
      bounds,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF03070C),
            Color(0xFF06121B),
            Color(0xFF03080D),
            Color(0xFF020509),
          ],
          stops: [0.0, 0.35, 0.68, 1.0],
        ).createShader(bounds),
    );
    canvas.drawRect(
      bounds,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(0.10, -0.30),
          radius: 0.68,
          colors: [
            AppTheme.cyan.withValues(alpha: 0.13),
            AppTheme.blue.withValues(alpha: 0.045),
            Colors.transparent,
          ],
          stops: const [0.0, 0.45, 1.0],
        ).createShader(bounds),
    );

    final horizon = size.height * 0.46;
    final cols = math.max(52, (size.width / 6.0).round());
    final step = size.width / math.max(1, cols - 1);
    final dot = Paint();
    for (var row = 0; row < 16; row++) {
      final depth = row / 15.0;
      final base = horizon + row * 8.4;
      final amp = 18.0 + row * 2.2;
      final phase = row * 0.28;
      for (var col = 0; col < cols; col++) {
        final x = col * step;
        final t = x / math.max(1.0, size.width);
        final y = base +
            math.sin(t * math.pi * 3.2 + phase) * amp +
            math.sin(t * math.pi * 7.1 - phase * 0.4) * 5.0;
        final edge = (2 * (t - 0.5).abs()).clamp(0.0, 1.0);
        final alpha = (0.25 - depth * 0.13) * (1 - edge * 0.50);
        dot.color = AppTheme.cyan.withValues(alpha: alpha);
        canvas.drawCircle(Offset(x, y), 0.72 + (1 - depth) * 0.35, dot);
      }
    }
    for (var trace = 0; trace < 4; trace++) {
      final path = Path();
      final base = horizon + 8 + trace * 19;
      for (double x = 0; x <= size.width; x += 4) {
        final t = x / math.max(1.0, size.width);
        final y = base +
            math.sin(t * math.pi * (2.8 + trace * 0.16) + trace * 0.8) *
                (14 + trace * 2.5);
        if (x == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.65
          ..color = AppTheme.cyan.withValues(alpha: 0.10 - trace * 0.014),
      );
    }
    canvas.drawRect(
      Rect.fromLTRB(0, size.height * 0.58, size.width, size.height),
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0x00020509),
            Color(0xD8020509),
            Color(0xFF020509),
          ],
          stops: [0.0, 0.38, 1.0],
        ).createShader(
          Rect.fromLTRB(0, size.height * 0.58, size.width, size.height),
        ),
    );
  }

  @override
  bool shouldRepaint(covariant _SalusSignalFieldPainter oldDelegate) => false;
}

'''
    text = text[:idx] + painter + text[idx:]
path.write_text(text)

# Connections: universal BLE visibility + clean categories + Health Connect user page.
path = Path('lib/screens/connections_screen.dart')
text = path.read_text()
if "debug_flags.dart" not in text:
    text = replace_once(
        text,
        "import '../core/theme/app_theme.dart';\n",
        "import '../core/theme/app_theme.dart';\nimport '../core/debug_flags.dart';\nimport '../services/device_category_service.dart';\n",
        'connections helper imports',
    )
text = text.replace(
    """const bool _showDeviceDebugTools = bool.fromEnvironment(
  'SALUS_SHOW_DEVICE_DEBUG',
  defaultValue: true,
);

""",
    '',
    1,
)
text = text.replace('_showDeviceDebugTools', 'salusShowDeviceDebug')
if "String _deviceFilter = 'All';" not in text:
    text = replace_once(
        text,
        '  String? _scanMessage;\n',
        "  String? _scanMessage;\n  String _deviceFilter = 'All';\n",
        'device filter state',
    )

scan_start = text.find('  Future<void> _scan() async {')
scan_end = text.find('  Future<void> _connect(_DiscoveredHealthDevice item) async {', scan_start)
if scan_start < 0 or scan_end < 0:
    fail('connections scan block')
scan = """  Future<void> _scan() async {
    if (_scanning) return;
    setState(() {
      _scanning = true;
      _scanMessage = null;
      _discovered = const [];
    });

    try {
      final devices = await _ble.scan();
      final found = <_DiscoveredHealthDevice>[];

      for (final device in devices.take(40)) {
        if (_saved.any((saved) => saved.id == device.id)) continue;
        final likelyHealth = device.hasKnownCapabilities ||
            DeviceCategoryService.looksLikeHealthName(device.name);
        found.add(
          _DiscoveredHealthDevice(
            device: device,
            inspection: null,
            likelyHealth: likelyHealth,
          ),
        );
      }

      if (!mounted) return;
      setState(() {
        _discovered = found;
        final recognized = found.where((item) => item.likelyHealth).length;
        _scanMessage = found.isEmpty
            ? 'No Bluetooth devices found. Keep the device awake and nearby, then scan again.'
            : '$recognized health device${recognized == 1 ? '' : 's'} recognized • '
                '${found.length - recognized} other nearby';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _scanMessage = 'Could not scan: $error');
    } finally {
      if (mounted) setState(() => _scanning = false);
    }
  }

"""

text = text[:scan_start] + scan + text[scan_end:]

if 'bool _matchesDeviceFilter(' not in text:
    anchor = '  List<String> _displayMetrics(List<String> values) {'
    idx = text.find(anchor)
    if idx < 0:
        fail('connections display metrics anchor')
    helpers = """  bool _matchesDeviceFilter(String kind, String? protocolId, String name) {
    if (_deviceFilter == 'All') return true;
    return DeviceCategoryService.category(
      deviceKind: kind,
      protocolId: protocolId,
      name: name,
    ) == _deviceFilter;
  }

"""
    text = text[:idx] + helpers + text[idx:]

build_anchor = """    final healthConnectSources = SourceHubService.healthSources(health)
        .where((source) => source.transport == SourceTransport.healthConnect)
        .toList();
"""
if build_anchor in text and 'final visibleSaved =' not in text:
    text = text.replace(
        build_anchor,
        build_anchor + """    final visibleSaved = _saved
        .where((device) => _matchesDeviceFilter(
              device.deviceKind,
              device.protocolId,
              device.name,
            ))
        .toList();
    final visibleDiscovered = _discovered
        .where((item) => _matchesDeviceFilter(
              item.inspection?.deviceKind ?? item.device.deviceKind,
              item.inspection?.protocolId ?? item.device.protocolId,
              item.device.name,
            ))
        .toList();
""",
        1,
    )

section_anchor = """          const SizedBox(height: 10),
          if (_saved.isEmpty)
"""
filter_ui = """          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                for (final filter in const [
                  'All', 'Watch', 'Ring', 'Scale', 'CPAP', 'Other'
                ]) ...[
                  ChoiceChip(
                    label: Text(filter),
                    selected: _deviceFilter == filter,
                    onSelected: (_) => setState(() => _deviceFilter = filter),
                  ),
                  const SizedBox(width: 7),
                ],
              ],
            ),
          ),
          const SizedBox(height: 10),
          if (visibleSaved.isEmpty)
"""
if section_anchor in text:
    text = text.replace(section_anchor, filter_ui, 1)
text = text.replace('            for (final device in _saved) ...[', '            for (final device in visibleSaved) ...[', 1)
text = text.replace('          if (_discovered.isNotEmpty) ...[', '          if (visibleDiscovered.isNotEmpty) ...[', 1)
text = text.replace('            for (final item in _discovered) ...[', '            for (final item in visibleDiscovered) ...[', 1)
text = text.replace(
    '            onAction: _healthConnectAction,\n',
    "            onAction: () => Navigator.of(context).pushNamed('/health-connect'),\n",
    1,
)
# Make the Health Connect card a navigation card, not the diagnostic/sync surface.
text = text.replace(
    "                    : authorized\n                        ? 'Sync Health Connect'\n                        : 'Connect Health Connect',",
    "                    : 'Open Health Connect',",
    1,
)

if 'Compatibility built on Bluetooth standards' not in text:
    anchor = '          if (_showDeviceDebugTools) ...[\n'
    text = text.replace(
        anchor,
        """          const SizedBox(height: 24),
          const Center(
            child: Text(
              'Compatibility built on Bluetooth standards and independent protocol research.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppTheme.textMuted,
                fontSize: 10.8,
                height: 1.35,
              ),
            ),
          ),
          if (_showDeviceDebugTools) ...[
""",
        1,
    )
text = text.replace(
    '    final kind = inspection?.deviceKind ?? device.deviceKind;\n',
    "    final rawKind = inspection?.deviceKind ?? device.deviceKind;\n    final kind = rawKind == 'Bluetooth device' ? 'Needs identification' : rawKind;\n",
    1,
)
path.write_text(text)

# IDO / VeryFit plus common rebrand family identification.
path = Path('lib/services/ble_protocol_profiles.dart')
text = path.read_text()
if 'idoVeryfitService' not in text:
    text = replace_once(
        text,
        "  static const String no1Service =\n      '000055ff-0000-1000-8000-00805f9b34fb';\n",
        "  static const String no1Service =\n      '000055ff-0000-1000-8000-00805f9b34fb';\n  static const String idoVeryfitService =\n      '00000af0-0000-1000-8000-00805f9b34fb';\n",
        'IDO service constant',
    )
if 'ido-veryfit-family' not in text:
    anchor = "    BleProtocolProfile(\n      id: 'no1-f1-family',\n"
    idx = text.find(anchor)
    if idx < 0:
        fail('protocol profile insertion anchor')
    profiles = """    BleProtocolProfile(
      id: 'ido-veryfit-family',
      label: 'IDO / VeryFit watch family',
      deviceKind: 'Watch / band',
      anyServices: {idoVeryfitService},
      nameHints: ['veryfit', 'toobur', 'idw16', 'idw19'],
      capabilities: [],
      note: 'IDO/VeryFit family identified. Proprietary metric decoding is not enabled yet.',
    ),
    BleProtocolProfile(
      id: 'gloryfit-family',
      label: 'GloryFit watch family',
      deviceKind: 'Watch / band',
      nameHints: ['gloryfit', 'glory fit'],
      capabilities: [],
      note: 'GloryFit family identified. Proprietary metric decoding is not enabled yet.',
    ),
    BleProtocolProfile(
      id: 'fitpro-family',
      label: 'FitPro watch family',
      deviceKind: 'Watch / band',
      nameHints: ['fitpro', 'fit pro', 'lefun'],
      capabilities: [],
      note: 'FitPro/Lefun family identified. Proprietary metric decoding is not enabled yet.',
    ),
    BleProtocolProfile(
      id: 'wearfit-family',
      label: 'WearFit watch family',
      deviceKind: 'Watch / band',
      nameHints: ['wearfit', 'wear fit'],
      capabilities: [],
      note: 'WearFit family identified. Proprietary metric decoding is not enabled yet.',
    ),
    BleProtocolProfile(
      id: 'huawei-family',
      label: 'Huawei / Honor watch family',
      deviceKind: 'Watch / band',
      nameHints: ['huawei', 'honor band', 'honor watch'],
      capabilities: [],
      note: 'Huawei/Honor family identified. Proprietary metric decoding is not enabled yet.',
    ),
    BleProtocolProfile(
      id: 'polar-family',
      label: 'Polar sensor / watch family',
      deviceKind: 'Watch / sensor',
      nameHints: ['polar'],
      capabilities: [],
      note: 'Polar family identified. Standard BLE health services are used when exposed.',
    ),
"""

    text = text[:idx] + profiles + text[idx:]
path.write_text(text)

# Harden family matching and only advertise metrics that a reader can decode.
path = Path('lib/services/ble_protocol_profiles.dart')
text = path.read_text()
old = """    final nameMatch = nameHints.isNotEmpty &&
        nameHints.any(normalizedName.contains);
"""
new = """    bool matchesHint(String hint) {
      final pattern = RegExp(
        '(^|[^a-z0-9])${RegExp.escape(hint.toLowerCase())}([^a-z0-9]|$)',
      );
      return pattern.hasMatch(normalizedName);
    }

    final nameMatch = nameHints.isNotEmpty && nameHints.any(matchesHint);
"""
if old not in text:
    fail('protocol name matcher anchor missing')
text = text.replace(old, new, 1)

for profileId in [
  'huami-zepp-family',
  'no1-f1-family',
  'fitcloud-family',
  'moyoung-dafit-family',
]:
    marker = f"id: '{profileId}',"
    at = text.find(marker)
    if at < 0:
        fail(f'protocol profile missing: {profileId}')
    cap = text.find('      capabilities:', at)
    note = text.find('      note:', cap)
    if cap < 0 or note < 0:
        fail(f'capability block missing: {profileId}')
    text = text[:cap] + '      capabilities: [],\n' + text[note:]

garminAt = text.find("id: 'garmin-family',")
garminCap = text.find('      capabilities:', garminAt)
garminNote = text.find('      note:', garminCap)
if garminAt < 0 or garminCap < 0 or garminNote < 0:
    fail('Garmin capability block missing')
text = text[:garminCap] + """      capabilities: [
        'Steps',
        'Heart rate',
        'HRV',
        'SpO2',
        'Respiratory rate',
        'Active calories',
        'Body battery',
        'Stress',
      ],
""" + text[garminNote:]

for profileId in ['ring-uart-v1', 'garmin-family', 'cpap-family']:
    marker = f"id: '{profileId}',"
    at = text.find(marker)
    end = text.find('    ),', at)
    if at < 0 or end < 0:
        fail(f'reader-ready profile missing: {profileId}')
    block = text[at:end]
    if 'dataReaderReady:' not in block:
        text = text[:end] + '      dataReaderReady: true,\n' + text[end:]

path.write_text(text)

# CPAP UI: only show code when native pairing is genuinely pending.
path = Path('lib/screens/cpap_screen.dart')
text = path.read_text()
if "import 'dart:async';" not in text:
    text = "import 'dart:async';\n\n" + text
if "debug_flags.dart" not in text:
    text = replace_once(
        text,
        "import '../core/theme/app_theme.dart';\n",
        "import '../core/theme/app_theme.dart';\nimport '../core/debug_flags.dart';\n",
        'CPAP debug import',
    )
if 'bool _awaitingPasskey = false;' not in text:
    text = text.replace(
        '  bool _submittingPasskey = false;\n',
        '  bool _submittingPasskey = false;\n  bool _awaitingPasskey = false;\n  Timer? _pairingPoll;\n',
        1,
    )
text = text.replace(
    """  void dispose() {
    _passkeyController.dispose();
    super.dispose();
  }
""",
    """  void dispose() {
    _pairingPoll?.cancel();
    _passkeyController.dispose();
    super.dispose();
  }
""",
    1,
)
start = text.find('  Future<void> _checkForData() async {')
end = text.find('  Future<void> _submitPairingCode() async {', start)
if start < 0 or end < 0:
    fail('CPAP sync method block')
check_method = """  Future<void> _checkForData() async {
    final device = _selected;
    if (device == null || _checking) return;
    _passkeyController.clear();
    _pairingPoll?.cancel();
    setState(() {
      _checking = true;
      _awaitingPasskey = false;
      _status = 'Syncing CPAP…';
    });

    _pairingPoll = Timer.periodic(const Duration(milliseconds: 500), (_) async {
      try {
        final pending = await _direct.isCpapPairingPending(device.id);
        if (!mounted || !_checking) return;
        if (pending != _awaitingPasskey) {
          setState(() {
            _awaitingPasskey = pending;
            if (pending) {
              _status = 'AirSense is asking for its one-time 4-digit pairing code.';
            }
          });
        }
      } catch (_) {}
    });

    try {
      final result = await _direct.readAndStore(
        BleDeviceCandidate(
          id: device.id,
          name: device.name,
          rssi: -127,
          advertisedServices: const [],
          capabilities: device.capabilities,
          protocolProfile: device.protocolLabel,
          protocolId: device.protocolId,
          protocolNote: null,
          deviceKind: device.deviceKind,
          manufacturerDataHex: '',
          bondState: device.bonded ? 'bonded' : device.pairState,
        ),
        protocolId: 'cpap-family',
        duration: const Duration(seconds: 70),
        cpapPasskey: null,
      );
      if (!mounted) return;
      setState(() {
        _status = result.message;
        _probeObservations = result.observations;
        _probeDiagnostics = result.diagnostics;
      });
      await _load();
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = 'Could not sync CPAP data: $error');
    } finally {
      _pairingPoll?.cancel();
      _pairingPoll = null;
      if (mounted) {
        setState(() {
          _checking = false;
          _awaitingPasskey = false;
        });
      }
    }
  }

  Future<void> _resetPairing() async {
    final device = _selected;
    if (device == null || _checking) return;
    final cleared = await _direct.resetCpapPairing(device.id);
    if (!mounted) return;
    setState(() {
      _status = cleared
          ? 'Pairing reset. Tap Sync CPAP and enter the code only when the AirSense displays one.'
          : 'Could not reset the saved CPAP pairing.';
    });
  }

"""
text = text[:start] + check_method + text[end:]
text = text.replace("_checking ? 'Secure session in progress…' : 'Start secure CPAP sync'", "_checking ? 'Syncing CPAP…' : 'Sync CPAP'")
text = text.replace('                  if (_checking) ...[', '                  if (_awaitingPasskey) ...[', 1)
text = text.replace("            ? 'Pairing code sent. Keep the AirSense screen open while Salus completes the secure session.'", "            ? 'Pairing code accepted. Completing CPAP sync…'")
text = text.replace("            : 'No active ResMed pairing request was found. Start secure sync again and enter the new code while it is displayed.';", "            : 'No active pairing request was found. Only enter a code when the AirSense displays one.';")
if 'Re-pair device' not in text:
    anchor = '                  if (_awaitingPasskey) ...[\n'
    text = text.replace(
        anchor,
        """                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: _checking ? null : _resetPairing,
                      child: const Text('Re-pair device'),
                    ),
                  ),
                  if (_awaitingPasskey) ...[
""",
        1,
    )
text = text.replace(
    "                  if (_probeDiagnostics.isNotEmpty ||\n                      _probeObservations.isNotEmpty) ...[",
    "                  if (salusShowDeviceDebug &&\n                      (_probeDiagnostics.isNotEmpty ||\n                          _probeObservations.isNotEmpty)) ...[",
    1,
)
text = text.replace(": '${device.name} • secure read-only therapy sync',", ": '${device.name} • connected',")
text = text.replace("label: 'Pressure',", "label: 'Typical pressure',")
path.write_text(text)

# MethodChannel bridge for CPAP pairing state/reset.
path = Path('scripts/protocol_metric_native_patch.py')
text = path.read_text()
if '"isCpapPairingPending" ->' not in text:
    anchor = '                "submitCpapPasskey" -> {\n'
    idx = text.find(anchor)
    if idx < 0:
        fail('protocol bridge submit anchor')
    addition = """                "isCpapPairingPending" -> {
                    val deviceId = call.argument<String>("deviceId")
                    result.success(
                        !deviceId.isNullOrBlank() &&
                            SalusProtocolReader.isCpapPairingPending(deviceId)
                    )
                }
                "resetCpapPairing" -> {
                    val deviceId = call.argument<String>("deviceId")
                    result.success(
                        !deviceId.isNullOrBlank() &&
                            SalusProtocolReader.resetCpapPairing(this, deviceId)
                    )
                }
"""
    text = text[:idx] + addition + text[idx:]
path.write_text(text)

# Native ResMed pairing stays persistent unless user explicitly resets it.
path = Path('scripts/SalusProtocolReader.kt.template')
text = path.read_text()
if 'fun isCpapPairingPending' not in text:
    anchor = '        fun submitCpapPasskey(deviceId: String, passkey: String): Boolean {\n'
    idx = text.find(anchor)
    if idx < 0:
        fail('protocol reader submit anchor')
    addition = """        fun isCpapPairingPending(deviceId: String): Boolean {
            val key = deviceId.replace(":", "").lowercase()
            return ACTIVE_CPAP_PAIRINGS.containsKey(key)
        }

        fun resetCpapPairing(activity: Activity, deviceId: String): Boolean {
            val key = deviceId.replace(":", "").lowercase()
            ACTIVE_CPAP_PAIRINGS.remove(key)
            return activity
                .getSharedPreferences("salus_resmed_session_v1", 0)
                .edit()
                .remove("${key}_clientId")
                .remove("${key}_masterPairKey")
                .commit()
        }

"""
    text = text[:idx] + addition + text[idx:]
old = """                if (method == "RequestSession" || method == "CheckSessionIntegrity") {
                    clearStoredCpapCredentials()
                    notes.add("Stored ResMed credentials were rejected; starting a fresh pairing exchange.")
                    startCpapKeyExchange()
                    return
                }
"""
new = """                if (method == "RequestSession" || method == "CheckSessionIntegrity") {
                    finish(
                        "Saved CPAP pairing could not be authenticated. Use Re-pair device only if you want to create a new pairing."
                    )
                    return
                }
"""
text = text.replace(old, new, 1)
old = """                    if (!accepted || master == null || nonce == null) {
                        clearStoredCpapCredentials()
                        notes.add("Stored ResMed session credentials were rejected; starting a fresh pairing exchange.")
                        startCpapKeyExchange()
                        return
                    }
"""
new = """                    if (!accepted || master == null || nonce == null) {
                        finish(
                            "Saved CPAP pairing could not be authenticated. Use Re-pair device only if you want to create a new pairing."
                        )
                        return
                    }
"""
text = text.replace(old, new, 1)
text = text.replace(
    '"ResMed secure sync completed with ${cpapSummaryRecords} stored nightly Summary record" +\n                (if (cpapSummaryRecords == 1) "." else "s.")',
    '"${cpapSummaryRecords} night" +\n                (if (cpapSummaryRecords == 1) " synced." else "s synced.")',
)
path.write_text(text)

print('Salus Build 37 cleanup patch applied.')
