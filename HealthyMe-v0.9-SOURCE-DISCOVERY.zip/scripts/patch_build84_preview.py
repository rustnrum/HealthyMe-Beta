#!/usr/bin/env python3
"""Build 84: non-destructive Home visual-preview switch in legacy HealthyMe-Beta.

Keeps old package ID, Health Connect/BLE code, signing, storage keys,
modules, and current Home implementation. This is a graphics-only addition.
"""
from pathlib import Path

pub = Path('pubspec.yaml')
v=pub.read_text()
if 'version: 0.21.46+84' in v:
    print('Build 84 home preview already applied')
    raise SystemExit(0)
if 'version: 0.21.45+83' not in v:
    raise RuntimeError('Build 84 requires committed Build 83 source (0.21.45+83)')

def replace(filename, old, new):
    path=Path(filename)
    contents=path.read_text()
    n=contents.count(old)
    if n!=1:
        raise RuntimeError(f'Build84 Home preview anchor mismatch {filename}: expected 1, got {n}; {old[:90]!r}')
    path.write_text(contents.replace(old,new,1))

home='lib/screens/premium/salus_home_77.dart'
replace(home,
    "import '../../widgets/salus77_design.dart';",
    "import '../../widgets/salus77_design.dart';\nimport 'salus_home_preview_84.dart';")
replace(home,
    'class _SalusHome77State extends ConsumerState<SalusHome77> {\n  double? _calorieGoal;',
    'class _SalusHome77State extends ConsumerState<SalusHome77> {\n  bool _showNewHomeDesign = true;\n  double? _calorieGoal;')
replace(home,
    '  @override Widget build(BuildContext context){\n    final app=ref.watch(appStateProvider),h=app.health;',
    '  @override Widget build(BuildContext context){\n    if (_showNewHomeDesign) {\n      return SalusHomePage(onViewLive: () => setState(() => _showNewHomeDesign = false));\n    }\n    final app=ref.watch(appStateProvider),h=app.health;')
replace(home,
    "Row(children:[Expanded(child:Text('S A L U S',style:TextStyle(color:S77.ink,fontSize:19,\n          fontWeight:FontWeight.w900,letterSpacing:3))),",
    "Row(children:[Expanded(child:InkWell(\n          onTap:()=>setState(()=>_showNewHomeDesign=true),\n          child:Text('S A L U S',style:TextStyle(color:S77.ink,fontSize:19,\n          fontWeight:FontWeight.w900,letterSpacing:3)))),")

replace('pubspec.yaml', 'version: 0.21.45+83', 'version: 0.21.46+84')
# Preserve earlier version contract tests while extending to the new build.
changed=0
for f in Path('test').glob('*.dart'):
    s=f.read_text()
    newer=s.replace('version: 0.21.45+83','version: 0.21.46+84')
    # The approved visual contract permits versions 75-84.
    newer=newer.replace('(37|38|39|40|41|42|43|44|45)', '(37|38|39|40|41|42|43|44|45|46)')
    newer=newer.replace('(75|76|77|78|79|80|81|82|83)', '(75|76|77|78|79|80|81|82|83|84)')
    if newer!=s:
        f.write_text(newer)
        changed+=1
print(f'Build 84 applied; updated {changed} version contract tests')
