#!/usr/bin/env bash
set -euo pipefail

MANIFEST="android/app/src/main/AndroidManifest.xml"

if [ ! -f "$MANIFEST" ]; then
  echo "AndroidManifest.xml not found"
  exit 1
fi

python3 - <<'PY'
from pathlib import Path

path = Path("android/app/src/main/AndroidManifest.xml")
text = path.read_text()

marker = "HEALTHY_ME_SOURCE_DISCOVERY_V09"
if marker not in text:
    permissions = f"""
    <!-- {marker}: Health Connect read + Bluetooth source discovery -->
    <uses-feature android:name="android.hardware.bluetooth_le" android:required="false" />
    <uses-permission android:name="android.permission.ACTIVITY_RECOGNITION" />
    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.health.READ_STEPS" />
    <uses-permission android:name="android.permission.health.READ_ACTIVE_CALORIES_BURNED" />
    <uses-permission android:name="android.permission.health.READ_DISTANCE" />
    <uses-permission android:name="android.permission.health.READ_HEART_RATE" />
    <uses-permission android:name="android.permission.health.READ_RESTING_HEART_RATE" />
    <uses-permission android:name="android.permission.health.READ_HEART_RATE_VARIABILITY" />
    <uses-permission android:name="android.permission.health.READ_RESPIRATORY_RATE" />
    <uses-permission android:name="android.permission.health.READ_OXYGEN_SATURATION" />
    <uses-permission android:name="android.permission.health.READ_WEIGHT" />
    <uses-permission android:name="android.permission.health.READ_BODY_FAT" />
    <uses-permission android:name="android.permission.health.READ_BODY_WATER_MASS" />
    <uses-permission android:name="android.permission.health.READ_LEAN_BODY_MASS" />
    <uses-permission android:name="android.permission.health.READ_SLEEP" />
    <uses-permission android:name="android.permission.health.READ_EXERCISE" />
    <uses-permission android:name="android.permission.health.READ_HEALTH_DATA_HISTORY" />
"""

    manifest_end = text.find(">")
    text = text[:manifest_end + 1] + permissions + text[manifest_end + 1:]

    queries = """
    <queries>
        <package android:name="com.google.android.apps.healthdata" />
        <intent>
            <action android:name="androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW_PERMISSION_USAGE" />
            <category android:name="android.intent.category.HEALTH_PERMISSIONS" />
        </intent>
    </queries>
"""
    text = text.replace("    <application", queries + "\n    <application", 1)

    rationale = """
            <intent-filter>
                <action android:name="androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE" />
            </intent-filter>
"""
    text = text.replace("        </activity>", rationale + "        </activity>", 1)

    alias = """
        <activity-alias
            android:name="ViewPermissionUsageActivity"
            android:exported="true"
            android:targetActivity=".MainActivity"
            android:permission="android.permission.START_VIEW_PERMISSION_USAGE">
            <intent-filter>
                <action android:name="android.intent.action.VIEW_PERMISSION_USAGE" />
                <category android:name="android.intent.category.HEALTH_PERMISSIONS" />
            </intent-filter>
        </activity-alias>
"""
    text = text.replace("    </application>", alias + "    </application>", 1)

path.write_text(text)
PY

MAIN_ACTIVITY="$(find android/app/src/main/kotlin -name MainActivity.kt -print -quit 2>/dev/null || true)"
if [ -z "$MAIN_ACTIVITY" ]; then
  echo "MainActivity.kt not found"
  exit 1
fi

cat > "$MAIN_ACTIVITY" <<'KOTLIN'
package com.rustnrum.healthyme.beta03

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.health.connect.GetDeviceDataSourcesResponse
import android.health.connect.HealthConnectException
import android.health.connect.HealthConnectManager
import android.health.connect.MatchmakingRequest
import android.health.connect.MatchmakingResponse
import android.os.Build
import android.os.OutcomeReceiver
import android.os.ext.SdkExtensions
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterFragmentActivity() {
    companion object {
        private const val CHANNEL = "com.rustnrum.healthyme/source_discovery"
        private const val MATCHMAKING_REQUEST_CODE = 9041
        private const val U_MATCHMAKING_EXTENSION = 21
        private const val U_DEVICE_SOURCE_EXTENSION = 22
    }

    private var pendingMatchmakingResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "discoveryStatus" -> discoveryStatus(result)
                "launchMatchmaking" -> launchMatchmaking(result)
                "deviceDataSources" -> deviceDataSources(result)
                else -> result.notImplemented()
            }
        }
    }

    private fun uExtensionVersion(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            SdkExtensions.getExtensionVersion(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
        } else {
            0
        }
    }

    private fun supportsMatchmaking(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
            uExtensionVersion() >= U_MATCHMAKING_EXTENSION
    }

    private fun supportsDeviceDataSources(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
            uExtensionVersion() >= U_DEVICE_SOURCE_EXTENSION
    }

    @SuppressLint("NewApi")
    private fun healthManager(): HealthConnectManager? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            return null
        }
        return getSystemService(HealthConnectManager::class.java)
    }

    private fun visibleHealthApps(): List<Map<String, String>> {
        val packages = linkedMapOf<String, String>()
        val intents = listOf(
            Intent("androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE"),
            Intent("android.intent.action.VIEW_PERMISSION_USAGE").apply {
                addCategory("android.intent.category.HEALTH_PERMISSIONS")
            },
        )

        for (intent in intents) {
            @Suppress("DEPRECATION")
            val activities = packageManager.queryIntentActivities(intent, 0)
            for (info in activities) {
                val packageName = info.activityInfo?.packageName ?: continue
                if (packageName == this.packageName) continue

                val label = try {
                    @Suppress("DEPRECATION")
                    val appInfo = packageManager.getApplicationInfo(packageName, 0)
                    packageManager.getApplicationLabel(appInfo).toString()
                } catch (_: PackageManager.NameNotFoundException) {
                    packageName
                }

                packages[packageName] = label
            }
        }

        return packages.map { (packageName, label) ->
            mapOf("packageName" to packageName, "label" to label)
        }
    }

    @SuppressLint("NewApi")
    private fun discoveryStatus(result: MethodChannel.Result) {
        val extension = uExtensionVersion()
        val matchmakingSupported = supportsMatchmaking()
        val devicesSupported = supportsDeviceDataSources()

        if (!matchmakingSupported) {
            result.success(
                mapOf(
                    "matchmakingSupported" to false,
                    "matchmakingPossible" to false,
                    "deviceProvidersSupported" to devicesSupported,
                    "healthExtensionVersion" to extension,
                    "visibleApps" to visibleHealthApps(),
                    "message" to
                        "Health Connect matchmaking requires U extension 21 or newer.",
                )
            )
            return
        }

        val manager = healthManager()
        if (manager == null) {
            result.success(
                mapOf(
                    "matchmakingSupported" to false,
                    "matchmakingPossible" to false,
                    "deviceProvidersSupported" to false,
                    "healthExtensionVersion" to extension,
                    "visibleApps" to visibleHealthApps(),
                    "message" to "Health Connect system service is unavailable.",
                )
            )
            return
        }

        val request = MatchmakingRequest.Builder().build()
        manager.isMatchmakingPossible(
            request,
            mainExecutor,
            object : OutcomeReceiver<MatchmakingResponse, HealthConnectException> {
                override fun onResult(response: MatchmakingResponse) {
                    result.success(
                        mapOf(
                            "matchmakingSupported" to true,
                            "matchmakingPossible" to response.isMatchmakingPossible,
                            "deviceProvidersSupported" to devicesSupported,
                            "healthExtensionVersion" to extension,
                            "visibleApps" to visibleHealthApps(),
                            "message" to if (response.isMatchmakingPossible) {
                                "Android found at least one source that can write a metric Healthy Me can read."
                            } else {
                                "Android did not find an unconnected compatible Health Connect source."
                            },
                        )
                    )
                }

                override fun onError(error: HealthConnectException) {
                    result.error(
                        "MATCHMAKING_CHECK_FAILED",
                        error.message ?: "Health Connect matchmaking check failed.",
                        error.errorCode,
                    )
                }
            },
        )
    }

    @SuppressLint("NewApi")
    private fun launchMatchmaking(result: MethodChannel.Result) {
        if (!supportsMatchmaking()) {
            result.error(
                "MATCHMAKING_UNAVAILABLE",
                "Health Connect matchmaking is not available on this Android build.",
                null,
            )
            return
        }

        val manager = healthManager()
        if (manager == null) {
            result.error(
                "HEALTH_CONNECT_UNAVAILABLE",
                "Health Connect system service is unavailable.",
                null,
            )
            return
        }

        try {
            pendingMatchmakingResult = result
            val request = MatchmakingRequest.Builder().build()
            @Suppress("DEPRECATION")
            startActivityForResult(
                manager.createMatchmakingIntent(request),
                MATCHMAKING_REQUEST_CODE,
            )
        } catch (error: Throwable) {
            pendingMatchmakingResult = null
            result.error(
                "MATCHMAKING_LAUNCH_FAILED",
                error.message ?: error.javaClass.simpleName,
                null,
            )
        }
    }

    @Deprecated("Retained for Health Connect matchmaking result delivery.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != MATCHMAKING_REQUEST_CODE) return

        pendingMatchmakingResult?.success(
            mapOf(
                "granted" to (resultCode == Activity.RESULT_OK),
                "resultCode" to resultCode,
            )
        )
        pendingMatchmakingResult = null
    }

    @SuppressLint("NewApi")
    private fun deviceDataSources(result: MethodChannel.Result) {
        if (!supportsDeviceDataSources()) {
            result.success(emptyList<Map<String, Any?>>())
            return
        }

        val manager = healthManager()
        if (manager == null) {
            result.success(emptyList<Map<String, Any?>>())
            return
        }

        manager.getDeviceDataSources(
            mainExecutor,
            object : OutcomeReceiver<GetDeviceDataSourcesResponse, HealthConnectException> {
                override fun onResult(response: GetDeviceDataSourcesResponse) {
                    val values = response.deviceDataSources.map { source ->
                        val device = source.device
                        val dataTypes = source.deviceDataTypeSources.map { dataType ->
                            mapOf(
                                "type" to dataType.dataType.simpleName,
                                "available" to dataType.isAvailable,
                                "enabled" to dataType.isUserEnabled,
                            )
                        }

                        mapOf<String, Any?>(
                            "origin" to source.deviceDataOrigin.packageName,
                            "displayName" to (device.displayName ?: ""),
                            "manufacturer" to (device.manufacturer ?: ""),
                            "model" to (device.model ?: ""),
                            "dataTypes" to dataTypes,
                        )
                    }
                    result.success(values)
                }

                override fun onError(error: HealthConnectException) {
                    result.error(
                        "DEVICE_SOURCE_DISCOVERY_FAILED",
                        error.message ?: "Health Connect device discovery failed.",
                        error.errorCode,
                    )
                }
            },
        )
    }
}
KOTLIN

python3 - <<'PYGRADLE'
from pathlib import Path
import re

for name in ('android/app/build.gradle.kts', 'android/app/build.gradle'):
    path = Path(name)
    if not path.exists():
        continue

    text = path.read_text()

    if name.endswith('.kts'):
        text = re.sub(
            r'compileSdk\s*=\s*flutter\.compileSdkVersion',
            'compileSdk = 37',
            text,
        )
        text = text.replace('minSdk = flutter.minSdkVersion', 'minSdk = 26')
        text = re.sub(
            r'namespace\s*=\s*["\'][^"\']+["\']',
            'namespace = "com.rustnrum.healthyme.beta03"',
            text,
        )
        text = re.sub(
            r'applicationId\s*=\s*["\'][^"\']+["\']',
            'applicationId = "com.rustnrum.healthyme.beta03"',
            text,
        )
    else:
        text = re.sub(
            r'compileSdkVersion\s+flutter\.compileSdkVersion',
            'compileSdkVersion 37',
            text,
        )
        text = text.replace(
            'minSdkVersion flutter.minSdkVersion',
            'minSdkVersion 26',
        )
        text = re.sub(
            r'applicationId\s+["\'][^"\']+["\']',
            'applicationId "com.rustnrum.healthyme.beta03"',
            text,
        )

    path.write_text(text)
PYGRADLE

if ! grep -q '^android.useAndroidX=true' android/gradle.properties 2>/dev/null; then
  echo 'android.useAndroidX=true' >> android/gradle.properties
fi
if ! grep -q '^android.enableJetifier=true' android/gradle.properties 2>/dev/null; then
  echo 'android.enableJetifier=true' >> android/gradle.properties
fi

python3 - <<'PYLABEL'
from pathlib import Path
import re

path = Path('android/app/src/main/AndroidManifest.xml')
text = path.read_text()
text = re.sub(
    r'android:label="[^"]+"',
    'android:label="Healthy Me Beta 0.9"',
    text,
    count=1,
)
path.write_text(text)
PYLABEL

echo "Healthy Me Beta 0.9 Android source-discovery bridge applied."

bash scripts/ui_contract_check.sh
bash scripts/source_discovery_contract.sh
