#!/usr/bin/env bash
set -euo pipefail
# The upload overlays this temporary wrapper on top of the checked-out Build 83 source.
# Run the existing verified app preparation unchanged, then install the design preview.
original="$(mktemp)"
trap 'rm -f "$original"' EXIT
git show HEAD:scripts/prepare_android.sh > "$original"
if grep -q 'existing verified app preparation unchanged' "$original"; then
  echo 'Unexpected wrapper found in committed source. Aborting to avoid recursive preparation.' >&2
  exit 1
fi
bash "$original"
cp "$original" scripts/prepare_android.sh
python3 scripts/install_preview84.py
