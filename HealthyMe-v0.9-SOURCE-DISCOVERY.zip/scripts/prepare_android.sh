#!/usr/bin/env bash
# Build 70 voice API repair overlay for the HealthyMe-Beta GitHub workflow.
# Restores the exact pre-failure Build 70 overlay already stored in this repo,
# verifies its blob integrity, then applies the targeted speech_to_text fix.
set -euo pipefail
cd "${GITHUB_WORKSPACE:-.}"
SOURCE_COMMIT='2d5247cbc8f88dce85f35d985e4e9c831fbacb85'
SOURCE_BLOB='f21b0553470fd043de7a42d6e3f213b8fe887829'
ARCHIVE='HealthyMe-v0.9-SOURCE-DISCOVERY.zip'
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

# checkout@v5 can be shallow. Fetch only the precise previous source commit.
git fetch --quiet --no-tags --depth=12 origin main
if ! git cat-file -e "${SOURCE_COMMIT}^{commit}" 2>/dev/null; then
  git fetch --quiet --no-tags origin "$SOURCE_COMMIT"
fi
git show "$SOURCE_COMMIT:$ARCHIVE" > "$WORK/original-build70.zip"
ACTUAL="$(git hash-object "$WORK/original-build70.zip")"
if [[ "$ACTUAL" != "$SOURCE_BLOB" ]]; then
  echo "Original Build 70 source integrity check failed: $ACTUAL" >&2
  exit 1
fi
mkdir -p "$WORK/extracted"
unzip -q "$WORK/original-build70.zip" -d "$WORK/extracted"

# Avoid truncating this currently running script: replace it by atomic rename.
while IFS= read -r -d '' file; do
  relative="${file#"$WORK/extracted/"}"
  if [[ "$relative" == 'scripts/prepare_android.sh' ]]; then continue; fi
  mkdir -p "$(dirname "$relative")"
  cp -p "$file" "$relative"
done < <(find "$WORK/extracted" -type f -print0)
mv -f "$WORK/extracted/scripts/prepare_android.sh" scripts/prepare_android.sh

python3 - <<'PYFIX'
from pathlib import Path
p = Path('lib/screens/salus_voice_screen.dart')
s = p.read_text(encoding='utf-8')
old = '''        listenFor: const Duration(seconds: 25),
        pauseFor: const Duration(seconds: 3),
        listenMode: stt.ListenMode.dictation,'''
new = '''        listenOptions: stt.SpeechListenOptions(
          listenFor: const Duration(seconds: 25),
          pauseFor: const Duration(seconds: 3),
          listenMode: stt.ListenMode.dictation,
        ),'''
if s.count(new) == 1 and s.count(old) == 0:
    print('Build 70 speech options already up to date')
elif s.count(old) == 1 and s.count(new) == 0:
    p.write_text(s.replace(old, new, 1), encoding='utf-8')
    print('Build 70: migrated speech_to_text 7.5 options')
else:
    raise RuntimeError('Voice API pattern changed; refusing an unverified patch')
PYFIX

# Run the original preparation that applies Build 70 dependency, manifest,
# navigation and version patches and preserves permanent signing settings.
bash scripts/prepare_android.sh

# Guard against accidental regression to the failed version.
grep -Fxq 'version: 0.21.32+70' pubspec.yaml
grep -Fq 'listenOptions: stt.SpeechListenOptions(' lib/screens/salus_voice_screen.dart
