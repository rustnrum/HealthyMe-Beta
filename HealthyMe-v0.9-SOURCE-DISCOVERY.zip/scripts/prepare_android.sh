#!/usr/bin/env bash
set -euo pipefail
# Build 84 preview integration: install original-assets screens on Build 83.
original="$(mktemp)"
trap 'rm -f "$original"' EXIT
git show HEAD:scripts/prepare_android.sh > "$original"
if grep -q 'Build 84 preview integration:' "$original"; then
  echo 'Committed prep is a wrapper; cannot safely run recursively.' >&2
  exit 1
fi
bash -n "$original"
bash "$original"
python3 scripts/install_preview84.py

# Guard completed Build 84 sources against replaying older migrations.
# Still execute the native Android setup from the original script.
python3 - "$original" <<'PY_PREP'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text()
start="if ! grep -Eq '^version: 0\\.21\\."
native='test -f lib/widgets/garmin_body_battery_panel.dart'
assert s.count(start) >= 1, 'Original version-migration section missing'
assert s.count(native) == 1, 'Original Android copy section missing'
guard="if grep -Eq '^version: 0\\.21\\.46\\+84$' pubspec.yaml; then\n  echo 'Build84: migrations already applied'\nelse\n"
s=s.replace(start,guard+start,1)
s=s.replace(native,'fi\n'+native,1)
p.write_text(s)
PY_PREP
bash -n "$original"
# Atomic rename, NEVER cp/truncate the Bash script that is currently executing.
mv -f "$original" scripts/prepare_android.sh
