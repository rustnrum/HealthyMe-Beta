import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'services/health_service.dart';
import 'services/lab_import_service.dart';
import 'services/storage_service.dart';

const _bg = Color(0xFF051821);
const _surface = Color(0xFF0B2633);
const _surface2 = Color(0xFF103444);
const _stroke = Color(0xFF173E4D);
const _cyan = Color(0xFF2BB9F3);
const _green = Color(0xFF4BE39E);
const _purple = Color(0xFF8D68F6);
const _pink = Color(0xFFFF5E73);
const _orange = Color(0xFFFFA72F);
const _blue = Color(0xFF35BDF4);
const _muted = Color(0xFF8CA4AE);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HealthyMeApp());
}

class HealthyMeApp extends StatefulWidget {
  const HealthyMeApp({super.key});

  @override
  State<HealthyMeApp> createState() => _HealthyMeAppState();
}

class _HealthyMeAppState extends State<HealthyMeApp> {
  final controller = AppController();

  @override
  void initState() {
    super.initState();
    controller.initialize();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Healthy Me',
      themeMode: ThemeMode.dark,
      theme: _theme(),
      darkTheme: _theme(),
      home: AnimatedBuilder(
        animation: controller,
        builder: (context, _) => HomeShell(controller: controller),
      ),
    );
  }

  ThemeData _theme() {
    final scheme = ColorScheme.fromSeed(
      seedColor: _cyan,
      brightness: Brightness.dark,
      surface: _surface,
    ).copyWith(
      primary: _cyan,
      secondary: _green,
      tertiary: _purple,
      surface: _surface,
      onSurface: Colors.white,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: _bg,
      canvasColor: _bg,
      dividerColor: _stroke,
      cardTheme: const CardThemeData(
        color: _surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(16)),
          side: BorderSide(color: _stroke),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: _surface2,
        labelStyle: const TextStyle(color: _muted),
        hintStyle: const TextStyle(color: _muted),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 66,
        backgroundColor: const Color(0xFF06131B),
        indicatorColor: _cyan.withOpacity(.14),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          return IconThemeData(color: states.contains(WidgetState.selected) ? _cyan : _muted, size: 22);
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          return TextStyle(
            color: states.contains(WidgetState.selected) ? Colors.white : _muted,
            fontWeight: FontWeight.w700,
            fontSize: 10,
          );
        }),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: _bg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: _green,
          foregroundColor: const Color(0xFF052016),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
    );
  }
}

class WellnessSuggestion {
  const WellnessSuggestion({required this.title, required this.summary, required this.why, required this.icon, required this.color});
  final String title;
  final String summary;
  final List<String> why;
  final IconData icon;
  final Color color;
}

class DailyStateSummary {
  const DailyStateSummary({
    required this.recovery,
    required this.stress,
    required this.label,
    required this.detail,
  });

  final double recovery;
  final double stress;
  final String label;
  final String detail;
}

const _dailyRecoveryKeys = <String>[
  'physicalCapability',
  'mentalCapability',
  'emotionalBalance',
  'overallRecovery',
];

const _dailyStressKeys = <String>[
  'muscularStress',
  'lackActivation',
  'negativeEmotionalState',
  'overallStress',
];

class AppController extends ChangeNotifier {
  final HealthService _healthService = HealthService();
  final LabImportService _labImport = LabImportService();
  final StorageService _storage = StorageService();

  bool ready = false;
  bool syncing = false;
  HealthSnapshot health = const HealthSnapshot();

  String name = 'Mike';
  String sex = '';
  String birthday = '';
  String startDate = '';
  String units = 'lb/in';
  String activityLevel = 'Moderately Active';
  String hormoneContext = 'Prefer not to specify';
  String cycleDay = '';
  double heightIn = 64;
  double startWeightLb = 200;
  double goalWeightLb = 150;
  double manualWeightLb = 200;
  double bodyFatGoal = 20;
  int stepGoal = 10000;
  int workoutGoal = 4;

  final Map<String, double> measurements = {
    'Neck': 0,
    'Chest': 0,
    'Waist': 0,
    'Left Arm': 0,
    'Right Arm': 0,
    'Hips': 0,
    'Left Thigh': 0,
    'Right Thigh': 0,
    'Left Calf': 0,
    'Right Calf': 0,
  };

  final List<Map<String, String>> photos = [];
  final List<Map<String, String>> bloodwork = [];
  final Map<String, String> sourcePreference = {
    'Steps': 'Auto',
    'Heart Rate': 'Auto',
    'Sleep': 'Auto',
    'Weight': 'Auto',
  };

  bool morningCheckInEnabled = true;
  int morningCheckInStartMinutes = 8 * 60;
  String dismissedCheckInDate = '';
  final List<Map<String, dynamic>> dailyCheckIns = [];

  String get todayDateKey => _dateKey(DateTime.now());

  Map<String, dynamic>? get todayCheckIn {
    for (final row in dailyCheckIns) {
      if (row['date']?.toString() == todayDateKey) return row;
    }
    return null;
  }

  bool get isCheckInDismissedToday => dismissedCheckInDate == todayDateKey;

  bool get isMorningCheckInDue {
    if (!morningCheckInEnabled || todayCheckIn != null || isCheckInDismissedToday) return false;
    final now = DateTime.now();
    final minutes = now.hour * 60 + now.minute;
    return minutes >= morningCheckInStartMinutes;
  }

  String get morningCheckInTimeLabel {
    final hour24 = (morningCheckInStartMinutes ~/ 60).clamp(0, 23);
    final minute = morningCheckInStartMinutes % 60;
    final suffix = hour24 >= 12 ? 'PM' : 'AM';
    final hour12 = hour24 % 12 == 0 ? 12 : hour24 % 12;
    return '$hour12:${minute.toString().padLeft(2, '0')} $suffix';
  }

  DailyStateSummary? get todayDailyState {
    final row = todayCheckIn;
    if (row == null) return null;
    final recovery = (row['recoveryAverage'] as num?)?.toDouble() ?? _averageFromRow(row, _dailyRecoveryKeys);
    final stress = (row['stressAverage'] as num?)?.toDouble() ?? _averageFromRow(row, _dailyStressKeys);
    return _summarizeDailyState(recovery, stress);
  }

  int get completedCheckInCount => dailyCheckIns.length;

  List<Map<String, dynamic>> get baselineRows {
    final today = todayDateKey;
    return dailyCheckIns.where((row) => row['date']?.toString() != today).take(30).toList();
  }

  double? get baselineRecovery {
    final rows = baselineRows;
    if (rows.length < 7) return null;
    final values = rows.map((row) => (row['recoveryAverage'] as num?)?.toDouble() ?? _averageFromRow(row, _dailyRecoveryKeys)).toList();
    return values.reduce((a, b) => a + b) / values.length;
  }

  double? get baselineStress {
    final rows = baselineRows;
    if (rows.length < 7) return null;
    final values = rows.map((row) => (row['stressAverage'] as num?)?.toDouble() ?? _averageFromRow(row, _dailyStressKeys)).toList();
    return values.reduce((a, b) => a + b) / values.length;
  }

  String get dailyBaselineText {
    final current = todayDailyState;
    final recoveryBase = baselineRecovery;
    final stressBase = baselineStress;
    if (current == null) {
      return baselineRows.length < 7 ? 'Building your baseline: ${baselineRows.length}/7 completed prior days' : 'Personal baseline ready';
    }
    if (recoveryBase == null || stressBase == null) {
      return 'Building your baseline: ${baselineRows.length}/7 completed prior days';
    }
    final recoveryDelta = current.recovery - recoveryBase;
    final stressDelta = current.stress - stressBase;
    if (recoveryDelta <= -0.6 || stressDelta >= 0.6) return 'Below your recent normal today';
    if (recoveryDelta >= 0.6 || stressDelta <= -0.6) return 'Better than your recent normal today';
    return 'Close to your recent normal today';
  }

  double get currentWeightLb => sourcePreference['Weight'] == 'Manual' ? manualWeightLb : (health.weightLb ?? manualWeightLb);
  double? get bodyFatPercent => health.bodyFatPercent;

  int? get age {
    final match = RegExp(r'^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$').firstMatch(birthday.trim());
    if (match == null) return null;
    final month = int.tryParse(match.group(1)!);
    final day = int.tryParse(match.group(2)!);
    final year = int.tryParse(match.group(3)!);
    if (month == null || day == null || year == null) return null;
    final dob = DateTime(year, month, day);
    final now = DateTime.now();
    var years = now.year - dob.year;
    if (now.month < dob.month || (now.month == dob.month && now.day < dob.day)) years--;
    return years >= 0 ? years : null;
  }

  int? get recommendedSleepMinMinutes {
    final years = age;
    if (years == null) return null;
    if (years >= 65) return 7 * 60;
    if (years >= 18) return 7 * 60;
    if (years >= 13) return 8 * 60;
    if (years >= 6) return 9 * 60;
    return null;
  }

  int? get recommendedSleepMaxMinutes {
    final years = age;
    if (years == null) return null;
    if (years >= 65) return 8 * 60;
    if (years >= 18) return 9 * 60;
    if (years >= 13) return 10 * 60;
    if (years >= 6) return 12 * 60;
    return null;
  }

  String get recommendedSleepRangeLabel {
    final min = recommendedSleepMinMinutes;
    final max = recommendedSleepMaxMinutes;
    if (min == null || max == null) return 'Add birthday for guidance';
    return '${min ~/ 60}–${max ~/ 60} hr/night';
  }

  List<WellnessSuggestion> get suggestions {
    final items = <WellnessSuggestion>[];
    final today = todayCheckIn;
    final daily = todayDailyState;
    if (today != null && daily != null) {
      final lackActivation = (today['lackActivation'] as num?)?.toInt() ?? 0;
      final muscularStress = (today['muscularStress'] as num?)?.toInt() ?? 0;
      final negativeEmotion = (today['negativeEmotionalState'] as num?)?.toInt() ?? 0;
      final overallStress = (today['overallStress'] as num?)?.toInt() ?? 0;
      if (lackActivation >= 4 && daily.recovery < 4.5) {
        items.add(WellnessSuggestion(
          title: 'Make starting easier',
          summary: 'Try 10 minutes of easy movement first. Reassess after you start instead of deciding the whole workout now.',
          why: [
            'Your activation score is elevated today (${lackActivation}/6).',
            'Your recovery average is ${daily.recovery.toStringAsFixed(1)}/6.',
            'A short bout of movement can improve mood and activation for some people; Healthy Me can track whether it helps you.',
          ],
          icon: Icons.directions_walk_rounded,
          color: _green,
        ));
      } else if (overallStress >= 4 || negativeEmotion >= 4) {
        items.add(WellnessSuggestion(
          title: 'Use a short reset',
          summary: 'Take a brief walk or a few quiet minutes of slow breathing, then check whether your state feels different.',
          why: [
            'Your stress/emotional load is elevated in today's check-in.',
            'Today's stress average is ${daily.stress.toStringAsFixed(1)}/6.',
            'This is a wellness suggestion, not treatment. The app records whether the reset actually helps you.',
          ],
          icon: Icons.self_improvement_rounded,
          color: _cyan,
        ));
      } else if (muscularStress >= 4 || daily.recovery < 3.0) {
        items.add(WellnessSuggestion(
          title: 'Lower the training demand',
          summary: 'Consider a lighter session, mobility, or recovery activity instead of forcing the planned intensity.',
          why: [
            'Your physical recovery pattern is lower today.',
            'Muscular/body stress is ${muscularStress}/6.',
            'Recovery can be a productive training choice rather than a failed workout day.',
          ],
          icon: Icons.spa_rounded,
          color: _purple,
        ));
      }
    }
    final minSleep = recommendedSleepMinMinutes;
    if (minSleep != null && health.sleepMinutes > 0 && health.sleepMinutes < minSleep) {
      items.add(WellnessSuggestion(
        title: 'Recovery first',
        summary: 'Keep today lighter and prioritize a full sleep window tonight.',
        why: [
          'Last sleep: ${_durationLabel(health.sleepMinutes)}',
          'Age-based recommendation: $recommendedSleepRangeLabel',
          'Rest can be a productive training decision when recovery is limited.',
        ],
        icon: Icons.bedtime_rounded,
        color: _purple,
      ));
    }
    if (stepGoal > 0 && health.steps < (stepGoal * .65).round()) {
      final remaining = (stepGoal - health.steps).clamp(0, stepGoal);
      items.add(WellnessSuggestion(
        title: 'Build movement gradually',
        summary: 'Add one or two short walks instead of trying to make up the whole day at once.',
        why: [
          'Steps so far: ${_commas(health.steps)} of ${_commas(stepGoal)}',
          '${_commas(remaining)} steps remain to your current daily goal.',
          'Consistency is more useful than a single oversized activity day.',
        ],
        icon: Icons.directions_walk_rounded,
        color: _green,
      ));
    }
    if (goalWeightLb < currentWeightLb) {
      items.add(WellnessSuggestion(
        title: 'Nutrition focus',
        summary: 'Keep meals protein-forward, include fiber-rich foods, and let weight trend guide future calorie adjustments.',
        why: [
          'Current weight: ${currentWeightLb.toStringAsFixed(1)} lb',
          'Goal weight: ${goalWeightLb.toStringAsFixed(0)} lb',
          'Healthy Me will adapt more precisely once actual food intake history is available.',
        ],
        icon: Icons.restaurant_rounded,
        color: _orange,
      ));
    }
    if (items.isEmpty) {
      items.add(const WellnessSuggestion(
        title: 'Keep the pattern going',
        summary: 'Your available data does not show a strong reason to change course today.',
        why: ['Healthy Me avoids inventing a recommendation when the available data is limited or already on track.'],
        icon: Icons.check_circle_rounded,
        color: _cyan,
      ));
    }
    return items.take(3).toList();
  }

  List<String> get suggestedHormoneTests {
    final normalizedSex = sex.trim().toLowerCase();
    if (normalizedSex.startsWith('f')) {
      return const ['Estradiol', 'Progesterone', 'LH', 'FSH', 'Prolactin', 'SHBG', 'Total Testosterone', 'Free Testosterone', 'DHEA-S', 'TSH', 'Free T4', 'Vitamin D', 'Vitamin B12', 'Ferritin'];
    }
    if (normalizedSex.startsWith('m')) {
      return const ['Total Testosterone', 'Free Testosterone', 'SHBG', 'Estradiol', 'LH', 'FSH', 'Prolactin', 'DHEA-S', 'TSH', 'Free T4', 'Vitamin D', 'Vitamin B12', 'Ferritin'];
    }
    return const ['TSH', 'Free T4', 'Vitamin D', 'Vitamin B12', 'Ferritin', 'Total Testosterone', 'Free Testosterone', 'Estradiol', 'Progesterone', 'LH', 'FSH', 'SHBG'];
  }

  List<Map<String, String>> get bloodworkWithDerived {
    final rows = bloodwork.map((row) => Map<String, String>.from(row)).toList();
    Map<String, String>? latestTotal;
    Map<String, String>? latestHdl;
    for (final row in rows) {
      final test = normalizeBiomarkerName(row['test'] ?? '');
      if (latestTotal == null && test == 'Total Cholesterol') latestTotal = row;
      if (latestHdl == null && test == 'HDL Cholesterol') latestHdl = row;
      if (latestTotal != null && latestHdl != null) break;
    }
    if (latestTotal != null && latestHdl != null) {
      final already = rows.any((row) => normalizeBiomarkerName(row['test'] ?? '') == 'Non-HDL Cholesterol' && row['date'] == latestTotal!['date']);
      final total = double.tryParse((latestTotal['result'] ?? '').replaceAll(RegExp(r'[^0-9.\-]'), ''));
      final hdl = double.tryParse((latestHdl['result'] ?? '').replaceAll(RegExp(r'[^0-9.\-]'), ''));
      if (!already && total != null && hdl != null && total >= hdl) {
        rows.insert(0, {
          'test': 'Non-HDL Cholesterol',
          'result': (total - hdl).toStringAsFixed(0),
          'units': latestTotal['units'] ?? latestHdl['units'] ?? '',
          'date': latestTotal['date'] ?? latestHdl['date'] ?? '',
          'source': 'Calculated from Total Cholesterol − HDL',
          'referenceRange': '',
          'category': 'Lifestyle',
          'recognized': 'true',
          'derived': 'true',
        });
      }
    }
    return rows;
  }

  double get goalProgress {
    final total = (startWeightLb - goalWeightLb).abs();
    if (total <= 0) return 0;
    final moved = (startWeightLb - currentWeightLb).clamp(0, total);
    return (moved / total).clamp(0.0, 1.0);
  }

  Future<void> initialize() async {
    final state = await _storage.loadState();
    _readState(state);
    if (startDate.isEmpty) startDate = _shortDate(DateTime.now());
    ready = true;
    notifyListeners();
  }

  Future<void> syncHealth() async {
    if (syncing) return;
    syncing = true;
    notifyListeners();
    health = await _healthService.loadToday(sourcePreference: sourcePreference);
    syncing = false;
    notifyListeners();
  }

  Future<void> saveProfile({
    required String newName,
    required String newSex,
    required String newBirthday,
    required String newStartDate,
    required String newUnits,
    required String newActivityLevel,
    required double newHeight,
    required double newStart,
    required double newGoal,
  }) async {
    name = newName.trim().isEmpty ? 'Me' : newName.trim();
    sex = newSex.trim();
    birthday = newBirthday.trim();
    startDate = newStartDate.trim();
    units = newUnits;
    activityLevel = newActivityLevel;
    heightIn = newHeight;
    startWeightLb = newStart;
    goalWeightLb = newGoal;
    await _persist();
  }

  Future<void> saveGoals({
    required int steps,
    required int workouts,
    required double bodyFat,
  }) async {
    stepGoal = steps;
    workoutGoal = workouts;
    bodyFatGoal = bodyFat;
    await _persist();
  }

  Future<void> setManualWeight(double value) async {
    manualWeightLb = value;
    await _persist();
  }

  Future<void> setMeasurement(String key, double value) async {
    measurements[key] = value;
    await _persist();
  }

  Future<void> setSourcePreference(String metric, String value) async {
    sourcePreference[metric] = value;
    await _persist();
    if (metric != 'Weight' || value != 'Manual') {
      await syncHealth();
    }
  }

  Future<void> addProgressPhoto(String view) async {
    final path = await _storage.pickAndStoreProgressPhoto(view);
    if (path == null) return;
    photos.insert(0, {
      'path': path,
      'view': view,
      'date': DateTime.now().toIso8601String(),
    });
    await _persist();
  }

  Future<void> addBloodwork({
    required String test,
    required String result,
    required String units,
    required String date,
    required String source,
    String referenceRange = '',
  }) async {
    final normalized = normalizeBiomarkerName(test);
    bloodwork.insert(0, {
      'test': normalized,
      'originalTest': test.trim(),
      'result': result.trim(),
      'units': units.trim(),
      'date': date.trim(),
      'source': source.trim(),
      'referenceRange': referenceRange.trim(),
      'category': biomarkerCategory(normalized),
      'recognized': knownBiomarkers.contains(normalized.toLowerCase()) ? 'true' : 'false',
    });
    await _persist();
  }

  Future<LabImportBatch?> pickBloodworkFile() => _labImport.pickAndParse();

  Future<void> addImportedBloodwork(LabImportBatch batch) async {
    bloodwork.insertAll(0, batch.rows.map((row) => Map<String, String>.from(row)));
    await _persist();
  }

  Future<void> saveHormoneContext(String context, String cycle) async {
    hormoneContext = context;
    cycleDay = cycle.trim();
    await _persist();
  }

  Future<void> saveMorningCheckInSettings({required bool enabled, required int startMinutes}) async {
    morningCheckInEnabled = enabled;
    morningCheckInStartMinutes = startMinutes.clamp(0, (24 * 60) - 1).toInt();
    await _persist();
  }

  Future<void> dismissMorningCheckInForToday() async {
    dismissedCheckInDate = todayDateKey;
    await _persist();
  }

  Future<void> completeMorningCheckIn(Map<String, int> values) async {
    if (![..._dailyRecoveryKeys, ..._dailyStressKeys].every(values.containsKey)) {
      throw ArgumentError('All eight daily-state items are required.');
    }
    final recovery = _averageValues(_dailyRecoveryKeys.map((key) => values[key]!).toList());
    final stress = _averageValues(_dailyStressKeys.map((key) => values[key]!).toList());
    final existing = todayCheckIn;
    final row = <String, dynamic>{
      'date': todayDateKey,
      'completedAt': DateTime.now().toIso8601String(),
      ...values,
      'recoveryAverage': recovery,
      'stressAverage': stress,
      'resetAction': existing?['resetAction']?.toString() ?? '',
      'resetHelpfulness': existing?['resetHelpfulness']?.toString() ?? '',
    };
    dailyCheckIns.removeWhere((entry) => entry['date']?.toString() == todayDateKey);
    dailyCheckIns.insert(0, row);
    dismissedCheckInDate = '';
    await _persist();
  }

  Future<void> recordResetAction(String action) async {
    final row = todayCheckIn;
    if (row == null) return;
    row['resetAction'] = action;
    row['resetStartedAt'] = DateTime.now().toIso8601String();
    row['resetHelpfulness'] = '';
    await _persist();
  }

  Future<void> recordResetHelpfulness(String value) async {
    final row = todayCheckIn;
    if (row == null) return;
    row['resetHelpfulness'] = value;
    row['resetFeedbackAt'] = DateTime.now().toIso8601String();
    await _persist();
  }

  Future<void> _persist() async {
    await _storage.saveState({
      'name': name,
      'sex': sex,
      'birthday': birthday,
      'startDate': startDate,
      'units': units,
      'activityLevel': activityLevel,
      'hormoneContext': hormoneContext,
      'cycleDay': cycleDay,
      'heightIn': heightIn,
      'startWeightLb': startWeightLb,
      'goalWeightLb': goalWeightLb,
      'manualWeightLb': manualWeightLb,
      'bodyFatGoal': bodyFatGoal,
      'stepGoal': stepGoal,
      'workoutGoal': workoutGoal,
      'measurements': measurements,
      'photos': photos,
      'bloodwork': bloodwork,
      'sourcePreference': sourcePreference,
      'morningCheckInEnabled': morningCheckInEnabled,
      'morningCheckInStartMinutes': morningCheckInStartMinutes,
      'dismissedCheckInDate': dismissedCheckInDate,
      'dailyCheckIns': dailyCheckIns,
    });
    notifyListeners();
  }

  void _readState(Map<String, dynamic> state) {
    name = state['name'] as String? ?? name;
    sex = state['sex'] as String? ?? sex;
    birthday = state['birthday'] as String? ?? birthday;
    startDate = state['startDate'] as String? ?? startDate;
    units = state['units'] as String? ?? units;
    activityLevel = state['activityLevel'] as String? ?? activityLevel;
    hormoneContext = state['hormoneContext'] as String? ?? hormoneContext;
    cycleDay = state['cycleDay'] as String? ?? cycleDay;
    heightIn = (state['heightIn'] as num?)?.toDouble() ?? heightIn;
    startWeightLb = (state['startWeightLb'] as num?)?.toDouble() ?? startWeightLb;
    goalWeightLb = (state['goalWeightLb'] as num?)?.toDouble() ?? goalWeightLb;
    manualWeightLb = (state['manualWeightLb'] as num?)?.toDouble() ?? manualWeightLb;
    bodyFatGoal = (state['bodyFatGoal'] as num?)?.toDouble() ?? bodyFatGoal;
    stepGoal = (state['stepGoal'] as num?)?.toInt() ?? stepGoal;
    workoutGoal = (state['workoutGoal'] as num?)?.toInt() ?? workoutGoal;
    morningCheckInEnabled = state['morningCheckInEnabled'] as bool? ?? morningCheckInEnabled;
    morningCheckInStartMinutes = (state['morningCheckInStartMinutes'] as num?)?.toInt() ?? morningCheckInStartMinutes;
    dismissedCheckInDate = state['dismissedCheckInDate']?.toString() ?? dismissedCheckInDate;

    final savedCheckIns = state['dailyCheckIns'];
    if (savedCheckIns is List) {
      dailyCheckIns
        ..clear()
        ..addAll(savedCheckIns.whereType<Map>().map(
              (row) => row.map((k, v) => MapEntry(k.toString(), v)),
            ));
      dailyCheckIns.sort((a, b) => (b['date']?.toString() ?? '').compareTo(a['date']?.toString() ?? ''));
    }

    final savedMeasurements = state['measurements'];
    if (savedMeasurements is Map) {
      for (final entry in savedMeasurements.entries) {
        if (measurements.containsKey(entry.key) && entry.value is num) {
          measurements[entry.key as String] = (entry.value as num).toDouble();
        }
      }
    }

    final savedPhotos = state['photos'];
    if (savedPhotos is List) {
      photos
        ..clear()
        ..addAll(savedPhotos.whereType<Map>().map(
              (p) => p.map((k, v) => MapEntry(k.toString(), v.toString())),
            ));
    }

    final savedBloodwork = state['bloodwork'];
    if (savedBloodwork is List) {
      bloodwork
        ..clear()
        ..addAll(savedBloodwork.whereType<Map>().map(
              (r) => r.map((k, v) => MapEntry(k.toString(), v.toString())),
            ));
    }

    final savedSources = state['sourcePreference'];
    if (savedSources is Map) {
      for (final entry in savedSources.entries) {
        sourcePreference[entry.key.toString()] = entry.value.toString();
      }
    }
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.controller});
  final AppController controller;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  Timer? _clockTimer;

  @override
  void initState() {
    super.initState();
    _clockTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    super.dispose();
  }

  void _go(int next) => setState(() => index = next);

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    if (!c.ready) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final pages = <Widget>[
      DashboardScreen(controller: c, goTab: _go),
      ActivityScreen(controller: c, onBack: () => _go(0)),
      SleepScreen(controller: c, onBack: () => _go(0)),
      BodyMetricsScreen(controller: c, onBack: () => _go(0)),
      MoreScreen(controller: c, onBack: () => _go(0)),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: _go,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.directions_run_rounded), label: 'Activity'),
          NavigationDestination(icon: Icon(Icons.bedtime_rounded), label: 'Sleep'),
          NavigationDestination(icon: Icon(Icons.monitor_weight_rounded), label: 'Body'),
          NavigationDestination(icon: Icon(Icons.menu_rounded), label: 'More'),
        ],
      ),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.controller, required this.goTab});
  final AppController controller;
  final ValueChanged<int> goTab;

  @override
  Widget build(BuildContext context) {
    final h = controller.health;
    final sleepH = h.sleepMinutes ~/ 60;
    final sleepM = h.sleepMinutes % 60;
    final stepsProgress = controller.stepGoal <= 0 ? 0.0 : (h.steps / controller.stepGoal).clamp(0.0, 1.0);

    return RefreshIndicator(
      onRefresh: controller.syncHealth,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 22),
        children: [
          Row(
            children: [
              const Expanded(child: Text('Healthy Me', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
              IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => GuidanceScreen(controller: controller))), icon: const Icon(Icons.auto_awesome_rounded, color: _orange), tooltip: 'Suggestions'),
              IconButton(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProfileScreen(controller: controller))),
                icon: const Icon(Icons.settings_rounded),
              ),
            ],
          ),
          Text('Good ${_daypart()}!', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(_dateLabel(), style: const TextStyle(fontSize: 12, color: _muted)),
          const SizedBox(height: 14),
          _DailyStateDashboardCard(controller: controller),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
              child: Column(
                children: [
                  SizedBox(
                    width: 176,
                    height: 176,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox.expand(
                          child: CircularProgressIndicator(
                            value: stepsProgress,
                            strokeWidth: 12,
                            backgroundColor: _stroke,
                            color: _green,
                            strokeCap: StrokeCap.round,
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.directions_walk_rounded, color: Colors.white, size: 30),
                            const SizedBox(height: 6),
                            Text(_commas(h.steps), style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
                            Text('of ${_commas(controller.stepGoal)}', style: const TextStyle(color: _muted, fontSize: 11)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(child: _DashboardStat(icon: Icons.local_fire_department_rounded, color: _orange, value: h.activeCalories == null ? '—' : '${h.activeCalories!.round()}', label: 'Active Cal')),
                      Expanded(child: _DashboardStat(icon: Icons.location_on_rounded, color: _blue, value: h.distanceMeters == null || h.distanceMeters == 0 ? '—' : (h.distanceMeters! / 1609.344).toStringAsFixed(1), label: 'Distance (mi)')),
                      Expanded(child: _DashboardStat(icon: Icons.stairs_rounded, color: _green, value: h.flightsClimbed == null || h.flightsClimbed == 0 ? '—' : h.flightsClimbed!.round().toString(), label: 'Floors')),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.48,
            children: [
              _HomeTile(
                icon: Icons.favorite_rounded,
                color: _pink,
                title: 'Heart Rate',
                value: h.heartRate == null ? '— bpm' : '${h.heartRate!.round()} bpm',
                subtitle: h.restingHeartRate == null ? 'Latest reading' : 'Resting ${h.restingHeartRate!.round()} bpm',
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => HeartHealthScreen(controller: controller))),
              ),
              _HomeTile(
                icon: Icons.bedtime_rounded,
                color: _purple,
                title: 'Sleep',
                value: h.sleepMinutes == 0 ? '—' : '${sleepH}h ${sleepM}m',
                subtitle: 'Last session',
                onTap: () => goTab(2),
              ),
              _HomeTile(
                icon: Icons.monitor_weight_rounded,
                color: _green,
                title: 'Weight',
                value: '${controller.currentWeightLb.toStringAsFixed(1)} lb',
                subtitle: '${(controller.startWeightLb - controller.currentWeightLb).toStringAsFixed(1)} lb from start',
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => WeightGoalsScreen(controller: controller))),
              ),
              _HomeTile(
                icon: Icons.directions_run_rounded,
                color: _green,
                title: 'Activity',
                value: h.activeCalories == null ? '—' : '${h.activeCalories!.round()} cal',
                subtitle: 'Today',
                onTap: () => goTab(1),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _SuggestionPreview(controller: controller),
          if (!h.authorized || h.error != null) ...[
            const SizedBox(height: 12),
            Card(
              child: InkWell(
                onTap: controller.syncHealth,
                borderRadius: BorderRadius.circular(16),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      const CircleAvatar(backgroundColor: Color(0x2235BDF4), child: Icon(Icons.health_and_safety_rounded, color: _cyan)),
                      const SizedBox(width: 12),
                      Expanded(child: Text(h.error ?? 'Tap to connect Health Connect', style: const TextStyle(color: _muted))),
                      const Icon(Icons.chevron_right_rounded),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _DashboardStat extends StatelessWidget {
  const _DashboardStat({required this.icon, required this.color, required this.value, required this.label});
  final IconData icon;
  final Color color;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(radius: 18, backgroundColor: color.withOpacity(.12), child: Icon(icon, color: color, size: 20)),
        const SizedBox(height: 6),
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 1),
        Text(label, textAlign: TextAlign.center, style: const TextStyle(color: _muted, fontSize: 9)),
      ],
    );
  }
}

class _HomeTile extends StatelessWidget {
  const _HomeTile({required this.icon, required this.color, required this.title, required this.value, required this.subtitle, required this.onTap});
  final IconData icon;
  final Color color;
  final String title;
  final String value;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [Icon(icon, color: color, size: 22), const SizedBox(width: 7), Expanded(child: Text(title, style: const TextStyle(color: _muted, fontWeight: FontWeight.w800, fontSize: 11)))]),
              const Spacer(),
              Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(height: 2),
              Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _muted, fontSize: 9)),
            ],
          ),
        ),
      ),
    );
  }
}

class ActivityScreen extends StatefulWidget {
  const ActivityScreen({super.key, required this.controller, required this.onBack});
  final AppController controller;
  final VoidCallback onBack;

  @override
  State<ActivityScreen> createState() => _ActivityScreenState();
}

class _ActivityScreenState extends State<ActivityScreen> {
  int range = 0;

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    final progress = c.stepGoal <= 0 ? 0.0 : (c.health.steps / c.stepGoal).clamp(0.0, 1.0);
    return _ReferencePage(
      title: 'Activity',
      onBack: widget.onBack,
      menu: true,
      children: [
        _RangeTabs(labels: const ['Day', 'Week', 'Month', 'Year'], selected: range, onChanged: (v) => setState(() => range = v)),
        const SizedBox(height: 12),
        _DateStrip(label: _dateLabel()),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 16, 12, 10),
            child: SizedBox(height: 155, child: CustomPaint(painter: _BarChartPainter(c.health.hourlySteps, _cyan), child: const SizedBox.expand())),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.directions_walk_rounded, color: _cyan, size: 30),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Steps', style: TextStyle(color: _muted, fontSize: 11)), Text(_commas(c.health.steps), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900))])),
                    Text('of ${_commas(c.stepGoal)}', style: const TextStyle(color: _muted, fontSize: 10)),
                  ],
                ),
                const SizedBox(height: 10),
                LinearProgressIndicator(value: progress, minHeight: 11, borderRadius: BorderRadius.circular(8), backgroundColor: _stroke, color: _green),
                const SizedBox(height: 6),
                Align(alignment: Alignment.centerRight, child: Text('${(progress * 100).round()}%', style: const TextStyle(color: _muted, fontSize: 10))),
                const Divider(height: 22),
                Row(
                  children: [
                    Expanded(child: _MiniMetric(label: 'Distance', value: c.health.distanceMeters == null || c.health.distanceMeters == 0 ? '— mi' : '${(c.health.distanceMeters! / 1609.344).toStringAsFixed(1)} mi')),
                    Expanded(child: _MiniMetric(label: 'Active Calories', value: c.health.activeCalories == null ? '—' : '${c.health.activeCalories!.round()}')),
                    Expanded(child: _MiniMetric(label: 'Floors', value: c.health.flightsClimbed == null || c.health.flightsClimbed == 0 ? '—' : c.health.flightsClimbed!.round().toString())),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const Text('Workouts', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                const CircleAvatar(backgroundColor: Color(0x222BB9F3), child: Icon(Icons.location_on_rounded, color: _cyan)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(controller.health.workoutsToday == 0 ? 'No workout detected today' : '${controller.health.workoutsToday} workout${controller.health.workoutsToday == 1 ? '' : 's'} detected today', style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(controller.health.sources['Workouts'] == null ? 'Health Connect workout sessions will appear here when available.' : 'Source: ${_friendlySource(controller.health.sources['Workouts']!)}', style: const TextStyle(color: _muted, fontSize: 10))])),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => _showNotAvailable(context, 'Manual workout logging is next.'), icon: const Icon(Icons.add), label: const Text('Add Activity'))),
      ],
    );
  }
}

class SleepScreen extends StatefulWidget {
  const SleepScreen({super.key, required this.controller, required this.onBack});
  final AppController controller;
  final VoidCallback onBack;

  @override
  State<SleepScreen> createState() => _SleepScreenState();
}

class _SleepScreenState extends State<SleepScreen> {
  int range = 0;

  @override
  Widget build(BuildContext context) {
    final minutes = widget.controller.health.sleepMinutes;
    final hours = minutes ~/ 60;
    final mins = minutes % 60;
    final sleepMin = widget.controller.recommendedSleepMinMinutes;
    final progress = sleepMin == null || sleepMin <= 0 ? 0.0 : (minutes / sleepMin).clamp(0.0, 1.0);
    return _ReferencePage(
      title: 'Sleep',
      onBack: widget.onBack,
      menu: true,
      children: [
        _RangeTabs(labels: const ['Day', 'Week', 'Month', 'Year'], selected: range, onChanged: (v) => setState(() => range = v)),
        const SizedBox(height: 12),
        _DateStrip(label: _dateLabel()),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                SizedBox(
                  height: 190,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(width: 156, height: 156, child: CircularProgressIndicator(value: progress, strokeWidth: 15, backgroundColor: _stroke, color: _purple, strokeCap: StrokeCap.round)),
                      Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.bedtime_rounded, color: _purple, size: 28), const SizedBox(height: 8), Text(minutes == 0 ? '—' : '${hours}h ${mins}m', style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900)), const Text('Total Sleep', style: TextStyle(color: _muted, fontSize: 10)), const SizedBox(height: 4), Text(widget.controller.recommendedSleepRangeLabel, style: const TextStyle(color: _purple, fontSize: 9, fontWeight: FontWeight.w700))]),
                    ],
                  ),
                ),
                _SleepStageRow(label: 'REM', color: _purple, fraction: minutes <= 0 || widget.controller.health.sleepRemMinutes <= 0 ? null : widget.controller.health.sleepRemMinutes / minutes),
                _SleepStageRow(label: 'Light', color: _blue, fraction: minutes <= 0 || widget.controller.health.sleepLightMinutes <= 0 ? null : widget.controller.health.sleepLightMinutes / minutes),
                _SleepStageRow(label: 'Deep', color: const Color(0xFF4458D8), fraction: minutes <= 0 || widget.controller.health.sleepDeepMinutes <= 0 ? null : widget.controller.health.sleepDeepMinutes / minutes),
                const SizedBox(height: 7),
                Text(widget.controller.health.sleepRemMinutes + widget.controller.health.sleepLightMinutes + widget.controller.health.sleepDeepMinutes == 0 ? 'Stage detail is not currently shared by this Health Connect source.' : 'Stage values shown from the connected source when available.', style: const TextStyle(color: _muted, fontSize: 9)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [Expanded(child: Text('Sleep Stages', style: TextStyle(fontWeight: FontWeight.w900))), Text('Last session', style: TextStyle(color: _muted, fontSize: 9))]),
              const SizedBox(height: 14),
              Container(height: 90, decoration: BoxDecoration(color: const Color(0xFF071E2A), borderRadius: BorderRadius.circular(10)), child: Center(child: Text(widget.controller.health.sleepRemMinutes + widget.controller.health.sleepLightMinutes + widget.controller.health.sleepDeepMinutes == 0 ? 'Detailed stage timeline unavailable' : 'REM ${_durationLabel(widget.controller.health.sleepRemMinutes)}  •  Light ${_durationLabel(widget.controller.health.sleepLightMinutes)}  •  Deep ${_durationLabel(widget.controller.health.sleepDeepMinutes)}', textAlign: TextAlign.center, style: const TextStyle(color: _muted, fontSize: 10)))),
            ]),
          ),
        ),
      ],
    );
  }
}

class HeartHealthScreen extends StatefulWidget {
  const HeartHealthScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<HeartHealthScreen> createState() => _HeartHealthScreenState();
}

class _HeartHealthScreenState extends State<HeartHealthScreen> {
  int range = 0;

  @override
  Widget build(BuildContext context) {
    final h = widget.controller.health;
    final samples = h.heartSamples;
    final values = samples.map((e) => e.value).toList();
    final avg = values.isEmpty ? null : values.reduce((a, b) => a + b) / values.length;
    final high = values.isEmpty ? null : values.reduce((a, b) => a > b ? a : b);
    final low = values.isEmpty ? null : values.reduce((a, b) => a < b ? a : b);
    return _DetailScaffold(
      title: 'Heart Health',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 22),
        children: [
          _RangeTabs(labels: const ['Day', 'Week', 'Month', 'Year'], selected: range, onChanged: (v) => setState(() => range = v)),
          const SizedBox(height: 12),
          _DateStrip(label: _dateLabel()),
          const SizedBox(height: 14),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.favorite_rounded, color: _pink, size: 28), const SizedBox(width: 8), Text(h.heartRate == null ? '—' : '${h.heartRate!.round()}', style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w900)), const SizedBox(width: 4), const Text('bpm', style: TextStyle(color: _muted, fontWeight: FontWeight.w700))]),
          const Center(child: Text('Latest Heart Rate', style: TextStyle(color: _muted, fontSize: 10))),
          const SizedBox(height: 14),
          Card(child: Padding(padding: const EdgeInsets.all(12), child: SizedBox(height: 180, child: CustomPaint(painter: _LineChartPainter(samples.map((e) => e.value).toList(), _pink), child: const SizedBox.expand())))),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _MetricBox(label: 'Average HR', value: avg == null ? '—' : '${avg.round()} bpm')),
            const SizedBox(width: 8),
            Expanded(child: _MetricBox(label: 'Highest HR', value: high == null ? '—' : '${high.round()} bpm')),
            const SizedBox(width: 8),
            Expanded(child: _MetricBox(label: 'Lowest HR', value: low == null ? '—' : '${low.round()} bpm')),
          ]),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Heart Rate Zones (Today)', style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                _ZoneRow(label: 'Zone 5', color: _pink, fraction: _zoneFraction(values, 150, 999)),
                _ZoneRow(label: 'Zone 4', color: Color(0xFFFF7849), fraction: _zoneFraction(values, 130, 149.999)),
                _ZoneRow(label: 'Zone 3', color: _orange, fraction: _zoneFraction(values, 110, 129.999)),
                _ZoneRow(label: 'Zone 2', color: _cyan, fraction: _zoneFraction(values, 90, 109.999)),
                _ZoneRow(label: 'Zone 1', color: _blue, fraction: _zoneFraction(values, 0, 89.999)),
                const SizedBox(height: 6),
                const Text('Zones are grouped from available heart-rate samples and are not a medical training prescription.', style: TextStyle(color: _muted, fontSize: 8)),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class WeightGoalsScreen extends StatefulWidget {
  const WeightGoalsScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<WeightGoalsScreen> createState() => _WeightGoalsScreenState();
}

class _WeightGoalsScreenState extends State<WeightGoalsScreen> {
  int tab = 0;
  int range = 1;

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    final weightHistory = c.health.weightHistory.map((e) => e.value).toList();
    final lost = c.startWeightLb - c.currentWeightLb;
    final toGo = (c.currentWeightLb - c.goalWeightLb).clamp(0.0, double.infinity);
    return _DetailScaffold(
      title: 'Weight & Goals',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 22),
        children: [
          _RangeTabs(labels: const ['Weight', 'Calories', 'Goals'], selected: tab, onChanged: (v) => setState(() => tab = v)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _MetricBox(label: 'Current Weight', value: '${c.currentWeightLb.toStringAsFixed(1)} lb', subvalue: lost >= 0 ? '-${lost.toStringAsFixed(1)} lb' : '+${(-lost).toStringAsFixed(1)} lb', accent: lost >= 0 ? _green : _orange)),
            const SizedBox(width: 8),
            Expanded(child: _MetricBox(label: 'Goal', value: '${c.goalWeightLb.toStringAsFixed(0)} lb', subvalue: '${toGo.toStringAsFixed(1)} lb to go')),
          ]),
          const SizedBox(height: 10),
          _RangeTabs(labels: const ['1W', '1M', '3M', '6M', '1Y', 'ALL'], selected: range, onChanged: (v) => setState(() => range = v), compact: true),
          const SizedBox(height: 10),
          Card(child: Padding(padding: const EdgeInsets.all(12), child: SizedBox(height: 190, child: CustomPaint(painter: _LineChartPainter(weightHistory, _green), child: weightHistory.isEmpty ? const Center(child: Text('Sync weight history from Health Connect', style: TextStyle(color: _muted, fontSize: 10))) : const SizedBox.expand())))),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Body Composition', style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: _CompositionTile(icon: Icons.monitor_weight_rounded, color: _green, label: 'Weight', value: '${c.currentWeightLb.toStringAsFixed(1)} lb')),
                  const SizedBox(width: 8),
                  Expanded(child: _CompositionTile(icon: Icons.water_drop_rounded, color: _blue, label: 'Body Fat', value: c.bodyFatPercent == null ? 'No device data' : '${c.bodyFatPercent!.toStringAsFixed(1)}%')),
                ]),
                if (c.health.bodyMassIndex != null || c.health.bodyWaterKg != null) ...[
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: _CompositionTile(icon: Icons.analytics_outlined, color: _cyan, label: 'BMI', value: c.health.bodyMassIndex == null ? 'No device data' : c.health.bodyMassIndex!.toStringAsFixed(1))),
                    const SizedBox(width: 8),
                    Expanded(child: _CompositionTile(icon: Icons.water_drop_outlined, color: _blue, label: 'Body Water', value: c.health.bodyWaterKg == null ? 'No device data' : '${(c.health.bodyWaterKg! * 2.2046226218).toStringAsFixed(1)} lb')),
                  ]),
                ],
              ]),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => _logWeightDialog(context, c), icon: const Icon(Icons.add), label: const Text('Log Weight'))),
        ],
      ),
    );
  }
}

class BodyMetricsScreen extends StatefulWidget {
  const BodyMetricsScreen({super.key, required this.controller, required this.onBack});
  final AppController controller;
  final VoidCallback onBack;

  @override
  State<BodyMetricsScreen> createState() => _BodyMetricsScreenState();
}

class _BodyMetricsScreenState extends State<BodyMetricsScreen> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final labels = const ['Measurements', 'Photos', 'History'];
    return _ReferencePage(
      title: 'Body Metrics',
      onBack: widget.onBack,
      menu: true,
      children: [
        _RangeTabs(labels: labels, selected: tab, onChanged: (v) => setState(() => tab = v)),
        const SizedBox(height: 12),
        if (tab == 0) _buildMeasurements(context),
        if (tab == 1) _buildPhotos(context),
        if (tab == 2) _buildHistory(context),
      ],
    );
  }

  Widget _buildMeasurements(BuildContext context) {
    final c = widget.controller;
    return Column(
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 12, 8, 10),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.asset(
                    'lib/assets/images/body_metrics_reference.png',
                    height: 292,
                    width: double.infinity,
                    fit: BoxFit.contain,
                    filterQuality: FilterQuality.high,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Measurement map',
                  style: TextStyle(color: _muted, fontSize: 9, fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                Row(children: [const Expanded(child: Text('Latest Measurements', style: TextStyle(fontWeight: FontWeight.w900))), Text(_shortDate(DateTime.now()), style: const TextStyle(color: _muted, fontSize: 9))]),
                const SizedBox(height: 8),
                _BodyRow(label: 'Weight', value: '${c.currentWeightLb.toStringAsFixed(1)} lb', color: _green, onTap: () => _logWeightDialog(context, c)),
                _BodyRow(label: 'Body Fat', value: c.bodyFatPercent == null ? 'No device data' : '${c.bodyFatPercent!.toStringAsFixed(1)}%', color: _green, onTap: () => _showNotAvailable(context, 'Body fat is read from a connected body-composition source.')),
                ...c.measurements.entries.map((e) => _BodyRow(label: e.key, value: e.value <= 0 ? 'Not set' : '${e.value.toStringAsFixed(1)} in', color: _measureColor(e.key), onTap: () => _measurementDialog(context, c, e.key, e.value))),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPhotos(BuildContext context) {
    final groups = _photoGroups(widget.controller.photos);
    return Column(
      children: [
        if (groups.isEmpty)
          Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [const Icon(Icons.photo_library_outlined, color: _muted, size: 38), const SizedBox(height: 10), const Text('No progress photos yet', style: TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), const Text('Add front, side and back photos to compare changes over time.', textAlign: TextAlign.center, style: TextStyle(color: _muted, fontSize: 10)), const SizedBox(height: 16), _AddPhotosButton(controller: widget.controller)]))),
        ...groups.entries.map((entry) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [Expanded(child: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w800)))]),
                    const SizedBox(height: 8),
                    Row(children: ['Front', 'Side', 'Back'].map((view) {
                      final item = entry.value.where((p) => p['view'] == view).firstOrNull;
                      return Expanded(child: Padding(padding: EdgeInsets.only(right: view == 'Back' ? 0 : 7), child: _PhotoSlot(item: item, label: view)));
                    }).toList()),
                  ]),
                ),
              ),
            )),
        if (groups.isNotEmpty) _AddPhotosButton(controller: widget.controller),
      ],
    );
  }

  Widget _buildHistory(BuildContext context) {
    final rows = widget.controller.measurements.entries.where((e) => e.value > 0).toList();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Measurement History', style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('History starts building as you update measurements.', style: TextStyle(color: _muted, fontSize: 10)),
          const SizedBox(height: 12),
          if (rows.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(20), child: Text('No measurements logged yet', style: TextStyle(color: _muted)))),
          ...rows.map((e) => ListTile(contentPadding: EdgeInsets.zero, dense: true, leading: CircleAvatar(radius: 5, backgroundColor: _measureColor(e.key)), title: Text(e.key), trailing: Text('${e.value.toStringAsFixed(1)} in', style: const TextStyle(fontWeight: FontWeight.w800)))),
        ]),
      ),
    );
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final TextEditingController name;
  late final TextEditingController birthday;
  late final TextEditingController height;
  late final TextEditingController startWeight;
  late final TextEditingController goalWeight;
  late final TextEditingController startDate;
  late String sex;
  late String units;
  late String activity;

  @override
  void initState() {
    super.initState();
    final c = widget.controller;
    name = TextEditingController(text: c.name);
    birthday = TextEditingController(text: c.birthday);
    height = TextEditingController(text: c.heightIn.toStringAsFixed(0));
    startWeight = TextEditingController(text: c.startWeightLb.toStringAsFixed(0));
    goalWeight = TextEditingController(text: c.goalWeightLb.toStringAsFixed(0));
    startDate = TextEditingController(text: c.startDate);
    sex = c.sex.isEmpty ? 'Male' : c.sex;
    units = c.units;
    activity = c.activityLevel;
  }

  @override
  Widget build(BuildContext context) {
    return _DetailScaffold(
      title: 'My Profile',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          const Center(child: CircleAvatar(radius: 38, backgroundColor: Color(0xFF2D6688), child: Icon(Icons.person_rounded, size: 54, color: Color(0xFF9FC5DA)))),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Column(children: [
                _ProfileEditRow(label: 'Name', child: TextField(controller: name, textAlign: TextAlign.right, decoration: const InputDecoration(border: InputBorder.none, filled: false, isDense: true))),
                _ProfileEditRow(label: 'Birthday', child: TextField(controller: birthday, textAlign: TextAlign.right, decoration: const InputDecoration(border: InputBorder.none, filled: false, hintText: 'MM/DD/YYYY', isDense: true))),
                _ProfileEditRow(label: 'Sex', child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: sex, items: const ['Male', 'Female', 'Other'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => sex = v ?? sex)))),
                _ProfileEditRow(label: 'Height', child: SizedBox(width: 100, child: TextField(controller: height, keyboardType: TextInputType.number, textAlign: TextAlign.right, decoration: const InputDecoration(border: InputBorder.none, filled: false, suffixText: 'in', isDense: true)))),
                _ProfileEditRow(label: 'Start Date', child: SizedBox(width: 125, child: TextField(controller: startDate, textAlign: TextAlign.right, decoration: const InputDecoration(border: InputBorder.none, filled: false, isDense: true)))),
                _ProfileEditRow(label: 'Start Weight', child: SizedBox(width: 100, child: TextField(controller: startWeight, keyboardType: TextInputType.number, textAlign: TextAlign.right, decoration: const InputDecoration(border: InputBorder.none, filled: false, suffixText: 'lb', isDense: true)))),
                _ProfileEditRow(label: 'Goal Weight', child: SizedBox(width: 100, child: TextField(controller: goalWeight, keyboardType: TextInputType.number, textAlign: TextAlign.right, decoration: const InputDecoration(border: InputBorder.none, filled: false, suffixText: 'lb', isDense: true)))),
                _ProfileEditRow(label: 'Units', child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: units, items: const ['lb/in', 'kg/cm'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => units = v ?? units)))),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Additional Info', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Column(children: [
                _ProfileEditRow(label: 'Activity Level', child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: activity, items: const ['Sedentary', 'Lightly Active', 'Moderately Active', 'Very Active'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => activity = v ?? activity)))),
                const _ProfileValueRow(label: 'Time Zone', value: 'Device default'),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_rounded), label: const Text('Save Profile'))),
        ],
      ),
    );
  }

  Future<void> _save() async {
    await widget.controller.saveProfile(
      newName: name.text,
      newSex: sex,
      newBirthday: birthday.text,
      newStartDate: startDate.text,
      newUnits: units,
      newActivityLevel: activity,
      newHeight: double.tryParse(height.text) ?? widget.controller.heightIn,
      newStart: double.tryParse(startWeight.text) ?? widget.controller.startWeightLb,
      newGoal: double.tryParse(goalWeight.text) ?? widget.controller.goalWeightLb,
    );
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile saved')));
  }
}

class DevicesSourcesScreen extends StatelessWidget {
  const DevicesSourcesScreen({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final grouped = <String, List<String>>{};
    for (final raw in controller.health.providerMetrics.keys) {
      final friendly = _friendlySource(raw);
      if (friendly == 'Health Connect' || friendly == 'Unknown source') continue;
      grouped.putIfAbsent(friendly, () => <String>[]).add(raw);
    }
    final providers = grouped.keys.toList()..sort();

    final priorityMetrics = <String>{'Steps', 'Heart Rate', 'Sleep', 'Weight'};
    for (final entry in controller.health.availableSources.entries) {
      if (entry.value.isNotEmpty) priorityMetrics.add(entry.key);
    }
    final sortedMetrics = priorityMetrics.toList()..sort((a, b) {
      const order = ['Steps', 'Distance', 'Workouts', 'Heart Rate', 'Resting Heart Rate', 'HRV', 'Blood Oxygen', 'Respiratory Rate', 'Sleep', 'Deep Sleep', 'Light Sleep', 'REM Sleep', 'Active Calories', 'Weight', 'Body Fat', 'BMI', 'Body Water', 'Flights Climbed'];
      final ai = order.indexOf(a);
      final bi = order.indexOf(b);
      if (ai < 0 && bi < 0) return a.compareTo(b);
      if (ai < 0) return 1;
      if (bi < 0) return -1;
      return ai.compareTo(bi);
    });

    return _DetailScaffold(
      title: 'Devices & Sources',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: _green)),
            child: InkWell(
              onTap: controller.syncHealth,
              borderRadius: BorderRadius.circular(14),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(children: [const CircleAvatar(radius: 16, backgroundColor: Color(0x224BE39E), child: Icon(Icons.sync_rounded, color: _green, size: 18)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(controller.health.authorized ? 'Health Connect ready' : 'Connect Health Connect', style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text(controller.syncing ? 'Syncing now…' : 'Tap to refresh data and detect sources', style: const TextStyle(color: _muted, fontSize: 9))])), const Icon(Icons.sync_rounded, color: _green, size: 18)]),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Detected providers', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const SizedBox(height: 4),
          const Text('Providers appear only when Healthy Me actually finds data from them.', style: TextStyle(color: _muted, fontSize: 9)),
          const SizedBox(height: 8),
          ...providers.map((provider) {
            final rawSources = grouped[provider] ?? const <String>[];
            final metrics = <String>{};
            for (final raw in rawSources) {
              metrics.addAll(controller.health.providerMetrics[raw] ?? const <String>[]);
            }
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _DeviceCard(
                icon: _sourceIcon(provider),
                iconColor: _sourceColor(provider),
                title: provider,
                status: 'Detected through Health Connect',
                detailText: metrics.isEmpty ? 'Data source detected' : (metrics.toList()..sort()).join(', '),
                active: true,
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProviderDetailScreen(controller: controller, provider: provider, rawSources: rawSources))),
              ),
            );
          }),
          if (providers.isEmpty)
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: _DeviceCard(icon: Icons.watch_rounded, iconColor: _muted, title: 'Wearables & health apps', status: 'No provider detected yet', detailText: 'Sync after your watch or health app writes data to Health Connect.', active: false),
            ),
          _DeviceCard(
            icon: Icons.favorite_outline_rounded,
            iconColor: _blue,
            title: 'Health Connect',
            status: controller.health.authorized ? 'Connected' : 'Permission needed',
            detailText: 'Central Android health-data layer',
            active: controller.health.authorized,
            onTap: controller.syncHealth,
          ),
          const SizedBox(height: 8),
          _DeviceCard(
            icon: Icons.air_rounded,
            iconColor: _muted,
            title: 'CPAP (Coming Soon)',
            status: 'Not connected',
            detailText: 'Reserved connector for sleep, AHI, usage and leak data.',
            active: false,
            showPlus: true,
            onTap: () => _showInfoSheet(context, 'CPAP connector', 'CPAP remains reserved until the exact machine/app connection is known. Healthy Me will not pretend a device is connected when it is not.'),
          ),
          const SizedBox(height: 8),
          const _DeviceCard(icon: Icons.edit_note_rounded, iconColor: _pink, title: 'Manual Entries', status: 'Active', detailText: 'Weight, body measurements and bloodwork', active: true),
          const SizedBox(height: 14),
          Row(children: [const Expanded(child: Text('Metric source priority', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14))), Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: _green.withOpacity(.12), borderRadius: BorderRadius.circular(20)), child: const Text('DYNAMIC', style: TextStyle(color: _green, fontSize: 8, fontWeight: FontWeight.w900)))]),
          const SizedBox(height: 4),
          const Text('Auto / Recommended first, then only providers detected for that exact metric.', style: TextStyle(color: _muted, fontSize: 9)),
          const SizedBox(height: 8),
          ...sortedMetrics.map((metric) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _SourcePriorityRow(controller: controller, metric: metric))),
        ],
      ),
    );
  }
}

class ProviderDetailScreen extends StatelessWidget {
  const ProviderDetailScreen({super.key, required this.controller, required this.provider, required this.rawSources});
  final AppController controller;
  final String provider;
  final List<String> rawSources;

  @override
  Widget build(BuildContext context) {
    final metrics = <String>{};
    DateTime? lastSeen;
    for (final raw in rawSources) {
      metrics.addAll(controller.health.providerMetrics[raw] ?? const <String>[]);
      final seen = controller.health.providerLastSeen[raw];
      if (seen != null && (lastSeen == null || seen.isAfter(lastSeen))) lastSeen = seen;
    }
    final sorted = metrics.toList()..sort();
    return _DetailScaffold(
      title: provider,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [CircleAvatar(radius: 24, backgroundColor: _sourceColor(provider).withOpacity(.12), child: Icon(_sourceIcon(provider), color: _sourceColor(provider))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Connection status', style: TextStyle(color: _muted, fontSize: 9)), const SizedBox(height: 2), const Text('Detected through Health Connect', style: TextStyle(color: _green, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(lastSeen == null ? 'No recent timestamp available' : 'Last data received ${_relativeTime(lastSeen!)}', style: const TextStyle(color: _muted, fontSize: 9))]))]))),
          const SizedBox(height: 10),
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [const Icon(Icons.health_and_safety_rounded, color: _cyan), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Health Connect permission', style: TextStyle(fontWeight: FontWeight.w900)), Text(controller.health.authorized ? 'Healthy Me can read authorized health data.' : 'Permission is still needed.', style: TextStyle(color: controller.health.authorized ? _green : _pink, fontSize: 9))]))]))),
          const SizedBox(height: 14),
          const Text('Metrics received from this provider', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const SizedBox(height: 4),
          const Text('Only metrics with actual records are listed here.', style: TextStyle(color: _muted, fontSize: 9)),
          const SizedBox(height: 8),
          if (sorted.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('No metric records detected yet.', style: TextStyle(color: _muted))))
          else
            ...sorted.map((metric) {
              final rawSelected = controller.health.sources[metric];
              final selectedHere = rawSelected != null && rawSources.any((raw) => raw.toLowerCase() == rawSelected.toLowerCase());
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: Icon(_metricIcon(metric), color: _metricColor(metric)),
                  title: Text(metric, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(selectedHere ? 'Currently selected for this metric' : 'Available as a source', style: TextStyle(color: selectedHere ? _green : _muted, fontSize: 9)),
                  trailing: selectedHere ? const Icon(Icons.check_circle_rounded, color: _green) : null,
                ),
              );
            }),
          const SizedBox(height: 6),
          SizedBox(width: double.infinity, child: FilledButton.tonalIcon(onPressed: controller.syncHealth, icon: const Icon(Icons.sync_rounded), label: const Text('Refresh Health Connect data'))),
        ],
      ),
    );
  }
}

class GuidanceScreen extends StatelessWidget {
  const GuidanceScreen({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final suggestions = controller.suggestions;
    return _DetailScaffold(
      title: 'Suggestions',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('Healthy Me uses the data you have available to suggest practical next steps. These are wellness suggestions, not medical treatment.', style: TextStyle(color: _muted, fontSize: 10, height: 1.4)))),
          const SizedBox(height: 10),
          ...suggestions.map((item) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _SuggestionCard(suggestion: item))),
          const SizedBox(height: 8),
          const Text('Suggestions become more specific as Healthy Me gets consistent weight, activity, sleep, workout and nutrition data.', style: TextStyle(color: _muted, fontSize: 9, height: 1.4)),
        ],
      ),
    );
  }
}

class GoalsProgressScreen extends StatelessWidget {
  const GoalsProgressScreen({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final sleep = c.health.sleepMinutes;
    return _DetailScaffold(
      title: 'Goals & Progress',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          const _RangeTabs(labels: ['Goals', 'Progress', 'Insights'], selected: 0, onChanged: null),
          const SizedBox(height: 12),
          _GoalCard(icon: Icons.monitor_weight_rounded, color: _cyan, title: 'Weight Goal', progress: c.goalProgress, line1: '${c.currentWeightLb.toStringAsFixed(1)} / ${c.goalWeightLb.toStringAsFixed(0)} lb', line2: '${(c.currentWeightLb - c.goalWeightLb).clamp(0.0, double.infinity).toStringAsFixed(1)} lb to go'),
          const SizedBox(height: 8),
          _GoalCard(icon: Icons.directions_walk_rounded, color: _green, title: 'Steps Goal', progress: c.stepGoal <= 0 ? 0 : (c.health.steps / c.stepGoal).clamp(0.0, 1.0), line1: '${_commas(c.health.steps)} / ${_commas(c.stepGoal)}', line2: '${(c.stepGoal <= 0 ? 0 : c.health.steps / c.stepGoal * 100).clamp(0, 100).round()}%'),
          const SizedBox(height: 8),
          _GoalCard(icon: Icons.bedtime_rounded, color: _purple, title: 'Sleep Recommendation', progress: c.recommendedSleepMinMinutes == null ? 0 : (sleep / c.recommendedSleepMinMinutes!).clamp(0.0, 1.0), line1: '${_durationLabel(sleep)} • ${c.recommendedSleepRangeLabel}', line2: c.recommendedSleepMinMinutes == null ? 'Add birthday in Profile' : (sleep < c.recommendedSleepMinMinutes! ? 'Below recommended range' : (sleep > c.recommendedSleepMaxMinutes! ? 'Above recommended range' : 'Within recommended range'))),
          const SizedBox(height: 8),
          _GoalCard(icon: Icons.directions_run_rounded, color: _orange, title: 'Workout Goal', progress: c.workoutGoal <= 0 ? 0 : (c.health.workoutsThisWeek / c.workoutGoal).clamp(0.0, 1.0), line1: '${c.health.workoutsThisWeek} / ${c.workoutGoal} this week', line2: c.health.sources['Workouts'] == null ? 'Waiting for workout data' : _friendlySource(c.health.sources['Workouts']!)),
          const SizedBox(height: 8),
          _GoalCard(icon: Icons.accessibility_new_rounded, color: _purple, title: 'Body Fat Goal', progress: c.bodyFatPercent == null ? 0 : (1 - ((c.bodyFatPercent! - c.bodyFatGoal).abs() / 20)).clamp(0.0, 1.0), line1: c.bodyFatPercent == null ? 'Waiting for body-composition data' : '${c.bodyFatPercent!.toStringAsFixed(1)}% → ${c.bodyFatGoal.toStringAsFixed(0)}%', line2: c.bodyFatPercent == null ? 'Connect a compatible scale/source' : 'Goal ${c.bodyFatGoal.toStringAsFixed(0)}%'),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => _goalDialog(context, c), icon: const Icon(Icons.add), label: const Text('Edit Goals'))),
        ],
      ),
    );
  }
}

class BloodworkScreen extends StatefulWidget {
  const BloodworkScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<BloodworkScreen> createState() => _BloodworkScreenState();
}

class _BloodworkScreenState extends State<BloodworkScreen> {
  int selected = 0;
  static const tabs = ['Lifestyle', 'Hormones & Performance', 'All Results', 'History'];

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (context, _) {
        final c = widget.controller;
        final allRows = c.bloodworkWithDerived;
        final rows = switch (selected) {
          0 => allRows.where((row) => _isLifestyleTest(row['test'] ?? '')).toList(),
          1 => allRows.where((row) => _isHormoneTest(row['test'] ?? '')).toList(),
          2 => allRows,
          _ => allRows,
        };
        return _DetailScaffold(
          title: 'Bloodwork & Biomarkers',
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Row(children: [CircleAvatar(backgroundColor: Color(0x22FF5E73), child: Icon(Icons.science_rounded, color: _pink)), SizedBox(width: 10), Expanded(child: Text('Wellness context, not treatment', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)))]),
                    const SizedBox(height: 8),
                    const Text('Healthy Me keeps the lab value, units, date, source and the lab\'s reference range when supplied. It emphasizes trends and context instead of diagnosing from one result.', style: TextStyle(color: _muted, fontSize: 10, height: 1.4)),
                  ]),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 38,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: tabs.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 6),
                  itemBuilder: (context, index) => ChoiceChip(
                    label: Text(tabs[index], style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800)),
                    selected: selected == index,
                    onSelected: (_) => setState(() => selected = index),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _openAddMenu, icon: const Icon(Icons.add_rounded), label: const Text('Add Bloodwork'))),
              if (selected == 1 && c.sex.trim().toLowerCase().startsWith('f')) ...[
                const SizedBox(height: 10),
                Card(
                  child: InkWell(
                    onTap: _editHormoneContext,
                    borderRadius: BorderRadius.circular(16),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Row(children: [const Icon(Icons.tune_rounded, color: _purple), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Hormone context', style: TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text('${c.hormoneContext}${c.cycleDay.isEmpty ? '' : ' • cycle day ${c.cycleDay}'}', style: const TextStyle(color: _muted, fontSize: 9))])), const Icon(Icons.chevron_right_rounded, color: _muted)]),
                    ),
                  ),
                ),
              ],
              if (selected == 1) ...[
                const SizedBox(height: 10),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(c.sex.trim().isEmpty ? 'Suggested hormone panel' : 'Suggested for ${c.sex.trim()} profile', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
                      const SizedBox(height: 4),
                      const Text('These are suggested tests to organize if you already have results. Healthy Me does not diagnose hormone conditions.', style: TextStyle(color: _muted, fontSize: 9, height: 1.35)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 6, runSpacing: 6, children: c.suggestedHormoneTests.take(10).map((test) => Chip(label: Text(test, style: const TextStyle(fontSize: 8)), visualDensity: VisualDensity.compact)).toList()),
                    ]),
                  ),
                ),
              ],
              const SizedBox(height: 12),
              if (selected == 3)
                ..._historyCards(allRows)
              else if (rows.isEmpty)
                Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [const Icon(Icons.biotech_outlined, color: _muted, size: 36), const SizedBox(height: 8), Text(selected == 0 ? 'No lifestyle biomarkers yet' : selected == 1 ? 'No hormone or performance biomarkers yet' : 'No bloodwork entered yet', style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), const Text('Import an XLSX/CSV file, enter a result manually, or choose a common test.', textAlign: TextAlign.center, style: TextStyle(color: _muted, fontSize: 10))])))
              else
                ...rows.map((row) => _LabResultCard(row: row)),
              const SizedBox(height: 8),
              if (selected == 0)
                const Text('Lifestyle markers are prioritized when they can reasonably inform wellness coaching. Thyroid, iron and vitamin data are context—not targets to “fix” with exercise alone.', style: TextStyle(color: _muted, fontSize: 9, height: 1.4)),
              if (selected == 1)
                const Text('Hormone results can affect recovery, energy and body-composition context. Healthy Me will not claim that a food or workout “fixes” a hormone result.', style: TextStyle(color: _muted, fontSize: 9, height: 1.4)),
            ],
          ),
        );
      },
    );
  }

  List<Widget> _historyCards(List<Map<String, String>> rows) {
    final groups = <String, List<Map<String, String>>>{};
    for (final row in rows.where((row) => row['derived'] != 'true')) {
      final key = normalizeBiomarkerName(row['test'] ?? '');
      if (key.isEmpty) continue;
      groups.putIfAbsent(key, () => <Map<String, String>>[]).add(row);
    }
    final names = groups.keys.toList()..sort();
    if (names.isEmpty) {
      return const [Card(child: Padding(padding: EdgeInsets.all(22), child: Text('Add at least one lab result to begin history tracking.', textAlign: TextAlign.center, style: TextStyle(color: _muted))))];
    }
    return names.map((name) {
      final items = groups[name]!;
      final latest = items.first;
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              const CircleAvatar(radius: 18, backgroundColor: Color(0x222BB9F3), child: Icon(Icons.show_chart_rounded, color: _cyan, size: 18)),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text('${items.length} result${items.length == 1 ? '' : 's'} • latest ${latest['date'] ?? ''}', style: const TextStyle(color: _muted, fontSize: 9))])),
              Text('${latest['result'] ?? ''}${(latest['units'] ?? '').isEmpty ? '' : ' ${latest['units']}'}', style: const TextStyle(fontWeight: FontWeight.w900)),
            ]),
          ),
        ),
      );
    }).toList();
  }

  Future<void> _openAddMenu() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surface,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Align(alignment: Alignment.centerLeft, child: Text('Add Bloodwork', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
            const SizedBox(height: 8),
            ListTile(leading: const CircleAvatar(backgroundColor: Color(0x2235BDF4), child: Icon(Icons.upload_file_rounded, color: _cyan)), title: const Text('Import file'), subtitle: const Text('XLSX or CSV • preview before saving', style: TextStyle(color: _muted, fontSize: 9)), onTap: () { Navigator.of(sheetContext).pop(); Future<void>.delayed(Duration.zero, _importFile); }),
            ListTile(leading: const CircleAvatar(backgroundColor: Color(0x224BE39E), child: Icon(Icons.edit_rounded, color: _green)), title: const Text('Enter manually'), subtitle: const Text('Test, value, units, date, lab and optional reference range', style: TextStyle(color: _muted, fontSize: 9)), onTap: () { Navigator.of(sheetContext).pop(); Future<void>.delayed(Duration.zero, () async { _bloodworkDialog(context, widget.controller); }); }),
            ListTile(leading: const CircleAvatar(backgroundColor: Color(0x228D68F6), child: Icon(Icons.checklist_rounded, color: _purple)), title: const Text('Choose common tests'), subtitle: const Text('Lifestyle plus profile-aware hormone suggestions', style: TextStyle(color: _muted, fontSize: 9)), onTap: () { Navigator.of(sheetContext).pop(); Future<void>.delayed(Duration.zero, _chooseCommonTest); }),
          ]),
        ),
      ),
    );
  }

  Future<void> _importFile() async {
    try {
      final batch = await widget.controller.pickBloodworkFile();
      if (!mounted || batch == null) return;
      final save = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Import Preview'),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text(batch.fileName, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text('${batch.rows.length} results • ${batch.recognizedCount} recognized', style: const TextStyle(color: _muted, fontSize: 10)),
                Text('${batch.lifestyleCount} Lifestyle • ${batch.hormoneCount} Hormones/Performance • ${batch.otherCount} Other', style: const TextStyle(color: _muted, fontSize: 10)),
                if (batch.dates.isNotEmpty) Text('Dates: ${batch.dates.take(3).join(', ')}', style: const TextStyle(color: _muted, fontSize: 9)),
                if (batch.sources.isNotEmpty) Text('Source: ${batch.sources.take(2).join(', ')}', style: const TextStyle(color: _muted, fontSize: 9)),
                const Divider(height: 22),
                ...batch.rows.take(8).map((row) => Padding(padding: const EdgeInsets.only(bottom: 6), child: Row(children: [Expanded(child: Text(row['test'] ?? '', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800))), Text('${row['result'] ?? ''}${(row['units'] ?? '').isEmpty ? '' : ' ${row['units']}'}', style: const TextStyle(fontSize: 10))]))),
                if (batch.rows.length > 8) Text('+ ${batch.rows.length - 8} more results', style: const TextStyle(color: _muted, fontSize: 9)),
              ]),
            ),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Import'))],
        ),
      );
      if (save == true) {
        await widget.controller.addImportedBloodwork(batch);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${batch.rows.length} lab results imported')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Import failed: $e')));
    }
  }

  Future<void> _chooseCommonTest() async {
    const lifestyle = ['A1C', 'Fasting Glucose', 'Total Cholesterol', 'LDL Cholesterol', 'HDL Cholesterol', 'Triglycerides', 'ApoB', 'ALT', 'AST', 'GGT', 'hs-CRP', 'TSH', 'Vitamin D', 'Vitamin B12', 'Ferritin'];
    final options = <String>{...lifestyle, ...widget.controller.suggestedHormoneTests}.toList();
    final chosen = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _surface,
      showDragHandle: true,
      builder: (context) => SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(14, 0, 14, 20), children: [const Text('Choose a common test', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), const SizedBox(height: 8), ...options.map((test) => ListTile(title: Text(test), subtitle: Text(_isHormoneTest(test) ? 'Hormones & Performance' : 'Lifestyle', style: const TextStyle(color: _muted, fontSize: 9)), trailing: const Icon(Icons.add_rounded), onTap: () => Navigator.pop(context, test)))])),
    );
    if (!mounted || chosen == null) return;
    _bloodworkDialog(context, widget.controller, initialTest: chosen);
  }

  Future<void> _editHormoneContext() async {
    var selectedContext = widget.controller.hormoneContext;
    final cycle = TextEditingController(text: widget.controller.cycleDay);
    const options = ['Regular menstrual cycles', 'Irregular cycles', 'Hormonal contraception', 'Pregnant', 'Postpartum', 'Perimenopause', 'Menopause', 'Prefer not to specify'];
    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
        title: const Text('Hormone context'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(value: options.contains(selectedContext) ? selectedContext : 'Prefer not to specify', items: options.map((value) => DropdownMenuItem(value: value, child: Text(value))).toList(), onChanged: (value) { if (value != null) setLocal(() => selectedContext = value); }, decoration: const InputDecoration(labelText: 'Context')),
          const SizedBox(height: 8),
          TextField(controller: cycle, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cycle day (optional)')),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save'))],
      )),
    );
    if (saved == true) await widget.controller.saveHormoneContext(selectedContext, cycle.text);
  }
}

class _LabResultCard extends StatelessWidget {
  const _LabResultCard({required this.row});
  final Map<String, String> row;

  @override
  Widget build(BuildContext context) {
    final test = row['test'] ?? 'Lab result';
    final reference = row['referenceRange'] ?? '';
    final derived = row['derived'] == 'true';
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 18, backgroundColor: _metricColor(test).withOpacity(.12), child: Icon(_isHormoneTest(test) ? Icons.bolt_rounded : Icons.bloodtype_rounded, color: _metricColor(test), size: 18)),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Expanded(child: Text(test, style: const TextStyle(fontWeight: FontWeight.w900))), if (derived) const Text('CALCULATED', style: TextStyle(color: _cyan, fontSize: 7, fontWeight: FontWeight.w900))]),
              const SizedBox(height: 3),
              Text('${row['date'] ?? ''}${(row['source'] ?? '').isEmpty ? '' : ' • ${row['source']}'}', style: const TextStyle(color: _muted, fontSize: 9)),
              if (reference.isNotEmpty) Text('Lab range: $reference', style: const TextStyle(color: _muted, fontSize: 8)),
            ])),
            const SizedBox(width: 8),
            Text('${row['result'] ?? ''}${(row['units'] ?? '').isEmpty ? '' : ' ${row['units']}'}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          ]),
        ),
      ),
    );
  }
}

class _DailyStateDashboardCard extends StatelessWidget {
  const _DailyStateDashboardCard({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final state = controller.todayDailyState;
    final due = controller.isMorningCheckInDue;
    final disabled = !controller.morningCheckInEnabled;

    return Card(
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => DailyStateScreen(controller: controller)),
        ),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                backgroundColor: (state == null ? _cyan : _dailyStateColor(state)).withOpacity(.12),
                child: Icon(
                  state == null ? Icons.wb_sunny_rounded : Icons.insights_rounded,
                  color: state == null ? _cyan : _dailyStateColor(state),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('DAILY STATE', style: TextStyle(color: _muted, fontSize: 8, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 3),
                    Text(
                      state != null
                          ? state.label
                          : disabled
                              ? 'Morning check-in is off'
                              : controller.isCheckInDismissedToday
                                  ? 'Check-in dismissed for today'
                                  : due
                                      ? 'Morning check-in ready'
                                      : 'Check-in after ${controller.morningCheckInTimeLabel}',
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      state != null
                          ? 'Recovery ${state.recovery.toStringAsFixed(1)}/6 • Stress ${state.stress.toStringAsFixed(1)}/6 • ${controller.dailyBaselineText}'
                          : due
                              ? 'Eight quick recovery/stress items. No diagnosis and no fake readiness percentage.'
                              : disabled
                                  ? 'You can enable it any time in Daily State settings.'
                                  : controller.isCheckInDismissedToday
                                      ? 'It will return after tomorrow's selected start time.'
                                      : 'It will not appear early just because the app is open.',
                      style: const TextStyle(color: _muted, fontSize: 9, height: 1.35),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: _muted),
            ],
          ),
        ),
      ),
    );
  }
}

class DailyStateScreen extends StatelessWidget {
  const DailyStateScreen({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final row = controller.todayCheckIn;
        final state = controller.todayDailyState;
        return _DetailScaffold(
          title: 'Daily State',
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Where you are today',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Morning check-in settings',
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => DailyStateSettingsScreen(controller: controller)),
                    ),
                    icon: const Icon(Icons.tune_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                'Recovery and stress are shown separately. Healthy Me does not diagnose mental-health or medical conditions from this check-in.',
                style: TextStyle(color: _muted, fontSize: 10, height: 1.4),
              ),
              const SizedBox(height: 12),
              if (row == null) _buildPendingCard(context) else _buildTodayCard(context, row, state!),
              const SizedBox(height: 12),
              if (row != null && state != null) _buildResetCard(context, row, state),
              if (row != null && state != null) const SizedBox(height: 12),
              _buildBaselineCard(),
              const SizedBox(height: 12),
              _buildHistoryCard(),
              const SizedBox(height: 12),
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('About the check-in', style: TextStyle(fontWeight: FontWeight.w900)),
                      SizedBox(height: 6),
                      Text(
                        'The beta follows the eight recovery/stress domains selected from established Short Recovery and Stress Scale (SRSS) research. Exact instrument licensing/wording still needs review before commercial release. Healthy Me summary labels are app interpretations, not clinical cutoffs.',
                        style: TextStyle(color: _muted, fontSize: 9, height: 1.4),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPendingCard(BuildContext context) {
    final due = controller.isMorningCheckInDue;
    if (!controller.morningCheckInEnabled) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Morning check-in is off', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              const SizedBox(height: 5),
              const Text('Enable it when you want Healthy Me to include your subjective recovery/stress state.', style: TextStyle(color: _muted, fontSize: 10)),
              const SizedBox(height: 12),
              FilledButton.tonalIcon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => DailyStateSettingsScreen(controller: controller))),
                icon: const Icon(Icons.settings_rounded),
                label: const Text('Open Settings'),
              ),
            ],
          ),
        ),
      );
    }

    if (controller.isCheckInDismissedToday) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Check-in dismissed for today', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              SizedBox(height: 5),
              Text('Healthy Me will offer the morning check-in again tomorrow after your selected start time.', style: TextStyle(color: _muted, fontSize: 10, height: 1.4)),
            ],
          ),
        ),
      );
    }

    if (!due) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Check-in starts at ${controller.morningCheckInTimeLabel}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              const SizedBox(height: 5),
              const Text('Opening the app earlier will not trigger the morning check-in. If the app stays open, the Daily State card updates when the selected start time arrives.', style: TextStyle(color: _muted, fontSize: 10, height: 1.4)),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                CircleAvatar(backgroundColor: Color(0x222BB9F3), child: Icon(Icons.wb_sunny_rounded, color: _cyan)),
                SizedBox(width: 10),
                Expanded(child: Text('Morning check-in is ready', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
              ],
            ),
            const SizedBox(height: 8),
            const Text('Eight taps. Recovery and stress stay separate so a watch score cannot override how you actually feel.', style: TextStyle(color: _muted, fontSize: 10, height: 1.4)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => MorningCheckInScreen(controller: controller))),
                icon: const Icon(Icons.fact_check_rounded),
                label: const Text('Check In Now'),
              ),
            ),
            const SizedBox(height: 4),
            Align(
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () async {
                  await controller.dismissMorningCheckInForToday();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Morning check-in dismissed for today.')));
                  }
                },
                child: const Text('Not today'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTodayCard(BuildContext context, Map<String, dynamic> row, DailyStateSummary state) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(backgroundColor: _dailyStateColor(state).withOpacity(.12), child: Icon(Icons.insights_rounded, color: _dailyStateColor(state))),
                const SizedBox(width: 10),
                Expanded(child: Text(state.label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18))),
                TextButton(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => MorningCheckInScreen(controller: controller, initialValues: _scoresFromRow(row)))),
                  child: const Text('Edit'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(state.detail, style: const TextStyle(color: _muted, fontSize: 10)),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(child: _DailyScoreBox(label: 'Recovery', value: state.recovery, color: _green, higherIsBetter: true)),
                const SizedBox(width: 10),
                Expanded(child: _DailyScoreBox(label: 'Stress', value: state.stress, color: _orange, higherIsBetter: false)),
              ],
            ),
            const SizedBox(height: 10),
            Text(controller.dailyBaselineText, style: const TextStyle(color: _muted, fontSize: 9, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  Widget _buildResetCard(BuildContext context, Map<String, dynamic> row, DailyStateSummary state) {
    final actions = _resetActions(row, state);
    final selected = row['resetAction']?.toString() ?? '';
    final helpfulness = row['resetHelpfulness']?.toString() ?? '';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Try a reset', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
            const SizedBox(height: 4),
            const Text('These are evidence-supported wellness options, not treatment. Pick one only if it fits your day.', style: TextStyle(color: _muted, fontSize: 9, height: 1.35)),
            const SizedBox(height: 10),
            ...actions.map((action) => Padding(
                  padding: const EdgeInsets.only(bottom: 7),
                  child: SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await controller.recordResetAction(action.$1);
                        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${action.$1} selected. Come back and tell Healthy Me whether it helped.')));
                      },
                      icon: Icon(action.$2, size: 18),
                      label: Align(alignment: Alignment.centerLeft, child: Text(action.$1)),
                    ),
                  ),
                )),
            if (selected.isNotEmpty) ...[
              const Divider(height: 20),
              Text('Selected: $selected', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10)),
              const SizedBox(height: 8),
              const Text('Did it help?', style: TextStyle(color: _muted, fontSize: 9)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: ['Worse', 'Same', 'A little', 'A lot'].map((value) {
                  return ChoiceChip(
                    label: Text(value, style: const TextStyle(fontSize: 9)),
                    selected: helpfulness == value,
                    onSelected: (_) => controller.recordResetHelpfulness(value),
                  );
                }).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildBaselineCard() {
    final recovery = controller.baselineRecovery;
    final stress = controller.baselineStress;
    final count = controller.baselineRows.length;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Your baseline', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
            const SizedBox(height: 5),
            if (recovery == null || stress == null)
              Text('Building your personal normal: $count/7 prior check-ins. Healthy Me will compare you with your own recent pattern instead of treating one generic number as normal for everyone.', style: const TextStyle(color: _muted, fontSize: 9, height: 1.4))
            else
              Row(
                children: [
                  Expanded(child: _MetricBox(label: 'Baseline recovery', value: '${recovery.toStringAsFixed(1)}/6')),
                  const SizedBox(width: 8),
                  Expanded(child: _MetricBox(label: 'Baseline stress', value: '${stress.toStringAsFixed(1)}/6')),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryCard() {
    final rows = controller.dailyCheckIns.take(7).toList();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Recent check-ins', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
            const SizedBox(height: 8),
            if (rows.isEmpty)
              const Text('No completed check-ins yet.', style: TextStyle(color: _muted, fontSize: 9))
            else
              ...rows.map((row) {
                final recovery = (row['recoveryAverage'] as num?)?.toDouble() ?? _averageFromRow(row, _dailyRecoveryKeys);
                final stress = (row['stressAverage'] as num?)?.toDouble() ?? _averageFromRow(row, _dailyStressKeys);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    children: [
                      Expanded(child: Text(_friendlyDateKey(row['date']?.toString() ?? ''), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10))),
                      Text('Recovery ${recovery.toStringAsFixed(1)}', style: const TextStyle(color: _green, fontSize: 9)),
                      const SizedBox(width: 10),
                      Text('Stress ${stress.toStringAsFixed(1)}', style: const TextStyle(color: _orange, fontSize: 9)),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}

class _DailyScoreBox extends StatelessWidget {
  const _DailyScoreBox({required this.label, required this.value, required this.color, required this.higherIsBetter});
  final String label;
  final double value;
  final Color color;
  final bool higherIsBetter;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: _surface2, borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: _muted, fontSize: 9, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('${value.toStringAsFixed(1)} / 6', style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(higherIsBetter ? 'Higher = more recovered' : 'Higher = more stress/load', style: const TextStyle(color: _muted, fontSize: 8)),
        ],
      ),
    );
  }
}

class MorningCheckInScreen extends StatefulWidget {
  const MorningCheckInScreen({super.key, required this.controller, this.initialValues});
  final AppController controller;
  final Map<String, int>? initialValues;

  @override
  State<MorningCheckInScreen> createState() => _MorningCheckInScreenState();
}

class _MorningCheckInScreenState extends State<MorningCheckInScreen> {
  late final Map<String, int?> values;

  static const items = <(String, String, String, bool)>[
    ('physicalCapability', 'Physical capability', 'How physically capable do you feel right now?', true),
    ('mentalCapability', 'Mental capability', 'How well does your head feel able to function right now?', true),
    ('emotionalBalance', 'Emotional balance', 'How emotionally balanced do you feel right now?', true),
    ('overallRecovery', 'Overall recovery', 'Overall, how recovered do you feel?', true),
    ('muscularStress', 'Body / muscular stress', 'How much soreness, strain, or muscular stress applies right now?', false),
    ('lackActivation', 'Lack of activation', 'How much sluggishness, low drive, or lack of activation applies right now?', false),
    ('negativeEmotionalState', 'Negative emotional state', 'How much irritability, low mood, or negative emotional state applies right now?', false),
    ('overallStress', 'Overall stress', 'Overall, how much stress or overload applies right now?', false),
  ];

  @override
  void initState() {
    super.initState();
    values = {for (final item in items) item.$1: widget.initialValues?[item.$1]};
  }

  bool get complete => values.values.every((value) => value != null);

  @override
  Widget build(BuildContext context) {
    return _DetailScaffold(
      title: 'Morning Check-In',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('How are you right now?', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                  SizedBox(height: 6),
                  Text('Tap one number for each item. 0 = does not apply at all. 6 = fully applies. Recovery items and stress items are scored separately.', style: TextStyle(color: _muted, fontSize: 10, height: 1.4)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const _DailySectionHeader(title: 'Recovery', subtitle: 'Higher scores mean more recovery/capability', color: _green),
          ...items.where((item) => item.$4).map(_questionCard),
          const SizedBox(height: 6),
          const _DailySectionHeader(title: 'Stress', subtitle: 'Higher scores mean more stress/load', color: _orange),
          ...items.where((item) => !item.$4).map(_questionCard),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: complete ? _save : null,
              icon: const Icon(Icons.check_rounded),
              label: Text(complete ? 'Save Today\'s Check-In' : 'Answer All 8 Items'),
            ),
          ),
          const SizedBox(height: 8),
          const Text('This is a wellness/recovery check-in, not a mental-health diagnosis or medical assessment.', textAlign: TextAlign.center, style: TextStyle(color: _muted, fontSize: 8)),
        ],
      ),
    );
  }

  Widget _questionCard((String, String, String, bool) item) {
    final key = item.$1;
    final selected = values[key];
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item.$2, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
              const SizedBox(height: 3),
              Text(item.$3, style: const TextStyle(color: _muted, fontSize: 9, height: 1.3)),
              const SizedBox(height: 9),
              Row(
                children: List.generate(7, (score) {
                  final active = selected == score;
                  return Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(right: score == 6 ? 0 : 4),
                      child: InkWell(
                        onTap: () => setState(() => values[key] = score),
                        borderRadius: BorderRadius.circular(8),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 120),
                          height: 36,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: active ? (item.$4 ? _green : _orange) : _surface2,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: active ? Colors.transparent : _stroke),
                          ),
                          child: Text('$score', style: TextStyle(color: active ? _bg : Colors.white, fontWeight: FontWeight.w900, fontSize: 11)),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _save() async {
    final result = <String, int>{};
    for (final entry in values.entries) {
      final value = entry.value;
      if (value == null) return;
      result[entry.key] = value;
    }
    await widget.controller.completeMorningCheckIn(result);
    if (mounted) Navigator.of(context).pop();
  }
}

class _DailySectionHeader extends StatelessWidget {
  const _DailySectionHeader({required this.title, required this.subtitle, required this.color});
  final String title;
  final String subtitle;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 4, 2, 8),
      child: Row(
        children: [
          Icon(Icons.circle, size: 10, color: color),
          const SizedBox(width: 7),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14))),
          Text(subtitle, style: const TextStyle(color: _muted, fontSize: 8)),
        ],
      ),
    );
  }
}

class DailyStateSettingsScreen extends StatefulWidget {
  const DailyStateSettingsScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<DailyStateSettingsScreen> createState() => _DailyStateSettingsScreenState();
}

class _DailyStateSettingsScreenState extends State<DailyStateSettingsScreen> {
  late bool enabled;
  late int minutes;

  @override
  void initState() {
    super.initState();
    enabled = widget.controller.morningCheckInEnabled;
    minutes = widget.controller.morningCheckInStartMinutes;
  }

  String get timeLabel {
    final hour24 = minutes ~/ 60;
    final minute = minutes % 60;
    final suffix = hour24 >= 12 ? 'PM' : 'AM';
    final hour12 = hour24 % 12 == 0 ? 12 : hour24 % 12;
    return '$hour12:${minute.toString().padLeft(2, '0')} $suffix';
  }

  @override
  Widget build(BuildContext context) {
    return _DetailScaffold(
      title: 'Daily State Settings',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Card(
            child: SwitchListTile(
              value: enabled,
              onChanged: (value) => setState(() => enabled = value),
              title: const Text('Morning recovery/stress check-in', style: TextStyle(fontWeight: FontWeight.w900)),
              subtitle: const Text('Optional. One daily state check-in after your chosen start time.', style: TextStyle(color: _muted, fontSize: 9)),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              enabled: enabled,
              onTap: enabled ? _chooseTime : null,
              leading: const CircleAvatar(backgroundColor: Color(0x222BB9F3), child: Icon(Icons.schedule_rounded, color: _cyan)),
              title: const Text('Daily start time', style: TextStyle(fontWeight: FontWeight.w900)),
              subtitle: const Text('The check-in stays hidden before this time.', style: TextStyle(color: _muted, fontSize: 9)),
              trailing: Text(timeLabel, style: TextStyle(color: enabled ? _cyan : _muted, fontWeight: FontWeight.w900)),
            ),
          ),
          const SizedBox(height: 10),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('Healthy Me checks the clock while the app is open, so leaving it open overnight will not create an early check-in. The card becomes available when the selected time arrives.', style: TextStyle(color: _muted, fontSize: 9, height: 1.4)),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save_rounded),
              label: const Text('Save Settings'),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _chooseTime() async {
    final chosen = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: minutes ~/ 60, minute: minutes % 60),
    );
    if (chosen != null) setState(() => minutes = chosen.hour * 60 + chosen.minute);
  }

  Future<void> _save() async {
    await widget.controller.saveMorningCheckInSettings(enabled: enabled, startMinutes: minutes);
    if (mounted) Navigator.of(context).pop();
  }
}

Color _dailyStateColor(DailyStateSummary state) {
  if (state.recovery >= 4.5 && state.stress <= 2.0) return _green;
  if (state.recovery < 3.0 && state.stress >= 4.0) return _pink;
  if (state.recovery < 3.5 || state.stress >= 3.5) return _orange;
  return _cyan;
}

Map<String, int> _scoresFromRow(Map<String, dynamic> row) {
  final result = <String, int>{};
  for (final key in [..._dailyRecoveryKeys, ..._dailyStressKeys]) {
    final value = (row[key] as num?)?.toInt();
    if (value != null) result[key] = value;
  }
  return result;
}

List<(String, IconData)> _resetActions(Map<String, dynamic> row, DailyStateSummary state) {
  final actions = <(String, IconData)>[];
  final activation = (row['lackActivation'] as num?)?.toInt() ?? 0;
  final muscle = (row['muscularStress'] as num?)?.toInt() ?? 0;
  final emotional = (row['negativeEmotionalState'] as num?)?.toInt() ?? 0;
  final stress = (row['overallStress'] as num?)?.toInt() ?? 0;

  if (activation >= 3) actions.add(('10-minute easy walk', Icons.directions_walk_rounded));
  if (emotional >= 3 || stress >= 3) actions.add(('5-minute quiet breathing / reset', Icons.self_improvement_rounded));
  if (muscle >= 3 || state.recovery < 3.5) actions.add(('Lighter workout or recovery activity', Icons.spa_rounded));
  if (actions.isEmpty) actions.add(('10-minute easy walk', Icons.directions_walk_rounded));
  return actions;
}

String _friendlyDateKey(String key) {
  final parsed = DateTime.tryParse(key);
  return parsed == null ? key : '${parsed.month}/${parsed.day}/${parsed.year}';
}


class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key, required this.controller, required this.onBack});
  final AppController controller;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return _ReferencePage(
      title: 'More',
      onBack: onBack,
      children: [
        _MoreTile(icon: Icons.favorite_rounded, color: _pink, title: 'Heart Health', subtitle: 'Heart rate trends and zones', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => HeartHealthScreen(controller: controller)))),
        _MoreTile(icon: Icons.monitor_weight_rounded, color: _green, title: 'Weight & Goals', subtitle: 'Weight trend and body composition', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => WeightGoalsScreen(controller: controller)))),
        _MoreTile(icon: Icons.person_rounded, color: _cyan, title: 'Profile / User Info', subtitle: 'Your baseline and preferences', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProfileScreen(controller: controller)))),
        _MoreTile(icon: Icons.hub_rounded, color: _green, title: 'Devices & Sources', subtitle: 'Connected health apps, devices and CPAP', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => DevicesSourcesScreen(controller: controller)))),
        _MoreTile(icon: Icons.wb_sunny_rounded, color: _cyan, title: 'Daily State', subtitle: 'Morning recovery, stress, baseline and reset feedback', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => DailyStateScreen(controller: controller)))),
        _MoreTile(icon: Icons.auto_awesome_rounded, color: _orange, title: 'Suggestions', subtitle: 'Diet, activity and recovery guidance with clear Why explanations', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => GuidanceScreen(controller: controller)))),
        _MoreTile(icon: Icons.science_rounded, color: _pink, title: 'Bloodwork & Biomarkers', subtitle: 'Lifestyle, hormones, imports and trends', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => BloodworkScreen(controller: controller)))),
        _MoreTile(icon: Icons.flag_rounded, color: _orange, title: 'Goals & Progress', subtitle: 'Weight, steps, sleep and workout goals', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => GoalsProgressScreen(controller: controller)))),
        _MoreTile(icon: Icons.sync_rounded, color: _blue, title: 'Sync Health Data', subtitle: controller.syncing ? 'Syncing…' : 'Refresh Health Connect now', onTap: controller.syncHealth),
      ],
    );
  }
}

class _ReferencePage extends StatelessWidget {
  const _ReferencePage({required this.title, required this.children, this.onBack, this.menu = false});
  final String title;
  final List<Widget> children;
  final VoidCallback? onBack;
  final bool menu;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 22),
      children: [
        Row(children: [
          if (onBack != null) IconButton(onPressed: onBack, visualDensity: VisualDensity.compact, icon: const Icon(Icons.chevron_left_rounded)),
          Expanded(child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
          if (menu) const Icon(Icons.more_vert_rounded, color: _muted),
        ]),
        const SizedBox(height: 10),
        ...children,
      ],
    );
  }
}

class _DetailScaffold extends StatelessWidget {
  const _DetailScaffold({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.chevron_left_rounded)), title: Text(title), actions: const [Padding(padding: EdgeInsets.only(right: 10), child: Icon(Icons.more_vert_rounded, color: _muted))]),
      body: SafeArea(top: false, child: child),
    );
  }
}

class _RangeTabs extends StatelessWidget {
  const _RangeTabs({required this.labels, required this.selected, required this.onChanged, this.compact = false});
  final List<String> labels;
  final int selected;
  final ValueChanged<int>? onChanged;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(color: _surface2, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: List.generate(labels.length, (i) {
          final active = i == selected;
          return Expanded(
            child: InkWell(
              onTap: onChanged == null ? null : () => onChanged!(i),
              borderRadius: BorderRadius.circular(8),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                padding: EdgeInsets.symmetric(vertical: compact ? 6 : 8),
                decoration: BoxDecoration(color: active ? _cyan : Colors.transparent, borderRadius: BorderRadius.circular(8)),
                alignment: Alignment.center,
                child: Text(labels[i], style: TextStyle(fontSize: compact ? 8 : 9, fontWeight: FontWeight.w800, color: active ? Colors.white : _muted)),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _DateStrip extends StatelessWidget {
  const _DateStrip({required this.label});
  final String label;
  @override
  Widget build(BuildContext context) => Center(child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)));
}

class _MiniMetric extends StatelessWidget {
  const _MiniMetric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Column(children: [Text(label, textAlign: TextAlign.center, style: const TextStyle(color: _muted, fontSize: 8)), const SizedBox(height: 3), Text(value, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13))]);
}

class _SleepStageRow extends StatelessWidget {
  const _SleepStageRow({required this.label, required this.color, required this.fraction});
  final String label;
  final Color color;
  final double? fraction;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [SizedBox(width: 50, child: Row(children: [Container(width: 8, height: 8, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2))), const SizedBox(width: 6), Text(label, style: const TextStyle(fontSize: 9))])), Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: fraction ?? 0, minHeight: 10, backgroundColor: _stroke, color: color)))]));
}

class _MetricBox extends StatelessWidget {
  const _MetricBox({required this.label, required this.value, this.subvalue, this.accent});
  final String label;
  final String value;
  final String? subvalue;
  final Color? accent;
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: _muted, fontSize: 9)), const SizedBox(height: 5), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)), if (subvalue != null) ...[const SizedBox(height: 3), Text(subvalue!, style: TextStyle(color: accent ?? _muted, fontSize: 9, fontWeight: FontWeight.w700))]])));
}

class _CompositionTile extends StatelessWidget {
  const _CompositionTile({required this.icon, required this.color, required this.label, required this.value});
  final IconData icon;
  final Color color;
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: _surface2, borderRadius: BorderRadius.circular(12)), child: Row(children: [CircleAvatar(radius: 16, backgroundColor: color.withOpacity(.12), child: Icon(icon, color: color, size: 17)), const SizedBox(width: 8), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: _muted, fontSize: 8)), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12))]))]));
}

class _ZoneRow extends StatelessWidget {
  const _ZoneRow({required this.label, required this.color, required this.fraction});
  final String label;
  final Color color;
  final double fraction;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [SizedBox(width: 48, child: Text(label, style: const TextStyle(fontSize: 9))), Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: fraction, minHeight: 9, backgroundColor: _stroke, color: color))), const SizedBox(width: 8), SizedBox(width: 36, child: Text('${(fraction * 100).round()}%', textAlign: TextAlign.right, style: const TextStyle(color: _muted, fontSize: 8)))]));
}

class _BodyRow extends StatelessWidget {
  const _BodyRow({required this.label, required this.value, required this.color, required this.onTap});
  final String label;
  final String value;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, child: Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: color)), const SizedBox(width: 8), Expanded(child: Text(label, style: const TextStyle(fontSize: 11))), Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)), const SizedBox(width: 4), const Icon(Icons.chevron_right_rounded, size: 16, color: _muted)])));
}

class _AddPhotosButton extends StatelessWidget {
  const _AddPhotosButton({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: FilledButton.icon(
        onPressed: () => showModalBottomSheet(
          context: context,
          backgroundColor: _surface,
          builder: (context) => SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Add progress photo', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  ...['Front', 'Side', 'Back'].map(
                    (view) => ListTile(
                      leading: const Icon(Icons.add_a_photo_rounded, color: _green),
                      title: Text(view),
                      onTap: () async {
                        Navigator.pop(context);
                        await controller.addProgressPhoto(view);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        icon: const Icon(Icons.add),
        label: const Text('Add Photos'),
      ),
    );
  }
}

class _PhotoSlot extends StatelessWidget {
  const _PhotoSlot({required this.item, required this.label});
  final Map<String, String>? item;
  final String label;
  @override
  Widget build(BuildContext context) {
    final file = item == null ? null : File(item!['path'] ?? '');
    return AspectRatio(
      aspectRatio: .72,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Stack(fit: StackFit.expand, children: [
          if (file != null && file.existsSync()) Image.file(file, fit: BoxFit.cover) else Container(color: _surface2, child: const Icon(Icons.person_outline_rounded, color: _muted, size: 38)),
          Positioned(left: 0, right: 0, bottom: 0, child: Container(padding: const EdgeInsets.symmetric(vertical: 4), color: Colors.black54, child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w800)))),
        ]),
      ),
    );
  }
}

class _ProfileEditRow extends StatelessWidget {
  const _ProfileEditRow({required this.label, required this.child});
  final String label;
  final Widget child;
  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _stroke))),
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(children: [
          SizedBox(width: 96, child: Text(label, style: const TextStyle(color: _muted, fontSize: 10))),
          const SizedBox(width: 8),
          Expanded(child: Align(alignment: Alignment.centerRight, child: child)),
          const SizedBox(width: 4),
        ]),
      );
}

class _ProfileValueRow extends StatelessWidget {
  const _ProfileValueRow({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Container(decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _stroke))), padding: const EdgeInsets.symmetric(vertical: 12), child: Row(children: [Expanded(child: Text(label, style: const TextStyle(color: _muted, fontSize: 10))), Text(value, style: const TextStyle(fontSize: 10))]));
}

class _DeviceCard extends StatelessWidget {
  const _DeviceCard({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.status,
    required this.active,
    this.detailText = '',
    this.showPlus = false,
    this.onTap,
  });
  final IconData icon;
  final Color iconColor;
  final String title;
  final String status;
  final String detailText;
  final bool active;
  final bool showPlus;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final row = Padding(
      padding: const EdgeInsets.all(13),
      child: Row(children: [
        CircleAvatar(radius: 23, backgroundColor: iconColor.withOpacity(.12), child: Icon(icon, color: iconColor)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
          const SizedBox(height: 2),
          Text(status, style: TextStyle(color: active ? _green : _pink, fontWeight: FontWeight.w800, fontSize: 9)),
          if (detailText.isNotEmpty) ...[const SizedBox(height: 2), Text(detailText, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _muted, fontSize: 8))],
        ])),
        if (onTap != null) Icon(showPlus ? Icons.add_rounded : Icons.chevron_right_rounded, color: _muted),
      ]),
    );
    return Card(child: onTap == null ? row : InkWell(onTap: onTap, borderRadius: BorderRadius.circular(16), child: row));
  }
}

class _SuggestionPreview extends StatelessWidget {
  const _SuggestionPreview({required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final item = controller.suggestions.first;
    return Card(
      child: InkWell(
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => GuidanceScreen(controller: controller))),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(backgroundColor: item.color.withOpacity(.12), child: Icon(item.icon, color: item.color)),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('TODAY\'S SUGGESTION', style: TextStyle(color: _muted, fontSize: 8, fontWeight: FontWeight.w900)),
              const SizedBox(height: 3),
              Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
              const SizedBox(height: 3),
              Text(item.summary, style: const TextStyle(color: _muted, fontSize: 9, height: 1.35)),
            ])),
            const Icon(Icons.chevron_right_rounded, color: _muted),
          ]),
        ),
      ),
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  const _SuggestionCard({required this.suggestion});
  final WellnessSuggestion suggestion;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [CircleAvatar(backgroundColor: suggestion.color.withOpacity(.12), child: Icon(suggestion.icon, color: suggestion.color)), const SizedBox(width: 10), Expanded(child: Text(suggestion.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)))]),
            const SizedBox(height: 8),
            Text(suggestion.summary, style: const TextStyle(color: _muted, fontSize: 10, height: 1.4)),
            const SizedBox(height: 8),
            TextButton.icon(onPressed: () => _showWhy(context, suggestion), icon: const Icon(Icons.help_outline_rounded, size: 16), label: const Text('Why am I seeing this?')),
          ]),
        ),
      );
}

class _SourcePriorityRow extends StatelessWidget {
  const _SourcePriorityRow({required this.controller, required this.metric});
  final AppController controller;
  final String metric;

  Future<void> _openPicker(BuildContext context) async {
    final available = controller.health.availableSources[metric] ?? const <String>[];
    final options = <String>{
      'Auto',
      ...available,
      if (metric == 'Weight') 'Manual',
    }.toList();
    final selected = controller.sourcePreference[metric] ?? 'Auto';

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surface,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$metric source', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(
                available.isEmpty
                    ? 'No Health Connect provider has supplied $metric data yet. Auto will begin using a provider as soon as one is detected.'
                    : 'Choose which detected provider Healthy Me should use for $metric.',
                style: const TextStyle(color: _muted, fontSize: 10),
              ),
              const SizedBox(height: 12),
              ...options.map((option) {
                final isSelected = option == selected || (selected != 'Manual' && !options.contains(selected) && option == 'Auto');
                final subtitle = option == 'Auto'
                    ? (available.isEmpty ? 'Waiting for a detected provider' : 'Automatically use the most recently active provider')
                    : option == 'Manual'
                        ? 'Use the weight entered in Healthy Me'
                        : 'Detected through Health Connect';
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    onTap: () async {
                      Navigator.of(sheetContext).pop();
                      await controller.setSourcePreference(metric, option);
                    },
                    leading: CircleAvatar(
                      radius: 16,
                      backgroundColor: (isSelected ? _green : _muted).withOpacity(.12),
                      child: Icon(
                        isSelected ? Icons.check_rounded : _sourceIcon(option),
                        color: isSelected ? _green : _sourceColor(option),
                        size: 18,
                      ),
                    ),
                    title: Text(
                      option == 'Auto' ? 'Auto / Recommended' : _friendlySource(option),
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
                    ),
                    subtitle: Text(subtitle, style: const TextStyle(color: _muted, fontSize: 9)),
                    trailing: isSelected ? const Icon(Icons.check_circle_rounded, color: _green) : null,
                  ),
                );
              }),
              if (available.isEmpty) ...[
                const SizedBox(height: 4),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonalIcon(
                    onPressed: () async {
                      Navigator.of(sheetContext).pop();
                      await controller.syncHealth();
                    },
                    icon: const Icon(Icons.sync_rounded),
                    label: const Text('Sync and detect sources'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final detected = controller.health.sources[metric];
    final available = controller.health.availableSources[metric] ?? const <String>[];
    final selected = controller.sourcePreference[metric] ?? 'Auto';
    final display = selected == 'Auto'
        ? 'Auto'
        : selected == 'Manual'
            ? 'Manual'
            : _friendlySource(selected);

    return Card(
      child: InkWell(
        onTap: () => _openPicker(context),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(metric, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
                    const SizedBox(height: 3),
                    Text(
                      detected != null
                          ? 'Using: ${_friendlySource(detected)}${controller.health.metricLastSeen[metric] == null ? '' : ' • updated ${_relativeTime(controller.health.metricLastSeen[metric]!)}'}'
                          : available.isEmpty
                              ? 'No provider data detected yet'
                              : '${available.length} provider${available.length == 1 ? '' : 's'} detected',
                      style: TextStyle(
                        color: detected != null ? _green : _muted,
                        fontSize: 9,
                        fontWeight: detected != null ? FontWeight.w700 : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
              Text(display, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)),
              const SizedBox(width: 6),
              const Icon(Icons.expand_more_rounded, color: _muted),
            ],
          ),
        ),
      ),
    );
  }
}

class _GoalCard extends StatelessWidget {
  const _GoalCard({required this.icon, required this.color, required this.title, required this.progress, required this.line1, required this.line2});
  final IconData icon;
  final Color color;
  final String title;
  final double progress;
  final String line1;
  final String line2;
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(13), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [CircleAvatar(radius: 18, backgroundColor: color.withOpacity(.12), child: Icon(icon, color: color, size: 19)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)), const SizedBox(height: 8), LinearProgressIndicator(value: progress.clamp(0.0, 1.0), minHeight: 8, borderRadius: BorderRadius.circular(8), backgroundColor: _stroke, color: color), const SizedBox(height: 6), Row(children: [Expanded(child: Text(line1, style: const TextStyle(fontSize: 9))), Text(line2, style: const TextStyle(color: _muted, fontSize: 8))])]))])));
}

class _MoreTile extends StatelessWidget {
  const _MoreTile({required this.icon, required this.color, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Card(child: ListTile(onTap: onTap, contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4), leading: CircleAvatar(backgroundColor: color.withOpacity(.12), child: Icon(icon, color: color)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)), subtitle: Text(subtitle, style: const TextStyle(color: _muted, fontSize: 9)), trailing: const Icon(Icons.chevron_right_rounded, color: _muted))));
}

class _BarChartPainter extends CustomPainter {
  _BarChartPainter(this.values, this.color);
  final List<double> values;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _stroke.withOpacity(.65)..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final vals = values.length == 24 ? values : List<double>.filled(24, 0);
    final maxV = math.max(1.0, vals.fold<double>(0, (a, b) => a > b ? a : b)).toDouble();
    final gap = 2.0;
    final barW = math.max(2.0, (size.width - gap * 23) / 24);

    for (var i = 0; i < 24; i++) {
      final h = (vals[i] / maxV) * (size.height - 14);
      final x = i * (barW + gap);
      final ratio = (vals[i] / maxV).clamp(0.0, 1.0);
      final top = Color.lerp(_blue, _green, ratio)!;
      final rect = Rect.fromLTWH(x, size.height - h, barW, h);
      final paint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [color.withOpacity(.55), top],
        ).createShader(rect);
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(3)), paint);
    }

    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    for (final item in const [(0, '12AM'), (6, '6AM'), (12, '12PM'), (18, '6PM'), (23, '12AM')]) {
      textPainter.text = TextSpan(text: item.$2, style: const TextStyle(color: _muted, fontSize: 7));
      textPainter.layout();
      final x = item.$1 / 23 * (size.width - textPainter.width);
      textPainter.paint(canvas, Offset(x, size.height - 9));
    }
  }

  @override
  bool shouldRepaint(covariant _BarChartPainter oldDelegate) => oldDelegate.values != values;
}

class _LineChartPainter extends CustomPainter {
  _LineChartPainter(this.values, this.color);
  final List<double> values;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _stroke.withOpacity(.65)..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    if (values.length < 2) return;
    var minV = values.reduce((a, b) => a < b ? a : b);
    var maxV = values.reduce((a, b) => a > b ? a : b);
    if ((maxV - minV).abs() < .1) {
      minV -= 1;
      maxV += 1;
    }

    final line = Path();
    final points = <Offset>[];
    for (var i = 0; i < values.length; i++) {
      final x = i / (values.length - 1) * size.width;
      final y = size.height - ((values[i] - minV) / (maxV - minV) * (size.height - 18)) - 9;
      points.add(Offset(x, y));
      if (i == 0) line.moveTo(x, y); else line.lineTo(x, y);
    }

    final fill = Path.from(line)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(
      fill,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [color.withOpacity(.30), color.withOpacity(.02)],
        ).createShader(Offset.zero & size),
    );
    canvas.drawPath(line, Paint()..color = color..strokeWidth = 2.4..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round);

    for (final pt in points) {
      canvas.drawCircle(pt, 2.2, Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant _LineChartPainter oldDelegate) => oldDelegate.values != values;
}

class _BodySilhouettePainter extends CustomPainter {
  const _BodySilhouettePainter({required this.front});
  final bool front;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * .58, size.height * .50);
    final h = size.height * .88;
    final scale = h / 300;
    final body = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: front
            ? [const Color(0xFFD7E1E6), const Color(0xFF7D929D)]
            : [const Color(0xFFBFCBD1), const Color(0xFF667A84)],
      ).createShader(Rect.fromCenter(center: center, width: 120 * scale, height: h));
    final outline = Paint()..color = Colors.white.withOpacity(.25)..style = PaintingStyle.stroke..strokeWidth = 1.2;

    final cx = center.dx;
    final top = center.dy - h / 2;
    final headCenter = Offset(cx, top + 25 * scale);
    final headRect = Rect.fromCenter(center: headCenter, width: 35 * scale, height: 44 * scale);
    canvas.drawOval(headRect, body);
    canvas.drawOval(headRect, outline);

    final torso = Path()
      ..moveTo(cx - 13 * scale, top + 48 * scale)
      ..cubicTo(cx - 35 * scale, top + 54 * scale, cx - 43 * scale, top + 79 * scale, cx - 38 * scale, top + 104 * scale)
      ..cubicTo(cx - 35 * scale, top + 122 * scale, cx - 29 * scale, top + 139 * scale, cx - 26 * scale, top + 154 * scale)
      ..cubicTo(cx - 22 * scale, top + 169 * scale, cx - 22 * scale, top + 176 * scale, cx - 18 * scale, top + 184 * scale)
      ..lineTo(cx + 18 * scale, top + 184 * scale)
      ..cubicTo(cx + 22 * scale, top + 176 * scale, cx + 22 * scale, top + 169 * scale, cx + 26 * scale, top + 154 * scale)
      ..cubicTo(cx + 29 * scale, top + 139 * scale, cx + 35 * scale, top + 122 * scale, cx + 38 * scale, top + 104 * scale)
      ..cubicTo(cx + 43 * scale, top + 79 * scale, cx + 35 * scale, top + 54 * scale, cx + 13 * scale, top + 48 * scale)
      ..close();
    canvas.drawPath(torso, body);
    canvas.drawPath(torso, outline);

    Path arm(bool left) {
      final sign = left ? -1.0 : 1.0;
      return Path()
        ..moveTo(cx + sign * 31 * scale, top + 62 * scale)
        ..cubicTo(cx + sign * 48 * scale, top + 70 * scale, cx + sign * 56 * scale, top + 97 * scale, cx + sign * 55 * scale, top + 128 * scale)
        ..cubicTo(cx + sign * 55 * scale, top + 157 * scale, cx + sign * 51 * scale, top + 178 * scale, cx + sign * 48 * scale, top + 194 * scale)
        ..cubicTo(cx + sign * 47 * scale, top + 202 * scale, cx + sign * 37 * scale, top + 202 * scale, cx + sign * 38 * scale, top + 192 * scale)
        ..cubicTo(cx + sign * 40 * scale, top + 168 * scale, cx + sign * 42 * scale, top + 142 * scale, cx + sign * 41 * scale, top + 118 * scale)
        ..cubicTo(cx + sign * 40 * scale, top + 92 * scale, cx + sign * 32 * scale, top + 81 * scale, cx + sign * 25 * scale, top + 78 * scale)
        ..close();
    }
    for (final left in [true, false]) {
      final p = arm(left);
      canvas.drawPath(p, body);
      canvas.drawPath(p, outline);
    }

    Path leg(bool left) {
      final sign = left ? -1.0 : 1.0;
      final inner = 3 * scale;
      final outer = 18 * scale;
      return Path()
        ..moveTo(cx + sign * inner, top + 179 * scale)
        ..lineTo(cx + sign * outer, top + 181 * scale)
        ..cubicTo(cx + sign * 24 * scale, top + 209 * scale, cx + sign * 22 * scale, top + 236 * scale, cx + sign * 18 * scale, top + 260 * scale)
        ..cubicTo(cx + sign * 15 * scale, top + 278 * scale, cx + sign * 16 * scale, top + 291 * scale, cx + sign * 13 * scale, top + 298 * scale)
        ..cubicTo(cx + sign * 7 * scale, top + 302 * scale, cx + sign * 1 * scale, top + 298 * scale, cx + sign * 2 * scale, top + 289 * scale)
        ..cubicTo(cx + sign * 5 * scale, top + 265 * scale, cx + sign * 5 * scale, top + 240 * scale, cx + sign * 3 * scale, top + 218 * scale)
        ..close();
    }
    for (final left in [true, false]) {
      final p = leg(left);
      canvas.drawPath(p, body);
      canvas.drawPath(p, outline);
    }

    if (!front) {
      canvas.drawLine(Offset(cx, top + 58 * scale), Offset(cx, top + 180 * scale), Paint()..color = _stroke..strokeWidth = 1.7);
      canvas.drawArc(Rect.fromCenter(center: Offset(cx, top + 180 * scale), width: 34 * scale, height: 18 * scale), 0, math.pi, false, Paint()..color = _stroke..style = PaintingStyle.stroke..strokeWidth = 1.4);
    }

    final bands = <(double, Color, String, double)>[
      (top + 48 * scale, _green, 'Neck', 28),
      (top + 88 * scale, _pink, 'Chest', 38),
      (top + 127 * scale, _orange, 'Waist', 31),
      (top + 153 * scale, _purple, 'Hips', 36),
      (top + 205 * scale, _pink, 'Thighs', 22),
      (top + 254 * scale, _cyan, 'Calves', 17),
    ];
    final labelPainter = TextPainter(textDirection: TextDirection.ltr);
    for (final band in bands) {
      final y = band.$1;
      final p = Paint()..color = band.$2..strokeWidth = 2;
      canvas.drawLine(Offset(cx - band.$4 * scale, y), Offset(cx + band.$4 * scale, y), p);
      if (front) {
        final labelX = 4.0;
        canvas.drawCircle(Offset(labelX + 3, y), 3, p);
        labelPainter.text = TextSpan(text: band.$3, style: TextStyle(color: band.$2, fontSize: 8, fontWeight: FontWeight.w800));
        labelPainter.layout();
        labelPainter.paint(canvas, Offset(labelX + 10, y - labelPainter.height / 2));
        canvas.drawLine(Offset(labelX + 48, y), Offset(cx - band.$4 * scale - 4, y), Paint()..color = band.$2.withOpacity(.55)..strokeWidth = 1);
      }
    }

    final armY = top + 110 * scale;
    final armPaint = Paint()..color = _green..strokeWidth = 2;
    canvas.drawLine(Offset(cx - 47 * scale, armY), Offset(cx + 47 * scale, armY), armPaint);
    if (front) {
      labelPainter.text = const TextSpan(text: 'Arms', style: TextStyle(color: _green, fontSize: 8, fontWeight: FontWeight.w800));
      labelPainter.layout();
      labelPainter.paint(canvas, Offset(10, armY - 16));
    }
  }

  @override
  bool shouldRepaint(covariant _BodySilhouettePainter oldDelegate) => oldDelegate.front != front;
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}

void _logWeightDialog(BuildContext context, AppController controller) {
  final field = TextEditingController(text: controller.currentWeightLb.toStringAsFixed(1));
  showDialog(context: context, builder: (context) => AlertDialog(title: const Text('Log Weight'), content: TextField(controller: field, autofocus: true, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Weight (lb)')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () { final v = double.tryParse(field.text); if (v != null && v > 0) controller.setManualWeight(v); Navigator.pop(context); }, child: const Text('Save'))]));
}

void _measurementDialog(BuildContext context, AppController controller, String label, double current) {
  final field = TextEditingController(text: current > 0 ? current.toStringAsFixed(1) : '');
  showDialog(context: context, builder: (context) => AlertDialog(title: Text(label), content: TextField(controller: field, autofocus: true, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Inches')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () { final v = double.tryParse(field.text); if (v != null && v >= 0) controller.setMeasurement(label, v); Navigator.pop(context); }, child: const Text('Save'))]));
}

void _bloodworkDialog(BuildContext context, AppController c, {String initialTest = ''}) {
  final test = TextEditingController(text: initialTest);
  final result = TextEditingController();
  final units = TextEditingController();
  final date = TextEditingController(text: _shortDate(DateTime.now()));
  final source = TextEditingController();
  final reference = TextEditingController();
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Add Lab Result'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: test, decoration: const InputDecoration(labelText: 'Test name')),
          const SizedBox(height: 8),
          TextField(controller: result, decoration: const InputDecoration(labelText: 'Your result')),
          const SizedBox(height: 8),
          TextField(controller: units, decoration: const InputDecoration(labelText: 'Units')),
          const SizedBox(height: 8),
          TextField(controller: date, decoration: const InputDecoration(labelText: 'Collection date')),
          const SizedBox(height: 8),
          TextField(controller: source, decoration: const InputDecoration(labelText: 'Lab / source')),
          const SizedBox(height: 8),
          TextField(controller: reference, decoration: const InputDecoration(labelText: 'Lab reference range (optional)')),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: () {
            if (test.text.trim().isEmpty || result.text.trim().isEmpty) return;
            c.addBloodwork(test: test.text, result: result.text, units: units.text, date: date.text, source: source.text, referenceRange: reference.text);
            Navigator.pop(context);
          },
          child: const Text('Save'),
        ),
      ],
    ),
  );
}

void _goalDialog(BuildContext context, AppController c) {
  final steps = TextEditingController(text: c.stepGoal.toString());
  final workouts = TextEditingController(text: c.workoutGoal.toString());
  final bodyFat = TextEditingController(text: c.bodyFatGoal.toStringAsFixed(0));
  showDialog(context: context, builder: (context) => AlertDialog(title: const Text('Edit Goals'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: steps, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Daily steps')), const SizedBox(height: 8), const Text('Sleep recommendation is set automatically from age-based guidance in your Profile.', style: TextStyle(color: _muted, fontSize: 10)), const SizedBox(height: 8), TextField(controller: workouts, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Workouts per week')), const SizedBox(height: 8), TextField(controller: bodyFat, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Body fat goal (%)'))])), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () { c.saveGoals(steps: int.tryParse(steps.text) ?? c.stepGoal, workouts: int.tryParse(workouts.text) ?? c.workoutGoal, bodyFat: double.tryParse(bodyFat.text) ?? c.bodyFatGoal); Navigator.pop(context); }, child: const Text('Save'))]));
}

void _showNotAvailable(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

Color _measureColor(String key) {
  if (key.contains('Neck')) return _green;
  if (key.contains('Chest')) return _pink;
  if (key.contains('Waist')) return _orange;
  if (key.contains('Arm')) return _green;
  if (key.contains('Hips')) return _purple;
  if (key.contains('Thigh')) return _pink;
  return _cyan;
}

Map<String, List<Map<String, String>>> _photoGroups(List<Map<String, String>> photos) {
  final result = <String, List<Map<String, String>>>{};
  for (final p in photos) {
    final d = DateTime.tryParse(p['date'] ?? '');
    final key = d == null ? 'Unknown date' : _longDate(d);
    result.putIfAbsent(key, () => []).add(p);
  }
  return result;
}

double _zoneFraction(List<double> values, double min, double max) {
  if (values.isEmpty) return 0;
  final count = values.where((v) => v >= min && v <= max).length;
  return count / values.length;
}

IconData _sourceIcon(String source) {
  final s = source.toLowerCase();
  if (s.contains('garmin') || s.contains('fitbit') || s.contains('watch')) return Icons.watch_rounded;
  if (s.contains('samsung')) return Icons.health_and_safety_rounded;
  if (s.contains('scale') || s.contains('weight')) return Icons.monitor_weight_rounded;
  return Icons.hub_rounded;
}

Color _sourceColor(String source) {
  final s = source.toLowerCase();
  if (s.contains('garmin')) return _cyan;
  if (s.contains('samsung')) return _green;
  if (s.contains('fitbit')) return _purple;
  return _blue;
}

String _metricsForSource(Map<String, String> sources, String sourceNeedle) {
  final metrics = sources.entries.where((e) => _friendlySource(e.value).contains(sourceNeedle)).map((e) => e.key).toList();
  return metrics.isEmpty ? 'Connected through Health Connect' : metrics.join(', ');
}

String _friendlySource(String raw) {
  final value = raw.trim();
  if (value.isEmpty) return 'Unknown source';
  final lower = value.toLowerCase();
  if (lower == 'auto') return 'Auto';
  if (lower == 'manual') return 'Manual';
  if (lower.contains('garmin')) return 'Garmin Connect';
  if (lower.contains('samsung') || lower.contains('shealth') || lower.contains('sec.android.app.health')) return 'Samsung Health';
  if (lower.contains('healthconnect') || lower.contains('health.connect') || lower.contains('healthdata')) return 'Health Connect';
  if (lower.contains('fitbit')) return 'Fitbit';
  if (lower.contains('google') && lower.contains('fit')) return 'Google Fit';
  if (lower.contains('zepp') || lower.contains('amazfit')) return 'Zepp / Amazfit';
  if (lower.contains('xiaomi') || lower.contains('mifit')) return 'Xiaomi Fitness';
  if (lower.contains('withings')) return 'Withings';
  if (lower.contains('oura')) return 'Oura';
  if (lower.contains('polar')) return 'Polar Flow';
  if (lower.startsWith('com.')) {
    final parts = value.split('.').where((p) => p.isNotEmpty).toList();
    if (parts.isNotEmpty) {
      final last = parts.last.replaceAll('_', ' ').replaceAll('-', ' ');
      return last.split(' ').where((w) => w.isNotEmpty).map((w) => '${w[0].toUpperCase()}${w.substring(1)}').join(' ');
    }
  }
  return value;
}

bool _isLifestyleTest(String test) {
  final key = normalizeBiomarkerName(test).toLowerCase();
  return const {
    'a1c', 'fasting glucose', 'total cholesterol', 'ldl cholesterol', 'hdl cholesterol',
    'triglycerides', 'non-hdl cholesterol', 'apob', 'alt', 'ast', 'ggt', 'hs-crp',
    'tsh', 'free t4', 'vitamin d', 'vitamin b12', 'ferritin', 'iron'
  }.contains(key);
}

bool _isHormoneTest(String test) {
  final key = normalizeBiomarkerName(test).toLowerCase();
  return const {
    'total testosterone', 'free testosterone', 'shbg', 'estradiol', 'progesterone',
    'lh', 'fsh', 'prolactin', 'dhea-s', 'tsh', 'free t4', 'vitamin d',
    'vitamin b12', 'ferritin', 'iron'
  }.contains(key);
}

IconData _metricIcon(String metric) {
  final m = metric.toLowerCase();
  if (m.contains('step') || m.contains('distance') || m.contains('flight')) return Icons.directions_walk_rounded;
  if (m.contains('workout') || m.contains('exercise')) return Icons.fitness_center_rounded;
  if (m.contains('heart') || m.contains('hrv')) return Icons.favorite_rounded;
  if (m.contains('oxygen') || m.contains('respir')) return Icons.air_rounded;
  if (m.contains('sleep')) return Icons.bedtime_rounded;
  if (m.contains('weight') || m.contains('body') || m.contains('bmi')) return Icons.monitor_weight_rounded;
  if (_isHormoneTest(metric)) return Icons.bolt_rounded;
  if (_isLifestyleTest(metric)) return Icons.science_rounded;
  return Icons.insights_rounded;
}

Color _metricColor(String metric) {
  final m = metric.toLowerCase();
  if (m.contains('heart')) return _pink;
  if (m.contains('sleep')) return _purple;
  if (m.contains('weight') || m.contains('body')) return _green;
  if (m.contains('step') || m.contains('workout') || m.contains('distance')) return _green;
  if (_isHormoneTest(metric)) return _purple;
  if (_isLifestyleTest(metric)) return _cyan;
  return _blue;
}

String _relativeTime(DateTime time) {
  final delta = DateTime.now().difference(time);
  if (delta.isNegative || delta.inMinutes < 1) return 'just now';
  if (delta.inMinutes < 60) return '${delta.inMinutes} min ago';
  if (delta.inHours < 24) return '${delta.inHours} hr ago';
  if (delta.inDays == 1) return 'yesterday';
  if (delta.inDays < 30) return '${delta.inDays} days ago';
  return _shortDate(time);
}

void _showWhy(BuildContext context, WellnessSuggestion suggestion) {
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: _surface,
    showDragHandle: true,
    builder: (context) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 22),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(suggestion.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text('Why am I seeing this?', style: TextStyle(color: _muted, fontSize: 10)),
          const SizedBox(height: 12),
          ...suggestion.why.map((reason) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Padding(padding: EdgeInsets.only(top: 5), child: Icon(Icons.circle, size: 5, color: _green)), const SizedBox(width: 8), Expanded(child: Text(reason, style: const TextStyle(fontSize: 10, height: 1.35)))]))),
          const SizedBox(height: 4),
          const Text('This is a wellness suggestion, not medical treatment.', style: TextStyle(color: _muted, fontSize: 9)),
        ]),
      ),
    ),
  );
}

void _showInfoSheet(BuildContext context, String title, String body) {
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: _surface,
    showDragHandle: true,
    builder: (context) => SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(18, 0, 18, 22), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text(body, style: const TextStyle(color: _muted, fontSize: 10, height: 1.4))]))),
  );
}

String _commas(int value) {
  final s = value.toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
    b.write(s[i]);
  }
  return b.toString();
}

String _durationLabel(int minutes) {
  if (minutes <= 0) return '—';
  final h = minutes ~/ 60;
  final m = minutes % 60;
  return '${h}h ${m}m';
}

double _averageValues(List<int> values) {
  if (values.isEmpty) return 0;
  return values.fold<double>(0, (sum, value) => sum + value) / values.length;
}

double _averageFromRow(Map<String, dynamic> row, List<String> keys) {
  final values = keys.map((key) => (row[key] as num?)?.toDouble()).whereType<double>().toList();
  if (values.isEmpty) return 0;
  return values.reduce((a, b) => a + b) / values.length;
}

DailyStateSummary _summarizeDailyState(double recovery, double stress) {
  if (recovery >= 4.5 && stress <= 2.0) {
    return DailyStateSummary(recovery: recovery, stress: stress, label: 'Strong today', detail: 'Recovery is high and stress load is low.');
  }
  if (recovery >= 3.5 && stress <= 3.0) {
    return DailyStateSummary(recovery: recovery, stress: stress, label: 'Fairly ready', detail: 'Your recovery/stress pattern looks workable today.');
  }
  if (recovery < 3.0 && stress >= 4.0) {
    return DailyStateSummary(recovery: recovery, stress: stress, label: 'Take it easier', detail: 'Recovery is lower while stress load is elevated.');
  }
  if (recovery < 3.5 || stress >= 3.5) {
    return DailyStateSummary(recovery: recovery, stress: stress, label: 'Mixed today', detail: 'One or more recovery/stress areas are working against you today.');
  }
  return DailyStateSummary(recovery: recovery, stress: stress, label: 'Steady today', detail: 'Recovery and stress are in the middle range.');
}

String _dateKey(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

String _shortDate(DateTime d) => '${d.month}/${d.day}/${d.year}';

String _longDate(DateTime d) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return '${months[d.month - 1]} ${d.day}, ${d.year}';
}

String _dateLabel() {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  final d = DateTime.now();
  return '${days[d.weekday - 1]}, ${months[d.month - 1]} ${d.day}, ${d.year}';
}

String _daypart() {
  final h = DateTime.now().hour;
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
}
