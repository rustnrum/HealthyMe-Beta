import 'dart:convert';
import 'dart:typed_data';

import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';

class LabImportBatch {
  const LabImportBatch({
    required this.fileName,
    required this.rows,
  });

  final String fileName;
  final List<Map<String, String>> rows;

  int get lifestyleCount => rows.where((row) => row['category'] == 'Lifestyle').length;
  int get hormoneCount => rows.where((row) => row['category'] == 'Hormones & Performance').length;
  int get otherCount => rows.where((row) => row['category'] == 'Other').length;
  int get recognizedCount => rows.where((row) => row['recognized'] == 'true').length;

  List<String> get dates {
    final values = rows.map((row) => row['date'] ?? '').where((value) => value.trim().isNotEmpty).toSet().toList();
    values.sort();
    return values;
  }

  List<String> get sources {
    final values = rows.map((row) => row['source'] ?? '').where((value) => value.trim().isNotEmpty).toSet().toList();
    values.sort();
    return values;
  }
}

class LabImportService {
  Future<LabImportBatch?> pickAndParse() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['csv', 'xlsx'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return null;

    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes == null || bytes.isEmpty) {
      throw const FormatException('The selected file could not be read.');
    }

    final extension = (file.extension ?? '').toLowerCase();
    final table = extension == 'xlsx' ? _xlsxRows(bytes) : _csvRows(bytes);
    final rows = _normalizeTable(table);
    if (rows.isEmpty) {
      throw const FormatException('No lab results could be recognized in that file.');
    }
    return LabImportBatch(fileName: file.name, rows: rows);
  }

  List<List<String>> _xlsxRows(Uint8List bytes) {
    final excel = Excel.decodeBytes(bytes);
    final output = <List<String>>[];
    for (final name in excel.tables.keys) {
      final sheet = excel.tables[name];
      if (sheet == null) continue;
      for (final row in sheet.rows) {
        output.add(row.map((cell) => cell?.value?.toString().trim() ?? '').toList());
      }
      if (output.isNotEmpty) break;
    }
    return output;
  }

  List<List<String>> _csvRows(Uint8List bytes) {
    final text = utf8.decode(bytes, allowMalformed: true).replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    final rows = <List<String>>[];
    var row = <String>[];
    var field = StringBuffer();
    var quoted = false;

    void pushField() {
      row.add(field.toString().trim());
      field = StringBuffer();
    }

    void pushRow() {
      pushField();
      if (row.any((cell) => cell.trim().isNotEmpty)) rows.add(row);
      row = <String>[];
    }

    for (var i = 0; i < text.length; i++) {
      final char = text[i];
      if (char == '"') {
        if (quoted && i + 1 < text.length && text[i + 1] == '"') {
          field.write('"');
          i++;
        } else {
          quoted = !quoted;
        }
      } else if (char == ',' && !quoted) {
        pushField();
      } else if (char == '\n' && !quoted) {
        pushRow();
      } else {
        field.write(char);
      }
    }
    if (field.length > 0 || row.isNotEmpty) pushRow();
    return rows;
  }

  List<Map<String, String>> _normalizeTable(List<List<String>> table) {
    if (table.isEmpty) return const [];
    final headerIndex = _findHeaderRow(table);
    final header = headerIndex >= 0 ? table[headerIndex].map(_headerKey).toList() : <String>[];
    final start = headerIndex >= 0 ? headerIndex + 1 : 0;

    int column(List<String> names, {int fallback = -1}) {
      for (final name in names) {
        final index = header.indexOf(name);
        if (index >= 0) return index;
      }
      return fallback;
    }

    final testCol = column(const ['test', 'testname', 'analyte', 'biomarker', 'marker', 'component'], fallback: 0);
    final resultCol = column(const ['result', 'value', 'labvalue'], fallback: 1);
    final unitsCol = column(const ['units', 'unit'], fallback: 2);
    final dateCol = column(const ['date', 'collectiondate', 'collected', 'specimendate', 'resultdate'], fallback: 3);
    final sourceCol = column(const ['lab', 'laboratory', 'source', 'facility'], fallback: 4);
    final referenceCol = column(const ['referencerange', 'range', 'reference', 'normalrange'], fallback: 5);

    String valueAt(List<String> row, int index) => index >= 0 && index < row.length ? row[index].trim() : '';

    final output = <Map<String, String>>[];
    for (var i = start; i < table.length; i++) {
      final raw = table[i];
      final rawTest = valueAt(raw, testCol);
      final result = valueAt(raw, resultCol);
      if (rawTest.isEmpty || result.isEmpty) continue;
      final normalized = normalizeBiomarkerName(rawTest);
      final recognized = normalized != rawTest.trim() || knownBiomarkers.contains(normalized.toLowerCase());
      output.add({
        'test': normalized,
        'originalTest': rawTest,
        'result': result,
        'units': valueAt(raw, unitsCol),
        'date': valueAt(raw, dateCol),
        'source': valueAt(raw, sourceCol),
        'referenceRange': valueAt(raw, referenceCol),
        'category': biomarkerCategory(normalized),
        'recognized': recognized ? 'true' : 'false',
      });
    }
    return output;
  }

  int _findHeaderRow(List<List<String>> table) {
    final limit = table.length < 20 ? table.length : 20;
    var bestIndex = -1;
    var bestScore = 0;
    for (var i = 0; i < limit; i++) {
      final keys = table[i].map(_headerKey).toList();
      var score = 0;
      for (final key in keys) {
        if (const {
          'test', 'testname', 'analyte', 'biomarker', 'marker', 'component',
          'result', 'value', 'labvalue', 'units', 'unit', 'date', 'collectiondate',
          'collected', 'specimendate', 'resultdate', 'lab', 'laboratory', 'source',
          'facility', 'referencerange', 'range', 'reference', 'normalrange'
        }.contains(key)) {
          score++;
        }
      }
      if (score > bestScore) {
        bestScore = score;
        bestIndex = i;
      }
    }
    return bestScore >= 2 ? bestIndex : -1;
  }

  String _headerKey(String value) => value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
}

const knownBiomarkers = <String>{
  'a1c',
  'fasting glucose',
  'total cholesterol',
  'ldl cholesterol',
  'hdl cholesterol',
  'triglycerides',
  'non-hdl cholesterol',
  'apob',
  'alt',
  'ast',
  'ggt',
  'hs-crp',
  'tsh',
  'free t4',
  'vitamin d',
  'vitamin b12',
  'ferritin',
  'iron',
  'total testosterone',
  'free testosterone',
  'shbg',
  'estradiol',
  'progesterone',
  'lh',
  'fsh',
  'prolactin',
  'dhea-s',
};

String normalizeBiomarkerName(String raw) {
  final cleaned = raw.trim().replaceAll(RegExp(r'\s+'), ' ');
  final key = cleaned.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), ' ').trim();
  const aliases = <String, String>{
    'a1c': 'A1C',
    'hba1c': 'A1C',
    'hemoglobin a1c': 'A1C',
    'hgb a1c': 'A1C',
    'glucose fasting': 'Fasting Glucose',
    'fasting glucose': 'Fasting Glucose',
    'glucose fasting serum': 'Fasting Glucose',
    'cholesterol total': 'Total Cholesterol',
    'total cholesterol': 'Total Cholesterol',
    'ldl': 'LDL Cholesterol',
    'ldl c': 'LDL Cholesterol',
    'ldl chol calc': 'LDL Cholesterol',
    'ldl cholesterol calculated': 'LDL Cholesterol',
    'ldl cholesterol': 'LDL Cholesterol',
    'hdl': 'HDL Cholesterol',
    'hdl c': 'HDL Cholesterol',
    'hdl cholesterol': 'HDL Cholesterol',
    'triglyceride': 'Triglycerides',
    'triglycerides': 'Triglycerides',
    'non hdl': 'Non-HDL Cholesterol',
    'non hdl cholesterol': 'Non-HDL Cholesterol',
    'apob': 'ApoB',
    'apolipoprotein b': 'ApoB',
    'alt': 'ALT',
    'alanine aminotransferase': 'ALT',
    'ast': 'AST',
    'aspartate aminotransferase': 'AST',
    'ggt': 'GGT',
    'gamma glutamyl transferase': 'GGT',
    'hs crp': 'hs-CRP',
    'high sensitivity crp': 'hs-CRP',
    'c reactive protein cardiac': 'hs-CRP',
    'tsh': 'TSH',
    'thyroid stimulating hormone': 'TSH',
    'free t4': 'Free T4',
    't4 free': 'Free T4',
    'vitamin d': 'Vitamin D',
    '25 hydroxy vitamin d': 'Vitamin D',
    'vitamin b12': 'Vitamin B12',
    'b12': 'Vitamin B12',
    'ferritin': 'Ferritin',
    'iron': 'Iron',
    'testosterone total': 'Total Testosterone',
    'total testosterone': 'Total Testosterone',
    'testosterone free': 'Free Testosterone',
    'free testosterone': 'Free Testosterone',
    'shbg': 'SHBG',
    'sex hormone binding globulin': 'SHBG',
    'estradiol': 'Estradiol',
    'e2': 'Estradiol',
    'progesterone': 'Progesterone',
    'lh': 'LH',
    'luteinizing hormone': 'LH',
    'fsh': 'FSH',
    'follicle stimulating hormone': 'FSH',
    'prolactin': 'Prolactin',
    'dhea s': 'DHEA-S',
    'dheas': 'DHEA-S',
  };
  return aliases[key] ?? cleaned;
}

String biomarkerCategory(String test) {
  final key = normalizeBiomarkerName(test).toLowerCase();
  const hormones = <String>{
    'total testosterone', 'free testosterone', 'shbg', 'estradiol', 'progesterone',
    'lh', 'fsh', 'prolactin', 'dhea-s', 'tsh', 'free t4', 'vitamin d',
    'vitamin b12', 'ferritin', 'iron'
  };
  const lifestyle = <String>{
    'a1c', 'fasting glucose', 'total cholesterol', 'ldl cholesterol',
    'hdl cholesterol', 'triglycerides', 'non-hdl cholesterol', 'apob',
    'alt', 'ast', 'ggt', 'hs-crp', 'tsh', 'vitamin d', 'vitamin b12',
    'ferritin', 'iron'
  };
  if (hormones.contains(key)) return 'Hormones & Performance';
  if (lifestyle.contains(key)) return 'Lifestyle';
  return 'Other';
}
