import 'package:health/health.dart';
import 'package:permission_handler/permission_handler.dart';

class TimedValue {
  const TimedValue(this.time, this.value);
  final DateTime time;
  final double value;
}

class HealthSnapshot {
  const HealthSnapshot({
    this.authorized = false,
    this.steps = 0,
    this.heartRate,
    this.restingHeartRate,
    this.hrvRmssd,
    this.sleepMinutes = 0,
    this.sleepDeepMinutes = 0,
    this.sleepLightMinutes = 0,
    this.sleepRemMinutes = 0,
    this.activeCalories,
    this.distanceMeters,
    this.flightsClimbed,
    this.bloodOxygen,
    this.respiratoryRate,
    this.weightLb,
    this.bodyFatPercent,
    this.bodyMassIndex,
    this.bodyWaterKg,
    this.workoutsToday = 0,
    this.workoutsThisWeek = 0,
    this.sources = const {},
    this.availableSources = const {},
    this.metricLastSeen = const {},
    this.providerMetrics = const {},
    this.providerLastSeen = const {},
    this.hourlySteps = const [],
    this.heartSamples = const [],
    this.weightHistory = const [],
    this.error,
  });

  final bool authorized;
  final int steps;
  final double? heartRate;
  final double? restingHeartRate;
  final double? hrvRmssd;
  final int sleepMinutes;
  final int sleepDeepMinutes;
  final int sleepLightMinutes;
  final int sleepRemMinutes;
  final double? activeCalories;
  final double? distanceMeters;
  final double? flightsClimbed;
  final double? bloodOxygen;
  final double? respiratoryRate;
  final double? weightLb;
  final double? bodyFatPercent;
  final double? bodyMassIndex;
  final double? bodyWaterKg;
  final int workoutsToday;
  final int workoutsThisWeek;
  final Map<String, String> sources;
  final Map<String, List<String>> availableSources;
  final Map<String, DateTime> metricLastSeen;
  final Map<String, List<String>> providerMetrics;
  final Map<String, DateTime> providerLastSeen;
  final List<double> hourlySteps;
  final List<TimedValue> heartSamples;
  final List<TimedValue> weightHistory;
  final String? error;
}

class HealthService {
  final Health _health = Health();

  static const Map<String, HealthDataType> _sourceTypes = {
    'Steps': HealthDataType.STEPS,
    'Distance': HealthDataType.DISTANCE_DELTA,
    'Flights Climbed': HealthDataType.FLIGHTS_CLIMBED,
    'Workouts': HealthDataType.WORKOUT,
    'Heart Rate': HealthDataType.HEART_RATE,
    'Resting Heart Rate': HealthDataType.RESTING_HEART_RATE,
    'HRV': HealthDataType.HEART_RATE_VARIABILITY_RMSSD,
    'Blood Oxygen': HealthDataType.BLOOD_OXYGEN,
    'Respiratory Rate': HealthDataType.RESPIRATORY_RATE,
    'Sleep': HealthDataType.SLEEP_SESSION,
    'Deep Sleep': HealthDataType.SLEEP_DEEP,
    'Light Sleep': HealthDataType.SLEEP_LIGHT,
    'REM Sleep': HealthDataType.SLEEP_REM,
    'Active Calories': HealthDataType.ACTIVE_ENERGY_BURNED,
    'Weight': HealthDataType.WEIGHT,
    'Body Fat': HealthDataType.BODY_FAT_PERCENTAGE,
    'BMI': HealthDataType.BODY_MASS_INDEX,
    'Body Water': HealthDataType.BODY_WATER_MASS,
  };

  static final List<HealthDataType> _types = _sourceTypes.values.toSet().toList();

  Future<HealthSnapshot> loadToday({
    Map<String, String> sourcePreference = const {},
  }) async {
    try {
      await _health.configure();
      await Permission.activityRecognition.request();

      var requestGranted = false;
      try {
        requestGranted = await _health.requestAuthorization(
          _types,
          permissions: List<HealthDataAccess>.filled(_types.length, HealthDataAccess.READ),
        );
      } catch (_) {
        // Reads are attempted one type at a time below. Optional or unsupported
        // types must not block core data such as steps, sleep, heart rate or weight.
      }

      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final recentStart = now.subtract(const Duration(days: 30));
      var readSucceeded = false;

      Future<List<HealthDataPoint>> readType(
        HealthDataType type,
        DateTime start,
        DateTime end,
      ) async {
        try {
          final raw = await _health.getHealthDataFromTypes(
            types: [type],
            startTime: start,
            endTime: end,
          );
          readSucceeded = true;
          return _health.removeDuplicates(raw);
        } catch (_) {
          return <HealthDataPoint>[];
        }
      }

      final todayPoints = <HealthDataType, List<HealthDataPoint>>{};
      final recentPoints = <HealthDataType, List<HealthDataPoint>>{};
      for (final type in _types) {
        todayPoints[type] = await readType(type, today, now);
        recentPoints[type] = await readType(type, recentStart, now);
      }

      String sourceLabel(HealthDataPoint point) {
        final name = point.sourceName.trim();
        if (name.isNotEmpty) return name;
        final id = point.sourceId.trim();
        return id.isEmpty ? 'Health Connect' : id;
      }

      bool sameSource(String a, String b) => a.trim().toLowerCase() == b.trim().toLowerCase();

      List<HealthDataPoint> allPoints(HealthDataType type) => <HealthDataPoint>[
            ...?recentPoints[type],
            ...?todayPoints[type],
          ];

      List<String> allSources(HealthDataType type) {
        final found = <String>{};
        for (final point in allPoints(type)) {
          found.add(sourceLabel(point));
        }
        final values = found.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
        return values;
      }

      String? chooseSource(String metric, HealthDataType type) {
        final available = allSources(type);
        if (available.isEmpty) return null;
        final requested = sourcePreference[metric] ?? 'Auto';
        if (requested != 'Auto' && requested != 'Manual') {
          for (final candidate in available) {
            if (sameSource(candidate, requested)) return candidate;
          }
        }

        final candidates = allPoints(type)..sort((a, b) => b.dateTo.compareTo(a.dateTo));
        return candidates.isEmpty ? available.first : sourceLabel(candidates.first);
      }

      List<HealthDataPoint> selectedPoints(String metric, HealthDataType type, {bool recent = false}) {
        final selected = chooseSource(metric, type);
        final points = recent ? (recentPoints[type] ?? const <HealthDataPoint>[]) : (todayPoints[type] ?? const <HealthDataPoint>[]);
        if (selected == null) return points;
        return points.where((point) => sameSource(sourceLabel(point), selected)).toList();
      }

      double? latestFrom(List<HealthDataPoint> points) {
        final sorted = [...points]..sort((a, b) => b.dateTo.compareTo(a.dateTo));
        for (final point in sorted) {
          final value = point.value;
          if (value is NumericHealthValue) return value.numericValue.toDouble();
        }
        return null;
      }

      double sumFrom(List<HealthDataPoint> points) {
        double total = 0;
        for (final point in points) {
          final value = point.value;
          if (value is NumericHealthValue) total += value.numericValue.toDouble();
        }
        return total;
      }

      DateTime? latestDate(List<HealthDataPoint> points) {
        if (points.isEmpty) return null;
        final sorted = [...points]..sort((a, b) => b.dateTo.compareTo(a.dateTo));
        return sorted.first.dateTo;
      }

      final sourceMap = <String, String>{};
      final availableSources = <String, List<String>>{};
      final metricLastSeen = <String, DateTime>{};
      final providerMetricSets = <String, Set<String>>{};
      final providerLastSeen = <String, DateTime>{};

      for (final entry in _sourceTypes.entries) {
        final metric = entry.key;
        final type = entry.value;
        final selected = chooseSource(metric, type);
        if (selected != null) sourceMap[metric] = selected;
        availableSources[metric] = allSources(type);
        final selectedRecent = selectedPoints(metric, type, recent: true);
        final seen = latestDate(selectedRecent);
        if (seen != null) metricLastSeen[metric] = seen;

        for (final point in allPoints(type)) {
          final source = sourceLabel(point);
          providerMetricSets.putIfAbsent(source, () => <String>{}).add(metric);
          final previous = providerLastSeen[source];
          if (previous == null || point.dateTo.isAfter(previous)) providerLastSeen[source] = point.dateTo;
        }
      }

      final providerMetrics = <String, List<String>>{};
      for (final entry in providerMetricSets.entries) {
        final values = entry.value.toList()..sort();
        providerMetrics[entry.key] = values;
      }

      final stepPoints = selectedPoints('Steps', HealthDataType.STEPS);
      final distancePoints = selectedPoints('Distance', HealthDataType.DISTANCE_DELTA);
      final flightsPoints = selectedPoints('Flights Climbed', HealthDataType.FLIGHTS_CLIMBED);
      final workoutPoints = selectedPoints('Workouts', HealthDataType.WORKOUT);
      final workoutRecent = selectedPoints('Workouts', HealthDataType.WORKOUT, recent: true);
      final weekStart = now.subtract(const Duration(days: 7));
      final workoutsThisWeek = workoutRecent.where((point) => point.dateTo.isAfter(weekStart)).length;
      final heartPoints = selectedPoints('Heart Rate', HealthDataType.HEART_RATE);
      final restingPoints = selectedPoints('Resting Heart Rate', HealthDataType.RESTING_HEART_RATE);
      final hrvPoints = selectedPoints('HRV', HealthDataType.HEART_RATE_VARIABILITY_RMSSD);
      final oxygenPoints = selectedPoints('Blood Oxygen', HealthDataType.BLOOD_OXYGEN);
      final respiratoryPoints = selectedPoints('Respiratory Rate', HealthDataType.RESPIRATORY_RATE);
      final sleepPoints = selectedPoints('Sleep', HealthDataType.SLEEP_SESSION);
      final deepSleepPoints = selectedPoints('Deep Sleep', HealthDataType.SLEEP_DEEP);
      final lightSleepPoints = selectedPoints('Light Sleep', HealthDataType.SLEEP_LIGHT);
      final remSleepPoints = selectedPoints('REM Sleep', HealthDataType.SLEEP_REM);
      final caloriePoints = selectedPoints('Active Calories', HealthDataType.ACTIVE_ENERGY_BURNED);
      final weightPointsToday = selectedPoints('Weight', HealthDataType.WEIGHT);
      final bodyFatPoints = selectedPoints('Body Fat', HealthDataType.BODY_FAT_PERCENTAGE);
      final bmiPoints = selectedPoints('BMI', HealthDataType.BODY_MASS_INDEX);
      final bodyWaterPoints = selectedPoints('Body Water', HealthDataType.BODY_WATER_MASS);

      final hourlySteps = List<double>.filled(24, 0);
      for (final point in stepPoints) {
        final value = point.value;
        if (value is NumericHealthValue) hourlySteps[point.dateFrom.hour] += value.numericValue.toDouble();
      }

      final heartSamples = <TimedValue>[];
      for (final point in heartPoints) {
        final value = point.value;
        if (value is NumericHealthValue) heartSamples.add(TimedValue(point.dateFrom, value.numericValue.toDouble()));
      }
      heartSamples.sort((a, b) => a.time.compareTo(b.time));

      final selectedWeightSource = chooseSource('Weight', HealthDataType.WEIGHT);
      final weightRecent = recentPoints[HealthDataType.WEIGHT] ?? const <HealthDataPoint>[];
      final weightHistory = <TimedValue>[];
      for (final point in weightRecent) {
        if (selectedWeightSource != null && !sameSource(sourceLabel(point), selectedWeightSource)) continue;
        final value = point.value;
        if (value is NumericHealthValue) {
          weightHistory.add(TimedValue(point.dateFrom, value.numericValue.toDouble() * 2.2046226218));
        }
      }
      weightHistory.sort((a, b) => a.time.compareTo(b.time));

      final kg = latestFrom(weightPointsToday);
      final authorized = requestGranted || readSucceeded;
      return HealthSnapshot(
        authorized: authorized,
        steps: sumFrom(stepPoints).round(),
        distanceMeters: sumFrom(distancePoints),
        flightsClimbed: sumFrom(flightsPoints),
        workoutsToday: workoutPoints.length,
        workoutsThisWeek: workoutsThisWeek,
        heartRate: latestFrom(heartPoints),
        restingHeartRate: latestFrom(restingPoints),
        hrvRmssd: latestFrom(hrvPoints),
        bloodOxygen: latestFrom(oxygenPoints),
        respiratoryRate: latestFrom(respiratoryPoints),
        sleepMinutes: sumFrom(sleepPoints).round(),
        sleepDeepMinutes: sumFrom(deepSleepPoints).round(),
        sleepLightMinutes: sumFrom(lightSleepPoints).round(),
        sleepRemMinutes: sumFrom(remSleepPoints).round(),
        activeCalories: sumFrom(caloriePoints),
        weightLb: kg == null ? null : kg * 2.2046226218,
        bodyFatPercent: latestFrom(bodyFatPoints),
        bodyMassIndex: latestFrom(bmiPoints),
        bodyWaterKg: latestFrom(bodyWaterPoints),
        sources: sourceMap,
        availableSources: availableSources,
        metricLastSeen: metricLastSeen,
        providerMetrics: providerMetrics,
        providerLastSeen: providerLastSeen,
        hourlySteps: hourlySteps,
        heartSamples: heartSamples,
        weightHistory: weightHistory,
        error: authorized ? null : 'Health Connect permission is still needed.',
      );
    } catch (e) {
      return HealthSnapshot(error: e.toString());
    }
  }
}
