import 'dart:convert';
import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../state/app_state.dart';

class StorageService {
  static const _legacyStateKey = 'healthy_me_state_v03';
  static const _stateKey = 'healthy_me_state_v1';

  // Existing source-first app API. Keep this intact so the checked-in modular
  // screens/tests continue to compile while v0.7 becomes the app entry point.
  SharedPreferencesAsync get _prefs => SharedPreferencesAsync();

  Future<HealthyMeState> load() async {
    final raw = await _prefs.getString(_legacyStateKey);
    if (raw == null || raw.isEmpty) return const HealthyMeState();
    try {
      return HealthyMeState.fromJson(
        jsonDecode(raw) as Map<String, dynamic>,
      );
    } catch (_) {
      return const HealthyMeState();
    }
  }

  Future<void> save(HealthyMeState state) {
    return _prefs.setString(_legacyStateKey, state.encode());
  }

  // v0.7 app-state persistence API.
  Future<Map<String, dynamic>> loadState() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_stateKey);
    if (raw == null || raw.isEmpty) return <String, dynamic>{};
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  Future<void> saveState(Map<String, dynamic> state) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_stateKey, jsonEncode(state));
  }

  Future<String?> pickAndStoreProgressPhoto(String view) async {
    final picker = ImagePicker();
    final image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 90,
    );
    if (image == null) return null;

    final dir = await getApplicationDocumentsDirectory();
    final photos = Directory('${dir.path}/progress_photos');
    if (!await photos.exists()) await photos.create(recursive: true);

    final ext = image.path.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
    final name =
        '${DateTime.now().millisecondsSinceEpoch}_${view.toLowerCase()}.$ext';
    final target = '${photos.path}/$name';
    await File(image.path).copy(target);
    return target;
  }
}
