# Healthy Me — Locked Product Direction

Updated: 2026-09-28

## Source of truth
The approved visual reference is the 10-screen dark Healthy Me mockup signed off in this project. New builds should match that visual structure rather than inventing a new design language.

Approved primary screens:
1. Dashboard / Home
2. Activity
3. Sleep
4. Heart Health
5. Weight & Goals
6. Profile / User Info
7. Body Measurements
8. Progress Photos
9. Devices & Sources
10. Goals & Progress

Bottom navigation: Home / Activity / Sleep / Body / More.

## Core product principles
- Vendor independent. Do not hard-code Garmin, Samsung, Fitbit, Pixel, Apple, Xiaomi, etc. as required sources.
- Health Connect is the Android aggregation layer; Apple HealthKit is the future iOS aggregation layer.
- Per-metric source selection is dynamic: Auto / Recommended + only sources actually detected for that metric.
- Translate known package/provider IDs into friendly names, but unknown providers must still be shown rather than hidden.
- One preferred source per metric to reduce duplicate data.
- Always make it possible to answer “Where did this number come from?”
- Prefer understandable measurements and trends over proprietary mystery scores.
- Recommendations must be explainable and based on evidence or the user's own longitudinal data.
- User data should remain understandable, portable and not be trapped behind a subscription.

## Health data behavior
### Dashboard
Keep the approved dark UI with prominent steps, calories/distance/floors, heart rate, sleep, weight and activity cards. Small source badges may identify the provider without clutter.

### Activity
- Day / Week / Month / Year.
- Match the approved visual treatment: shaded/gradient bar chart with stronger green emphasis around higher activity, blue/cyan elsewhere.
- Workouts shown below chart.

### Sleep
- Do not ask the user to invent a sleep goal.
- Use age-based evidence-informed recommended ranges.
- Adults 18–64: show recommended 7–9 hours/night.
- Adults 65+: show recommended 7–8 hours/night.
- Teen 13–17: show 8–10 hours/night.
- Child 6–12: show 9–12 hours/night.
- If birthday is missing, show “Add birthday for guidance” rather than guessing.
- Future refinement may use individual patterns, but should never claim that an adaptive value is a medical guideline.
- Include a “Why this recommendation?” explanation with guideline sources in a future information sheet.

Reference sources:
- National Sleep Foundation sleep-duration recommendations: https://www.thensf.org/how-many-hours-of-sleep-do-you-really-need/
- American Academy of Sleep Medicine / Sleep Research Society adult sleep consensus: adults should regularly obtain at least 7 hours/night for health.

### Body composition
- Body fat is NOT a manual health measurement input.
- Read body fat from Health Connect / HealthKit / connected body-composition scale or other supported data source.
- If no body-fat source is present, show “No device data.”
- Manual tape measurements remain supported: neck, chest, waist, hips, left/right arms, left/right thighs, left/right calves.
- Body Measurements screen should use a polished front/back human silhouette with clearly placed measurement markers.

### Progress photos
- Front / side / back.
- Date stamped.
- Grouped by date.
- Future: compare dates and slider.

### Devices & Sources
- Dynamic provider discovery.
- Device/provider cards are generated from actual detected Health Connect data origins.
- Metric source picker: Auto + sources detected for that exact metric.
- Do not hard-code Samsung as the Steps alternative, Garmin as the Heart alternative, etc.
- Manual source may be offered only where Healthy Me truly supports manual entry (for example weight).
- CPAP remains a reserved connector until the exact device/app integration is known.

### Profile
Fields:
- name / nickname
- birthday (age calculated automatically)
- sex
- height
- start date
- start weight
- goal weight
- preferred units
- activity level
- device timezone

Profile layout must remain responsive on narrow Android screens. Labels cannot collapse to one-character columns.

## Bloodwork
Add a Bloodwork section now.

Store exactly what the user provides:
- test name
- result
- units
- collection date
- lab / source

Do NOT automatically label results high/low and do NOT diagnose from a single value.

The future Diet section may use bloodwork as one input along with weight trend, activity, sleep, body measurements, preferences and goals. Nutrition recommendations should explain which inputs drove the suggestion and distinguish evidence from inference.

## Future Diet direction
Not part of v0.4 implementation beyond preparing bloodwork data.

Design principles:
- Use actual intake + actual weight trend when enough data exists rather than blindly trusting wearable calorie-burn estimates.
- Include micronutrients rather than only calories/macros.
- Adjust recommendations gradually from observed results.
- State when data is insufficient.
- Never infer a deficiency/disease from one lab value without appropriate context.

## Competitive review — strengths to borrow / weaknesses to avoid

### Apple Health
Strengths: central repository, trends, privacy, medical/health record aggregation, broad third-party support.
Weakness: can feel like a database; source management can be buried.
Healthy Me: be the understandable layer above the raw database.

### Samsung Health
Strengths: broad coverage of steps, exercise, food, sleep, body composition and other health metrics.
Weakness: vendor-centric concepts and ecosystem dependence.
Healthy Me: broad coverage without Samsung-specific assumptions.

### Garmin Connect
Strengths: deep workouts, trends, device metrics, courses and detailed fitness data.
Weakness: dense and Garmin-centric; syncing/pairing can add friction.
Healthy Me: preserve depth on detail pages while keeping the home screen simple.

### Oura
Strengths: excellent simplification of physiology into clean daily views; strong sleep/activity presentation.
Weakness: proprietary scores can become black boxes; tied to hardware/membership.
Healthy Me: simple summaries with visible underlying data and “Why?” explanations.

### WHOOP
Strengths: connects sleep, strain and recovery to suggested behavior.
Weakness: highly score-centric and tied to hardware/subscription.
Healthy Me: recommendations can combine multiple metrics without requiring one vendor or proprietary score.

### Bevel
Strengths: strong data-source management and Apple Health aggregation; clear missing-data behavior.
Weakness: advanced scores can disappear when necessary metrics are unavailable.
Healthy Me: dynamic per-metric source priority, explicit missing-data explanations, no hidden assumptions.

### Gentler Streak
Strengths: excellent visual design; treats rest as a valid recommendation rather than failure.
Weakness: primarily fitness focused.
Healthy Me: recommendations should support recovery/rest when appropriate rather than punishing missed activity.

### Cronometer
Strengths: deep nutrition database and micronutrient tracking.
Weakness: can overwhelm normal users with detail.
Healthy Me Diet: simple actionable nutrition first; deep nutrient detail one layer down.

### MacroFactor
Strengths: adapts calorie recommendations from logged intake and actual weight trend rather than trusting estimated energy expenditure alone.
Weakness: depends on consistent food logging.
Healthy Me Diet: learn from observed results when enough data exists and clearly say when data is insufficient.

### Guava
Strengths: medical-record, lab, PDF and wearable aggregation; good lab extraction model.
Weakness: can become more of a record repository than an everyday wellness dashboard.
Healthy Me Bloodwork: clean storage and history without turning the app into a medical chart.

### InsideTracker
Strengths: combines biomarkers and lifestyle information into nutrition/lifestyle action plans.
Weakness: recommendations can feel overly authoritative if reasoning is hidden.
Healthy Me: expose which data drove each recommendation and the evidence behind it.

### Welltory
Strengths: personal baselines and plain-language HRV explanations.
Weakness: derived wellness scores can imply false precision.
Healthy Me: use personal baselines but avoid mystery scores and false certainty.

### Bearable / Exist
Strengths: customizable tracking and correlation views across habits, symptoms, sleep and lifestyle.
Weakness: correlations can be mistaken for causation and manual logging can become burdensome.
Healthy Me: optional habit tags later; describe relationships as associations, not causes.

### Gadgetbridge
Strengths: open-source, local-first wearable support without mandatory vendor cloud accounts.
Weakness: uneven device support and technical complexity.
Healthy Me: long-term option for local/direct connectors while keeping the UI polished.

### openScale
Strengths: open-source smart-scale support, Bluetooth body metrics, local ownership, Health Connect sync.
Weakness: hardware compatibility varies.
Healthy Me: connected body-composition data should come from detected sources rather than forced manual entry.

### FitoTrack / OpenTracks
Strengths: private/open-source workout tracking and exportability.
Weakness: less polished than premium commercial products.
Healthy Me: preserve privacy/exportability without sacrificing visual quality.

### Zepp / Amazfit
Strengths: daily snapshot followed by deeper trend pages; improving local-first controls.
Weakness: still centered on one device ecosystem and proprietary readiness concepts.
Healthy Me: daily snapshot -> detail -> trend hierarchy, but vendor independent.

### Huawei Health / Mi Fitness
Strengths: straightforward goal and timeline experiences with broad wearable metrics.
Weakness: primarily vendor companion apps.
Healthy Me: same simplicity regardless of manufacturer.

## Product positioning
Healthy Me should sit between a raw health database (Apple Health / Samsung Health / Health Connect) and a personalized health interpretation layer (Oura / Bevel / Guava), without locking the user to one wearable or hiding conclusions behind opaque scores.

Core differentiators:
1. Vendor-independent aggregation.
2. Dynamic source priority per metric.
3. Explainable recommendations.
4. Clean long-term trends.
5. Bloodwork integrated into the same personal health picture.
6. Future adaptive nutrition based on real outcomes and evidence.
7. User-owned, understandable data.

## v0.5 correction build
- Body Metrics uses the approved front/back human measurement reference instead of a simplified drawn silhouette.
- Metric source rows are fully tappable and open a source picker.
- Source options are Auto/Recommended plus providers actually detected for that metric; Weight may also use Manual.
- Source selection is persisted and re-syncs health data using the chosen provider.
- Health Connect reads are isolated by metric so an unavailable optional type cannot block all other metrics.
- Provider discovery uses a 30-day Health Connect lookback.
- Release builds must verify the permanent beta signing certificate before upload.

## Beta 0.7 — Daily State / Morning Check-In

### Purpose
Give the user a quick, non-diagnostic answer to “where am I today?” that accounts for subjective recovery and stress instead of letting wearable data create an implausibly high recovery number when the user feels poorly.

### Daily check-in structure
Healthy Me tracks eight recovery/stress domains selected from Short Recovery and Stress Scale (SRSS) research:
- Physical capability
- Mental capability
- Emotional balance
- Overall recovery
- Body / muscular stress
- Lack of activation
- Negative emotional state
- Overall stress

Each item is entered on a 0–6 scale. Recovery and stress are calculated and displayed as separate 0–6 averages. Healthy Me MUST NOT describe its own summary label as an official SRSS cutoff or validated readiness percentage.

### Trigger behavior
- Feature is optional.
- User chooses the daily start time.
- It does not appear before the configured start time merely because the app launches/resumes.
- A one-minute in-app clock refresh lets the card become available at the configured time if the app was left open.
- User can complete or dismiss it for the current day.
- One completed check-in per calendar day; editing replaces that day’s check-in.

### Personal baseline
- Build a user-specific baseline after at least 7 prior completed days.
- Compare today with up to the most recent 30 prior check-ins.
- Baseline comparison is descriptive: below recent normal / near recent normal / better than recent normal.
- Do not claim population medical normality.

### Coaching response
If today shows low recovery, elevated stress, lack of activation, negative emotional state or muscular stress, Healthy Me may offer a small evidence-supported wellness action, such as:
- 10-minute easy walk
- 5-minute quiet breathing / reset
- lighter workout or recovery activity

The user can record whether the action made them feel Worse / Same / A little better / A lot better. Over time this feedback can be used to personalize which reset Healthy Me offers first.

### Scientific guardrail
The SRSS is a validated recovery/stress monitoring instrument in athlete populations, not a diagnostic mental-health instrument. Healthy Me beta uses the selected recovery/stress framework for wellness monitoring. Exact licensed instrument wording/duplication rights must be reviewed before commercial release.

### Evidence notes
- Kölling S, et al. Validation of the Acute Recovery and Stress Scale (ARSS) and the Short Recovery and Stress Scale (SRSS) in three English-speaking regions. J Sports Sci. 2020;38(2):130-139. PMID: 31696778.
- Weinstein AA, et al. Affective Responses to Acute Exercise: A Meta-Analysis of the Potential Beneficial Effects of a Single Bout of Exercise on General Mood, Anxiety, and Depressive Symptoms. Psychosom Med. 2024;86(6):486-497. PMID: 38787545.
- Edwards MK, Loprinzi PD. Experimental effects of brief, single bouts of walking and meditation on mood profile in young adults. Health Promot Perspect. 2018;8(3):171-178. PMID: 30087839.
