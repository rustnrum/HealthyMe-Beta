# Changelog

## 0.7.0 — 2026-10-03
- Added Daily State / Morning Check-In.
- Added configurable morning start time and daily dismissal.
- Added eight 0–6 recovery/stress inputs.
- Added separate Recovery and Stress results rather than an invented clinical readiness percentage.
- Added user-specific recovery/stress baseline after 7 prior check-ins.
- Added reset actions and user feedback tracking.
- Fed Daily State into the existing wellness suggestion engine.
- Added Daily State dashboard card, detail screen, history and settings.
- Added product/evidence documentation and explicit SRSS licensing guardrail.

## 0.6.0
- Dynamic Health Connect/source architecture.
- Bloodwork import and biomarker organization.
- Profile-aware hormone panels.
- Initial explainable wellness recommendation system.
