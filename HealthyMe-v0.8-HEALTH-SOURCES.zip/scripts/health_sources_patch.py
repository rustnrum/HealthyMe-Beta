#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path.cwd()

def read(path):
    return (ROOT / path).read_text()

def write(path, text):
    (ROOT / path).write_text(text)

def replace_required(text, old, new, label):
    if old not in text:
        raise SystemExit(f"PATCH ERROR: anchor not found: {label}")
    return text.replace(old, new, 1)

# ---- pubspec/version -------------------------------------------------------
pub = read("pubspec.yaml")
pub = re.sub(r"(?m)^version:\s*.+$", "version: 0.8.0+12", pub, count=1)
write("pubspec.yaml", pub)

# ---- friendly source identity --------------------------------------------
source_service = r"""class SourceNameService {
  static String key({
    required String sourceId,
    required String sourceName,
  }) {
    final id = sourceId.trim();
    if (id.isNotEmpty) return id;
    return sourceName.trim();
  }

  static String displayFor({
    required String sourceId,
    required String sourceName,
  }) {
    final name = sourceName.trim();
    if (name.isNotEmpty && !_looksLikePackageId(name)) {
      return friendly(name);
    }
    final id = sourceId.trim();
    if (id.isNotEmpty) return friendly(id);
    return friendly(name);
  }

  static String friendly(String source) {
    final raw = source.trim();
    final lower = raw.toLowerCase();
    if (lower.isEmpty) return 'Connected source';

    // These mappings are display-only. Metric behavior remains provider-neutral.
    if (lower.contains('com.app.cq.ring') ||
        lower == 'qring' ||
        lower.contains('qring')) {
      return 'QRing';
    }
    if (lower.contains('com.xs.imoni') ||
        lower == 'imoni' ||
        lower.contains('imoni')) {
      return 'iMoni';
    }
    if (lower.contains('health connect') ||
        lower.contains('healthconnect') ||
        lower.contains('com.android.healthconnect') ||
        lower.contains('com.google.android.apps.healthdata')) {
      return 'Health Connect';
    }
    if (lower.contains('samsung') ||
        lower.contains('shealth') ||
        lower.contains('com.sec.android.app.shealth')) {
      return 'Samsung Health';
    }
    if (lower.contains('garmin')) return 'Garmin Connect';
    if (lower.contains('fitbit')) return 'Fitbit';
    if (lower.contains('withings')) return 'Withings';
    if (lower.contains('google fit') ||
        lower.contains('com.google.android.apps.fitness')) {
      return 'Google Fit';
    }
    if (lower.contains('polar')) return 'Polar';
    if (lower.contains('oura')) return 'Oura';
    if (lower.contains('whoop')) return 'WHOOP';
    if (lower.contains('zepp')) return 'Zepp';

    if (_looksLikePackageId(raw)) {
      return _packageBrand(raw);
    }

    return raw;
  }

  static bool _looksLikePackageId(String value) {
    final lower = value.toLowerCase();
    return (lower.startsWith('com.') ||
            lower.startsWith('org.') ||
            lower.startsWith('net.') ||
            lower.startsWith('io.') ||
            lower.startsWith('co.') ||
            lower.startsWith('fi.')) &&
        value.contains('.');
  }

  static String _packageBrand(String value) {
    final parts = value
        .split('.')
        .map((part) => part.trim())
        .where((part) => part.isNotEmpty)
        .toList();
    const ignored = {
      'com',
      'org',
      'net',
      'io',
      'co',
      'fi',
      'android',
      'app',
      'apps',
      'mobile',
      'health',
      'fitness',
      'client',
      'phone',
      'wear',
    };
    for (final part in parts) {
      final lower = part.toLowerCase();
      if (!ignored.contains(lower) && lower.length > 2) {
        return _prettyToken(part);
      }
    }
    return 'Connected source';
  }

  static String _prettyToken(String value) {
    var text = value
        .replaceAll(RegExp(r'[_-]+'), ' ')
        .replaceAllMapped(
          RegExp(r'([a-z])([A-Z])'),
          (match) => '${match.group(1)} ${match.group(2)}',
        )
        .trim();
    if (text.isEmpty) return 'Connected source';
    text = text.toLowerCase();
    return '${text[0].toUpperCase()}${text.substring(1)}';
  }

  static List<String> uniqueRawByFriendly(Iterable<String> sources) {
    final result = <String>[];
    final seen = <String>{};
    for (final source in sources) {
      final name = friendly(source);
      if (name == 'Health Connect') continue;
      if (seen.add(name)) result.add(source);
    }
    return result;
  }

  static bool detected(Iterable<String> sources, String provider) {
    return sources.any((source) => friendly(source) == provider);
  }

  static bool sameProvider(String a, String b) {
    if (a.trim().isEmpty || b.trim().isEmpty) return false;
    if (a.trim() == b.trim()) return true;
    return friendly(a) == friendly(b);
  }

  static bool pointMatches({
    required String selected,
    required String sourceId,
    required String sourceName,
  }) {
    return sameProvider(selected, sourceId) ||
        sameProvider(selected, sourceName);
  }
}
"""
write("lib/services/source_name_service.dart", source_service)

# ---- HealthSnapshot provenance/body-composition fields -------------------
models = read("lib/models/models.dart")
models = replace_required(
    models,
    "  final double? bodyFatPercent;\n  final double? bloodOxygenPercent;",
    "  final double? bodyFatPercent;\n"
    "  final double? bodyWaterMassKg;\n"
    "  final double? leanBodyMassKg;\n"
    "  final double? bloodOxygenPercent;",
    "model body fields",
)
models = replace_required(
    models,
    "  final Map<String, List<String>> availableSources;\n  final Map<String, DateTime> freshness;",
    "  final Map<String, List<String>> availableSources;\n"
    "  final Map<String, String> sourceLabels;\n"
    "  final Map<String, String> resolvedSources;\n"
    "  final Map<String, DateTime> sourceLastSeen;\n"
    "  final Map<String, DateTime> freshness;",
    "model source fields",
)
models = replace_required(
    models,
    "    this.bodyFatPercent,\n    this.bloodOxygenPercent,",
    "    this.bodyFatPercent,\n"
    "    this.bodyWaterMassKg,\n"
    "    this.leanBodyMassKg,\n"
    "    this.bloodOxygenPercent,",
    "constructor body args",
)
models = replace_required(
    models,
    "    this.availableSources = const {},\n    this.freshness = const {},",
    "    this.availableSources = const {},\n"
    "    this.sourceLabels = const {},\n"
    "    this.resolvedSources = const {},\n"
    "    this.sourceLastSeen = const {},\n"
    "    this.freshness = const {},",
    "constructor source args",
)
models = replace_required(
    models,
    "    double? bodyFatPercent,\n    double? bloodOxygenPercent,",
    "    double? bodyFatPercent,\n"
    "    double? bodyWaterMassKg,\n"
    "    double? leanBodyMassKg,\n"
    "    double? bloodOxygenPercent,",
    "copyWith body params",
)
models = replace_required(
    models,
    "    Map<String, List<String>>? availableSources,\n    Map<String, DateTime>? freshness,",
    "    Map<String, List<String>>? availableSources,\n"
    "    Map<String, String>? sourceLabels,\n"
    "    Map<String, String>? resolvedSources,\n"
    "    Map<String, DateTime>? sourceLastSeen,\n"
    "    Map<String, DateTime>? freshness,",
    "copyWith source params",
)
models = replace_required(
    models,
    "      bodyFatPercent: bodyFatPercent ?? this.bodyFatPercent,\n"
    "      bloodOxygenPercent: bloodOxygenPercent ?? this.bloodOxygenPercent,",
    "      bodyFatPercent: bodyFatPercent ?? this.bodyFatPercent,\n"
    "      bodyWaterMassKg: bodyWaterMassKg ?? this.bodyWaterMassKg,\n"
    "      leanBodyMassKg: leanBodyMassKg ?? this.leanBodyMassKg,\n"
    "      bloodOxygenPercent: bloodOxygenPercent ?? this.bloodOxygenPercent,",
    "copyWith body assign",
)
models = replace_required(
    models,
    "      availableSources: availableSources ?? this.availableSources,\n"
    "      freshness: freshness ?? this.freshness,",
    "      availableSources: availableSources ?? this.availableSources,\n"
    "      sourceLabels: sourceLabels ?? this.sourceLabels,\n"
    "      resolvedSources: resolvedSources ?? this.resolvedSources,\n"
    "      sourceLastSeen: sourceLastSeen ?? this.sourceLastSeen,\n"
    "      freshness: freshness ?? this.freshness,",
    "copyWith source assign",
)
models = replace_required(
    models,
    "        'bodyFatPercent': bodyFatPercent,\n"
    "        'bloodOxygenPercent': bloodOxygenPercent,",
    "        'bodyFatPercent': bodyFatPercent,\n"
    "        'bodyWaterMassKg': bodyWaterMassKg,\n"
    "        'leanBodyMassKg': leanBodyMassKg,\n"
    "        'bloodOxygenPercent': bloodOxygenPercent,",
    "json body",
)
models = replace_required(
    models,
    "        'availableSources': availableSources,\n"
    "        'freshness': freshness.map(",
    "        'availableSources': availableSources,\n"
    "        'sourceLabels': sourceLabels,\n"
    "        'resolvedSources': resolvedSources,\n"
    "        'sourceLastSeen': sourceLastSeen.map(\n"
    "          (key, value) => MapEntry(key, value.toIso8601String()),\n"
    "        ),\n"
    "        'freshness': freshness.map(",
    "json sources",
)
models = replace_required(
    models,
    "    final rawSources =\n"
    "        json['availableSources'] as Map<String, dynamic>? ?? const {};\n",
    "    final rawSources =\n"
    "        json['availableSources'] as Map<String, dynamic>? ?? const {};\n"
    "    final rawSourceLabels =\n"
    "        json['sourceLabels'] as Map<String, dynamic>? ?? const {};\n"
    "    final rawResolvedSources =\n"
    "        json['resolvedSources'] as Map<String, dynamic>? ?? const {};\n"
    "    final rawSourceLastSeen =\n"
    "        json['sourceLastSeen'] as Map<String, dynamic>? ?? const {};\n",
    "fromJson raw source maps",
)
models = replace_required(
    models,
    "      bodyFatPercent: (json['bodyFatPercent'] as num?)?.toDouble(),\n"
    "      bloodOxygenPercent:",
    "      bodyFatPercent: (json['bodyFatPercent'] as num?)?.toDouble(),\n"
    "      bodyWaterMassKg: (json['bodyWaterMassKg'] as num?)?.toDouble(),\n"
    "      leanBodyMassKg: (json['leanBodyMassKg'] as num?)?.toDouble(),\n"
    "      bloodOxygenPercent:",
    "fromJson body values",
)
models = replace_required(
    models,
    "      freshness: rawFresh.map(\n",
    "      sourceLabels: rawSourceLabels.map(\n"
    "        (key, value) => MapEntry(key, value.toString()),\n"
    "      ),\n"
    "      resolvedSources: rawResolvedSources.map(\n"
    "        (key, value) => MapEntry(key, value.toString()),\n"
    "      ),\n"
    "      sourceLastSeen: rawSourceLastSeen.map(\n"
    "        (key, value) => MapEntry(\n"
    "          key,\n"
    "          DateTime.tryParse(value.toString()) ?? DateTime.now(),\n"
    "        ),\n"
    "      ),\n"
    "      freshness: rawFresh.map(\n",
    "fromJson source values",
)
write("lib/models/models.dart", models)

# ---- Health Connect: stable origin identity + independent metric sources --
hc = read("lib/services/health_connect_service.dart")
hc = replace_required(
    hc,
    "    HealthDataType.BODY_FAT_PERCENTAGE,\n"
    "    HealthDataType.SLEEP_ASLEEP,",
    "    HealthDataType.BODY_FAT_PERCENTAGE,\n"
    "    HealthDataType.BODY_WATER_MASS,\n"
    "    HealthDataType.LEAN_BODY_MASS,\n"
    "    HealthDataType.SLEEP_ASLEEP,",
    "health types body composition",
)

old_source_block = """    final sources = points
        .map((p) => p.sourceName.trim())
        .where((name) => name.isNotEmpty)
        .toSet()
        .toList()
      ..sort();

    bool sourceMatches(HealthDataPoint point, String? selectedSource) {
      if (selectedSource == null || selectedSource == 'Auto') return true;
      return SourceNameService.sameProvider(point.sourceName, selectedSource);
    }

    List<HealthDataPoint> filtered(
      HealthDataType type,
      String metric,
    ) {
      final source = metricSources[metric];
      return points.where((p) {
        if (p.type != type) return false;
        return sourceMatches(p, source);
      }).toList()
        ..sort((a, b) => a.dateTo.compareTo(b.dateTo));
    }

    List<HealthDataPoint> filteredForSource(
      HealthDataType type,
      String? selectedSource,
    ) {
      return points.where((p) {
        if (p.type != type) return false;
        return sourceMatches(p, selectedSource);
      }).toList()
        ..sort((a, b) => a.dateTo.compareTo(b.dateTo));
    }
"""

new_source_block = """    String originKey(HealthDataPoint point) => SourceNameService.key(
          sourceId: point.sourceId,
          sourceName: point.sourceName,
        );

    String originLabel(HealthDataPoint point) => SourceNameService.displayFor(
          sourceId: point.sourceId,
          sourceName: point.sourceName,
        );

    final sourceLabels = <String, String>{};
    final sourceLastSeen = <String, DateTime>{};
    for (final point in points) {
      final key = originKey(point);
      if (key.isEmpty) continue;
      sourceLabels[key] = originLabel(point);
      final previous = sourceLastSeen[key];
      if (previous == null || point.dateTo.isAfter(previous)) {
        sourceLastSeen[key] = point.dateTo;
      }
    }

    final sources = sourceLabels.keys.toList()
      ..sort((a, b) => (sourceLabels[a] ?? a).compareTo(sourceLabels[b] ?? b));

    bool sourceMatches(HealthDataPoint point, String? selectedSource) {
      if (selectedSource == null || selectedSource == 'Auto') return true;
      return SourceNameService.pointMatches(
        selected: selectedSource,
        sourceId: point.sourceId,
        sourceName: point.sourceName,
      );
    }

    final resolvedSources = <String, String>{};

    String? latestOriginForTypes(Iterable<HealthDataType> types) {
      final allowed = types.toSet();
      HealthDataPoint? latest;
      for (final point in points) {
        if (!allowed.contains(point.type) || originKey(point).isEmpty) continue;
        if (latest == null || point.dateTo.isAfter(latest.dateTo)) {
          latest = point;
        }
      }
      return latest == null ? null : originKey(latest);
    }

    String? resolvedOrigin(
      String metric,
      Iterable<HealthDataType> types,
    ) {
      final selected = metricSources[metric];
      if (selected != null && selected != 'Auto') {
        final matching = points
            .where((p) => types.contains(p.type) && sourceMatches(p, selected))
            .toList()
          ..sort((a, b) => a.dateTo.compareTo(b.dateTo));
        if (matching.isNotEmpty) {
          final key = originKey(matching.last);
          if (key.isNotEmpty) {
            resolvedSources[metric] = key;
            return key;
          }
        }
      }

      final auto = latestOriginForTypes(types);
      if (auto != null) resolvedSources[metric] = auto;
      return auto;
    }

    List<HealthDataPoint> filtered(
      HealthDataType type,
      String metric,
    ) {
      final resolved = resolvedOrigin(metric, [type]);
      if (resolved == null) return <HealthDataPoint>[];
      return points.where((p) {
        if (p.type != type) return false;
        return originKey(p) == resolved;
      }).toList()
        ..sort((a, b) => a.dateTo.compareTo(b.dateTo));
    }

    List<HealthDataPoint> filteredForSource(
      HealthDataType type,
      String? selectedSource,
    ) {
      return points.where((p) {
        if (p.type != type) return false;
        return sourceMatches(p, selectedSource);
      }).toList()
        ..sort((a, b) => a.dateTo.compareTo(b.dateTo));
    }
"""
hc = replace_required(hc, old_source_block, new_source_block, "source identity block")

# Steps: selected source uses raw records; Auto uses Health Connect aggregate.
hc = replace_required(
    hc,
    "    final rawSteps = filtered(HealthDataType.STEPS, 'Steps');\n",
    """    final selectedStepSource = metricSources['Steps'];
    final allStepPoints = points
        .where((p) => p.type == HealthDataType.STEPS)
        .toList()
      ..sort((a, b) => a.dateTo.compareTo(b.dateTo));
    final rawSteps = selectedStepSource != null && selectedStepSource != 'Auto'
        ? allStepPoints.where((p) => sourceMatches(p, selectedStepSource)).toList()
        : allStepPoints;
    if (selectedStepSource != null &&
        selectedStepSource != 'Auto' &&
        rawSteps.isNotEmpty) {
      resolvedSources['Steps'] = originKey(rawSteps.last);
    } else {
      const aggregateKey = '__health_connect_steps_aggregate__';
      sourceLabels[aggregateKey] = 'Health Connect aggregate';
      resolvedSources['Steps'] = aggregateKey;
    }
""",
    "steps source resolution",
)

# Remove duplicate selectedStepSource declaration later.
hc = replace_required(
    hc,
    "    final selectedStepSource = metricSources['Steps'];\n"
    "    final resolvedMotionSource =\n"
    "        selectedStepSource != null && selectedStepSource != 'Auto'\n"
    "            ? selectedStepSource\n"
    "            : _latestSourceFor(points, HealthDataType.STEPS) ??\n"
    "                _latestSourceFor(points, HealthDataType.DISTANCE_DELTA);\n",
    """    final resolvedMotionSource =
        selectedStepSource != null && selectedStepSource != 'Auto'
            ? resolvedSources['Steps']
            : latestOriginForTypes([
                HealthDataType.STEPS,
                HealthDataType.DISTANCE_DELTA,
              ]);
""",
    "motion source resolution",
)

# filteredForSource must understand stable origin keys too.
hc = replace_required(
    hc,
    "        return sourceMatches(p, selectedSource);\n"
    "      }).toList()\n"
    "        ..sort((a, b) => a.dateTo.compareTo(b.dateTo));\n"
    "    }\n\n    double? number",
    "        if (selectedSource == null) return true;\n"
    "        return originKey(p) == selectedSource || sourceMatches(p, selectedSource);\n"
    "      }).toList()\n"
    "        ..sort((a, b) => a.dateTo.compareTo(b.dateTo));\n"
    "    }\n\n    double? number",
    "stable source filter",
)

# Sleep must resolve to one provider instead of mixing every provider in Auto.
old_sleep = """    final sleepSource = metricSources['Sleep'];
    final sleepTypes = <HealthDataType>[
      HealthDataType.SLEEP_ASLEEP,
      HealthDataType.SLEEP_AWAKE,
      HealthDataType.SLEEP_REM,
      HealthDataType.SLEEP_LIGHT,
      HealthDataType.SLEEP_DEEP,
    ];

    final sleepPoints = points.where((p) {
      if (!sleepTypes.contains(p.type)) return false;
      return sourceMatches(p, sleepSource);
    }).toList();
"""
new_sleep = """    final sleepTypes = <HealthDataType>[
      HealthDataType.SLEEP_ASLEEP,
      HealthDataType.SLEEP_AWAKE,
      HealthDataType.SLEEP_REM,
      HealthDataType.SLEEP_LIGHT,
      HealthDataType.SLEEP_DEEP,
    ];

    final sleepResolved = resolvedOrigin('Sleep', sleepTypes);
    final sleepPoints = points.where((p) {
      if (!sleepTypes.contains(p.type)) return false;
      return sleepResolved != null && originKey(p) == sleepResolved;
    }).toList();
"""
hc = replace_required(hc, old_sleep, new_sleep, "sleep resolution")

# Split vital source settings instead of routing all through "Heart rate".
hc = hc.replace(
    "      'Heart rate',\n    );\n    final restingValues",
    "      'Resting heart rate',\n    );\n    final restingValues",
    1,
)
hc = hc.replace(
    "      'Heart rate',\n    );\n    final respiratory = filtered(",
    "      'HRV',\n    );\n    final respiratory = filtered(",
    1,
)
hc = hc.replace(
    "      HealthDataType.RESPIRATORY_RATE,\n      'Heart rate',",
    "      HealthDataType.RESPIRATORY_RATE,\n      'Respiratory rate',",
    1,
)
hc = hc.replace(
    "      HealthDataType.BLOOD_OXYGEN,\n      'Heart rate',",
    "      HealthDataType.BLOOD_OXYGEN,\n      'SpO2',",
    1,
)

# Body composition additions.
hc = replace_required(
    hc,
    "    final bodyFat = filtered(\n"
    "      HealthDataType.BODY_FAT_PERCENTAGE,\n"
    "      'Body fat',\n"
    "    );\n",
    "    final bodyFat = filtered(\n"
    "      HealthDataType.BODY_FAT_PERCENTAGE,\n"
    "      'Body fat',\n"
    "    );\n"
    "    final bodyWater = filtered(\n"
    "      HealthDataType.BODY_WATER_MASS,\n"
    "      'Body water',\n"
    "    );\n"
    "    final leanBodyMass = filtered(\n"
    "      HealthDataType.LEAN_BODY_MASS,\n"
    "      'Lean body mass',\n"
    "    );\n",
    "body composition lists",
)

# Friendly source labels on history/workouts.
hc = hc.replace(
    "            source: p.sourceName.isEmpty\n"
    "                ? 'Health Connect'\n"
    "                : SourceNameService.friendly(p.sourceName),",
    "            source: originLabel(p),",
    1,
)
hc = hc.replace(
    "        source: p.sourceName.isEmpty\n"
    "            ? 'Health Connect'\n"
    "            : SourceNameService.friendly(p.sourceName),",
    "        source: originLabel(p),",
    1,
)

# Freshness must be metric-specific.
hc = replace_required(
    hc,
    "    addFresh('Heart rate', [...heart, ...resting]);\n"
    "    addFresh('Weight', weight);\n"
    "    addFresh('Body fat', bodyFat);\n"
    "    addFresh('Workouts', workoutPoints);",
    "    addFresh('Heart rate', heart);\n"
    "    addFresh('Resting heart rate', resting);\n"
    "    addFresh('HRV', hrv);\n"
    "    addFresh('Respiratory rate', respiratory);\n"
    "    addFresh('SpO2', oxygen);\n"
    "    addFresh('Weight', weight);\n"
    "    addFresh('Body fat', bodyFat);\n"
    "    addFresh('Body water', bodyWater);\n"
    "    addFresh('Lean body mass', leanBodyMass);\n"
    "    addFresh('Workouts', workoutPoints);",
    "freshness metrics",
)

# originsFor returns stable origin keys.
old_origins = """    List<String> originsFor(Iterable<HealthDataType> types) {
      final allowed = types.toSet();
      return SourceNameService.uniqueRawByFriendly(
        points
            .where((point) => allowed.contains(point.type))
            .map((point) => point.sourceName.trim())
            .where((source) => source.isNotEmpty),
      )..sort(
          (a, b) => SourceNameService.friendly(a)
              .compareTo(SourceNameService.friendly(b)),
        );
    }

    final availableSources = <String, List<String>>{
      'Steps': originsFor([HealthDataType.STEPS]),
      'Sleep': originsFor(sleepTypes),
      'Heart rate': originsFor([
        HealthDataType.HEART_RATE,
        HealthDataType.RESTING_HEART_RATE,
        HealthDataType.HEART_RATE_VARIABILITY_RMSSD,
        HealthDataType.RESPIRATORY_RATE,
        HealthDataType.BLOOD_OXYGEN,
      ]),
      'Weight': originsFor([HealthDataType.WEIGHT]),
      'Body fat': originsFor([HealthDataType.BODY_FAT_PERCENTAGE]),
      'Workouts': originsFor([HealthDataType.WORKOUT]),
    };
"""
new_origins = """    List<String> originsFor(Iterable<HealthDataType> types) {
      final allowed = types.toSet();
      final values = points
          .where((point) => allowed.contains(point.type))
          .map(originKey)
          .where((source) => source.isNotEmpty)
          .toSet()
          .toList();
      values.sort(
        (a, b) => (sourceLabels[a] ?? SourceNameService.friendly(a))
            .compareTo(sourceLabels[b] ?? SourceNameService.friendly(b)),
      );
      return values;
    }

    final availableSources = <String, List<String>>{
      'Steps': originsFor([HealthDataType.STEPS]),
      'Sleep': originsFor(sleepTypes),
      'Heart rate': originsFor([HealthDataType.HEART_RATE]),
      'Resting heart rate': originsFor([HealthDataType.RESTING_HEART_RATE]),
      'HRV': originsFor([HealthDataType.HEART_RATE_VARIABILITY_RMSSD]),
      'Respiratory rate': originsFor([HealthDataType.RESPIRATORY_RATE]),
      'SpO2': originsFor([HealthDataType.BLOOD_OXYGEN]),
      'Weight': originsFor([HealthDataType.WEIGHT]),
      'Body fat': originsFor([HealthDataType.BODY_FAT_PERCENTAGE]),
      'Body water': originsFor([HealthDataType.BODY_WATER_MASS]),
      'Lean body mass': originsFor([HealthDataType.LEAN_BODY_MASS]),
      'Workouts': originsFor([HealthDataType.WORKOUT]),
    };
"""
hc = replace_required(hc, old_origins, new_origins, "available sources")

# Return new values and provenance.
hc = replace_required(
    hc,
    "      bodyFatPercent: lastNumber(bodyFat),\n"
    "      bloodOxygenPercent: lastNumber(oxygen),",
    "      bodyFatPercent: lastNumber(bodyFat),\n"
    "      bodyWaterMassKg: lastNumber(bodyWater),\n"
    "      leanBodyMassKg: lastNumber(leanBodyMass),\n"
    "      bloodOxygenPercent: lastNumber(oxygen),",
    "snapshot body values",
)
hc = replace_required(
    hc,
    "      detectedSources: sources,\n"
    "      availableSources: availableSources,\n"
    "      freshness: freshness,",
    "      detectedSources: sources,\n"
    "      availableSources: availableSources,\n"
    "      sourceLabels: sourceLabels,\n"
    "      resolvedSources: resolvedSources,\n"
    "      sourceLastSeen: sourceLastSeen,\n"
    "      freshness: freshness,",
    "snapshot provenance",
)
write("lib/services/health_connect_service.dart", hc)

# ---- Merge source registry across refreshes -------------------------------
sync = read("lib/state/health_sync_provider.dart")
old_set = """    ref.read(appStateProvider.notifier).setHealthSnapshot(snapshot);
"""
new_set = """    Map<String, List<String>> mergeSourceLists(
      Map<String, List<String>> oldValues,
      Map<String, List<String>> newValues,
    ) {
      final result = <String, List<String>>{};
      for (final key in {...oldValues.keys, ...newValues.keys}) {
        final merged = <String>{
          ...?oldValues[key],
          ...?newValues[key],
        }.toList();
        result[key] = merged;
      }
      return result;
    }

    final previous = app.health;
    final lastSeen = <String, DateTime>{...previous.sourceLastSeen};
    for (final entry in snapshot.sourceLastSeen.entries) {
      final old = lastSeen[entry.key];
      if (old == null || entry.value.isAfter(old)) {
        lastSeen[entry.key] = entry.value;
      }
    }

    final merged = snapshot.copyWith(
      detectedSources: <String>{
        ...previous.detectedSources,
        ...snapshot.detectedSources,
      }.toList(),
      availableSources: mergeSourceLists(
        previous.availableSources,
        snapshot.availableSources,
      ),
      sourceLabels: {
        ...previous.sourceLabels,
        ...snapshot.sourceLabels,
      },
      sourceLastSeen: lastSeen,
    );
    ref.read(appStateProvider.notifier).setHealthSnapshot(merged);
"""
sync = replace_required(sync, old_set, new_set, "sync registry merge")
write("lib/state/health_sync_provider.dart", sync)

# ---- Foreground refresh every 5 minutes while app remains open ------------
home = read("lib/screens/home_shell.dart")
home = replace_required(
    home,
    "import 'package:flutter/material.dart';",
    "import 'dart:async';\n\nimport 'package:flutter/material.dart';",
    "home timer import",
)
home = replace_required(
    home,
    "  bool _autoSyncStarted = false;\n",
    "  bool _autoSyncStarted = false;\n"
    "  Timer? _foregroundSyncTimer;\n",
    "home timer field",
)
home = replace_required(
    home,
    "    WidgetsBinding.instance.addObserver(this);\n",
    "    WidgetsBinding.instance.addObserver(this);\n"
    "    _foregroundSyncTimer = Timer.periodic(const Duration(minutes: 5), (_) {\n"
    "      if (!mounted) return;\n"
    "      final app = ref.read(appStateProvider);\n"
    "      final sync = ref.read(healthSyncProvider);\n"
    "      if (app.health.authorized && !sync.isLoading) {\n"
    "        ref.read(healthSyncProvider.notifier).sync();\n"
    "      }\n"
    "    });\n",
    "home timer start",
)
home = replace_required(
    home,
    "    WidgetsBinding.instance.removeObserver(this);\n"
    "    super.dispose();",
    "    WidgetsBinding.instance.removeObserver(this);\n"
    "    _foregroundSyncTimer?.cancel();\n"
    "    super.dispose();",
    "home timer dispose",
)
write("lib/screens/home_shell.dart", home)

# ---- Sources screen: rescan on open, independent metrics, diagnostics -----
sources = read("lib/screens/sources_screen.dart")
sources = replace_required(
    sources,
    "class SourcesScreen extends ConsumerWidget {\n"
    "  const SourcesScreen({super.key});\n\n"
    "  static const metrics = [\n"
    "    'Steps',\n"
    "    'Sleep',\n"
    "    'Heart rate',\n"
    "    'Weight',\n"
    "    'Body fat',\n"
    "    'Workouts',\n"
    "  ];\n\n"
    "  @override\n"
    "  Widget build(BuildContext context, WidgetRef ref) {",
    "class SourcesScreen extends ConsumerStatefulWidget {\n"
    "  const SourcesScreen({super.key});\n\n"
    "  @override\n"
    "  ConsumerState<SourcesScreen> createState() => _SourcesScreenState();\n"
    "}\n\n"
    "class _SourcesScreenState extends ConsumerState<SourcesScreen> {\n"
    "  static const metrics = [\n"
    "    'Steps',\n"
    "    'Sleep',\n"
    "    'Heart rate',\n"
    "    'Resting heart rate',\n"
    "    'HRV',\n"
    "    'SpO2',\n"
    "    'Respiratory rate',\n"
    "    'Weight',\n"
    "    'Body fat',\n"
    "    'Body water',\n"
    "    'Lean body mass',\n"
    "    'Workouts',\n"
    "  ];\n\n"
    "  @override\n"
    "  void initState() {\n"
    "    super.initState();\n"
    "    WidgetsBinding.instance.addPostFrameCallback((_) {\n"
    "      if (!mounted) return;\n"
    "      final app = ref.read(appStateProvider);\n"
    "      final sync = ref.read(healthSyncProvider);\n"
    "      if (app.health.authorized && !sync.isLoading) {\n"
    "        ref.read(healthSyncProvider.notifier).sync();\n"
    "      }\n"
    "    });\n"
    "  }\n\n"
    "  @override\n"
    "  Widget build(BuildContext context) {",
    "sources stateful conversion",
)

sources = sources.replace(
    "'Healthy Me reads what is currently available in Health Connect. Refreshing here does not force a watch or another health app to sync first.'",
    "'Healthy Me rescans Health Connect when this page opens, when the app resumes, every few minutes while open, and when you tap Refresh. A device app still has to write its data into Health Connect first.'",
)
sources = sources.replace(
    "'One setting per metric. Healthy Me shows only readable app names and only sources that have actually supplied that type of data.'",
    "'One source per metric. Automatic uses the freshest provider that actually supplied that metric; Steps uses Health Connect’s aggregate result when Automatic is selected.'",
)

# Pass labels/resolved source into rows and chooser.
sources = replace_required(
    sources,
    "                    selectedRaw: app.metricSources[metrics[i]],\n"
    "                    sources: h.availableSources[metrics[i]] ?? const [],\n"
    "                    freshness: h.freshness[metrics[i]],",
    "                    selectedRaw: app.metricSources[metrics[i]],\n"
    "                    resolvedRaw: h.resolvedSources[metrics[i]],\n"
    "                    sources: h.availableSources[metrics[i]] ?? const [],\n"
    "                    sourceLabels: h.sourceLabels,\n"
    "                    freshness: h.freshness[metrics[i]],",
    "source row params",
)
sources = replace_required(
    sources,
    "                      selectedRaw: app.metricSources[metrics[i]],\n"
    "                      sources: h.availableSources[metrics[i]] ?? const [],\n"
    "                      authorized: h.authorized,",
    "                      selectedRaw: app.metricSources[metrics[i]],\n"
    "                      sources: h.availableSources[metrics[i]] ?? const [],\n"
    "                      sourceLabels: h.sourceLabels,\n"
    "                      authorized: h.authorized,",
    "chooser params",
)
sources = replace_required(
    sources,
    "    required List<String> sources,\n"
    "    required bool authorized,",
    "    required List<String> sources,\n"
    "    required Map<String, String> sourceLabels,\n"
    "    required bool authorized,",
    "chooser signature",
)
sources = sources.replace(
    "title: 'Health Connect recommended',\n"
    "                subtitle: 'Use Health Connect’s combined / priority result',",
    "title: 'Automatic',\n"
    "                subtitle: metric == 'Steps'\n"
    "                    ? 'Use Health Connect’s aggregate step result'\n"
    "                    : 'Use the freshest provider supplying this metric',",
)
sources = sources.replace(
    "title: SourceNameService.friendly(source),",
    "title: sourceLabels[source] ?? SourceNameService.friendly(source),",
)

# Add diagnostics after metric-source card.
diagnostics_anchor = """          ),
        ],
      ),
    );
  }

  Future<void> _chooseSource("""
diagnostics_block = """          ),
          if (h.detectedSources.isNotEmpty) ...[
            const SizedBox(height: 24),
            const HmSectionHeader(title: 'Detected providers'),
            const SizedBox(height: 6),
            const Text(
              'Providers are identified by their Health Connect data origin. This is diagnostic information so you can see what is actually supplying data.',
              style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 13,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 10),
            CommandCard(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 3),
              child: Column(
                children: [
                  for (var i = 0; i < h.detectedSources.length; i++) ...[
                    _ProviderRow(
                      sourceKey: h.detectedSources[i],
                      label: h.sourceLabels[h.detectedSources[i]] ??
                          SourceNameService.friendly(h.detectedSources[i]),
                      metrics: h.availableSources.entries
                          .where((entry) => entry.value.contains(h.detectedSources[i]))
                          .map((entry) => entry.key)
                          .toList(),
                      lastSeen: h.sourceLastSeen[h.detectedSources[i]],
                    ),
                    if (i != h.detectedSources.length - 1)
                      const Divider(height: 1),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _chooseSource("""
sources = replace_required(sources, diagnostics_anchor, diagnostics_block, "provider diagnostics")

# Metric row fields.
sources = replace_required(
    sources,
    "  final String? selectedRaw;\n"
    "  final List<String> sources;\n"
    "  final DateTime? freshness;",
    "  final String? selectedRaw;\n"
    "  final String? resolvedRaw;\n"
    "  final List<String> sources;\n"
    "  final Map<String, String> sourceLabels;\n"
    "  final DateTime? freshness;",
    "metric row fields",
)
sources = replace_required(
    sources,
    "    required this.selectedRaw,\n"
    "    required this.sources,\n"
    "    required this.freshness,",
    "    required this.selectedRaw,\n"
    "    required this.resolvedRaw,\n"
    "    required this.sources,\n"
    "    required this.sourceLabels,\n"
    "    required this.freshness,",
    "metric row ctor",
)
sources = replace_required(
    sources,
    "    final current = selectedRaw == null\n"
    "        ? 'Health Connect recommended'\n"
    "        : SourceNameService.friendly(selectedRaw!);",
    "    final resolvedLabel = resolvedRaw == null\n"
    "        ? null\n"
    "        : (sourceLabels[resolvedRaw!] ?? SourceNameService.friendly(resolvedRaw!));\n"
    "    final selectedLabel = selectedRaw == null\n"
    "        ? null\n"
    "        : (sourceLabels[selectedRaw!] ?? SourceNameService.friendly(selectedRaw!));\n"
    "    final current = selectedRaw == null\n"
    "        ? (resolvedLabel == null ? 'Automatic' : 'Automatic • $resolvedLabel')\n"
    "        : (resolvedRaw != null &&\n"
    "                !SourceNameService.sameProvider(selectedRaw!, resolvedRaw!))\n"
    "            ? '$selectedLabel selected • using $resolvedLabel'\n"
    "            : selectedLabel!;",
    "metric row current label",
)

# Source display and extra icons/colors.
sources = sources.replace(
    "'Heart rate' => Icons.favorite_rounded,\n"
    "        'Weight' =>",
    "'Heart rate' => Icons.favorite_rounded,\n"
    "        'Resting heart rate' => Icons.favorite_border_rounded,\n"
    "        'HRV' => Icons.insights_rounded,\n"
    "        'SpO2' => Icons.bloodtype_rounded,\n"
    "        'Respiratory rate' => Icons.air_rounded,\n"
    "        'Weight' =>",
)
sources = sources.replace(
    "'Body fat' => Icons.percent_rounded,\n"
    "        'Workouts' =>",
    "'Body fat' => Icons.percent_rounded,\n"
    "        'Body water' => Icons.water_drop_rounded,\n"
    "        'Lean body mass' => Icons.fitness_center_rounded,\n"
    "        'Workouts' =>",
)
sources = sources.replace(
    "'Heart rate' => AppTheme.rose,\n"
    "        'Weight' =>",
    "'Heart rate' => AppTheme.rose,\n"
    "        'Resting heart rate' => AppTheme.rose,\n"
    "        'HRV' => AppTheme.purple,\n"
    "        'SpO2' => AppTheme.blue,\n"
    "        'Respiratory rate' => AppTheme.cyan,\n"
    "        'Weight' =>",
)
sources = sources.replace(
    "'Body fat' => AppTheme.amber,\n"
    "        'Workouts' =>",
    "'Body fat' => AppTheme.amber,\n"
    "        'Body water' => AppTheme.blue,\n"
    "        'Lean body mass' => AppTheme.mint,\n"
    "        'Workouts' =>",
)

# Add provider row class before source choice.
provider_class = r"""
class _ProviderRow extends StatelessWidget {
  final String sourceKey;
  final String label;
  final List<String> metrics;
  final DateTime? lastSeen;

  const _ProviderRow({
    required this.sourceKey,
    required this.label,
    required this.metrics,
    required this.lastSeen,
  });

  @override
  Widget build(BuildContext context) {
    final metricText = metrics.isEmpty ? 'No current metric records' : metrics.join(' • ');
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const HmIconBadge(
            icon: Icons.sensors_rounded,
            color: AppTheme.cyan,
            size: 40,
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  metricText,
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12.2,
                    height: 1.3,
                  ),
                ),
                if (lastSeen != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    'Last record ${relativeAge(lastSeen)}',
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 12,
                    ),
                  ),
                ],
                const SizedBox(height: 2),
                Text(
                  sourceKey,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppTheme.textMuted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

"""
sources = replace_required(
    sources,
    "class _SourceChoice extends StatelessWidget {",
    provider_class + "class _SourceChoice extends StatelessWidget {",
    "provider class",
)
write("lib/screens/sources_screen.dart", sources)

# ---- Activity source should show actual resolved source -------------------
activity = read("lib/screens/activity_screen.dart")
activity = replace_required(
    activity,
    "    final selectedStepSource = app.metricSources['Steps'];\n"
    "    final stepSourceLabel = selectedStepSource == null || selectedStepSource == 'Auto'\n"
    "        ? 'Health Connect recommended'\n"
    "        : SourceNameService.friendly(selectedStepSource);",
    "    final stepSourceKey = health.resolvedSources['Steps'] ?? app.metricSources['Steps'];\n"
    "    final stepSourceLabel = stepSourceKey == null\n"
    "        ? 'Automatic'\n"
    "        : (health.sourceLabels[stepSourceKey] ??\n"
    "            SourceNameService.friendly(stepSourceKey));",
    "activity resolved source",
)
write("lib/screens/activity_screen.dart", activity)

# ---- Sleep page source -----------------------------------------------------
sleep = read("lib/screens/sleep_screen.dart")
sleep = replace_required(
    sleep,
    "import '../services/sleep_guidance_service.dart';",
    "import '../services/sleep_guidance_service.dart';\n"
    "import '../services/source_name_service.dart';",
    "sleep source import",
)
sleep = replace_required(
    sleep,
    "    final guidance = SleepGuidanceService.forAge(app.profile.age);\n",
    "    final guidance = SleepGuidanceService.forAge(app.profile.age);\n"
    "    final sleepSourceKey = h.resolvedSources['Sleep'];\n"
    "    final sleepSourceLabel = sleepSourceKey == null\n"
    "        ? 'No connected source'\n"
    "        : (h.sourceLabels[sleepSourceKey] ??\n"
    "            SourceNameService.friendly(sleepSourceKey));\n"
    "    final sleepFreshness = h.freshness['Sleep'];\n",
    "sleep source vars",
)
sleep = replace_required(
    sleep,
    "                    const SizedBox(height: 7),\n"
    "                    Text(\n"
    "                      'Target: ${guidance.label} based on your age',",
    "                    const SizedBox(height: 6),\n"
    "                    Text(\n"
    "                      'Source: $sleepSourceLabel',\n"
    "                      maxLines: 1,\n"
    "                      overflow: TextOverflow.ellipsis,\n"
    "                      style: const TextStyle(\n"
    "                        color: AppTheme.purple,\n"
    "                        fontSize: 12.5,\n"
    "                        fontWeight: FontWeight.w800,\n"
    "                      ),\n"
    "                    ),\n"
    "                    if (sleepFreshness != null) ...[\n"
    "                      const SizedBox(height: 2),\n"
    "                      Text(\n"
    "                        'Sleep data ${relativeAge(sleepFreshness)}',\n"
    "                        style: const TextStyle(\n"
    "                          color: AppTheme.textMuted,\n"
    "                          fontSize: 12,\n"
    "                        ),\n"
    "                      ),\n"
    "                    ],\n"
    "                    const SizedBox(height: 7),\n"
    "                    Text(\n"
    "                      'Target: ${guidance.label} based on your age',",
    "sleep source UI",
)
write("lib/screens/sleep_screen.dart", sleep)

# ---- Body page source + body water / lean mass ----------------------------
body = read("lib/screens/body_screen.dart")
body = replace_required(
    body,
    "import '../models/models.dart';",
    "import '../models/models.dart';\n"
    "import '../services/source_name_service.dart';",
    "body source import",
)

# Weight source text after weight change block, before divider.
weight_anchor = """                        if (change != null) ...[
                          const SizedBox(height: 5),
                          Text(
                            '${change >= 0 ? '+' : ''}${change.toStringAsFixed(1)} lb since first entry',
                            style: TextStyle(
                              color: change <= 0 ? AppTheme.mint : AppTheme.amber,
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
"""
weight_new = weight_anchor + """                        const SizedBox(height: 5),
                        Text(
                          app.health.weightLb == null
                              ? 'Source: Manual'
                              : 'Source: ${_sourceLabel(app, 'Weight')}',
                          style: const TextStyle(
                            color: AppTheme.cyan,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (app.health.freshness['Weight'] != null)
                          Text(
                            'Weight data ${relativeAge(app.health.freshness['Weight'])}',
                            style: const TextStyle(
                              color: AppTheme.textMuted,
                              fontSize: 12,
                            ),
                          ),
"""
body = replace_required(body, weight_anchor, weight_new, "body weight source UI")

# Composition telemetry adds provenance and extra body metrics.
body = replace_required(
    body,
    "              _dataLine(\n"
    "                'Weight type',\n"
    "                app.health.weightLb != null ? 'Measured' : 'Manual',\n"
    "              ),",
    "              _dataLine(\n"
    "                'Weight type',\n"
    "                app.health.weightLb != null ? 'Device reading' : 'Manual',\n"
    "              ),\n"
    "              _dataLine(\n"
    "                'Weight source',\n"
    "                app.health.weightLb != null ? _sourceLabel(app, 'Weight') : 'Manual',\n"
    "              ),",
    "composition weight provenance",
)
body = replace_required(
    body,
    "              _dataLine(\n"
    "                'Body fat type',\n"
    "                app.health.bodyFatPercent == null ? 'No measured reading' : 'Measured',\n"
    "              ),",
    "              _dataLine(\n"
    "                'Body fat type',\n"
    "                app.health.bodyFatPercent == null ? 'No device reading' : 'Device reading',\n"
    "              ),\n"
    "              if (app.health.bodyFatPercent != null)\n"
    "                _dataLine('Body fat source', _sourceLabel(app, 'Body fat')),\n"
    "              if (app.health.bodyWaterMassKg != null)\n"
    "                _dataLine(\n"
    "                  'Body water',\n"
    "                  _bodyWaterLabel(app),\n"
    "                ),\n"
    "              if (app.health.bodyWaterMassKg != null)\n"
    "                _dataLine('Body water source', _sourceLabel(app, 'Body water')),\n"
    "              if (app.health.leanBodyMassKg != null)\n"
    "                _dataLine(\n"
    "                  'Lean body mass',\n"
    "                  '${(app.health.leanBodyMassKg! * 2.2046226218).toStringAsFixed(1)} lb',\n"
    "                ),\n"
    "              if (app.health.leanBodyMassKg != null)\n"
    "                _dataLine('Lean mass source', _sourceLabel(app, 'Lean body mass')),",
    "composition body provenance",
)

# Body fat card source.
body = replace_required(
    body,
    "                      : 'Measured body-fat data read through Health Connect.',",
    "                      : 'Device body-fat reading from ${_sourceLabel(app, 'Body fat')}.',",
    "body fat source label",
)

# Add helpers before measurement grid.
helper_anchor = "  Widget _measurementGrid(BodyMeasurements m, {bool preview = false}) {"
helpers = r"""  String _sourceLabel(HealthyMeState app, String metric) {
    final key = app.health.resolvedSources[metric];
    if (key == null || key.isEmpty) return 'Connected source';
    return app.health.sourceLabels[key] ?? SourceNameService.friendly(key);
  }

  String _bodyWaterLabel(HealthyMeState app) {
    final kg = app.health.bodyWaterMassKg;
    if (kg == null) return '—';
    final pounds = kg * 2.2046226218;
    final weight = app.health.weightLb;
    final waterSource = app.health.resolvedSources['Body water'];
    final weightSource = app.health.resolvedSources['Weight'];
    if (weight != null &&
        weight > 0 &&
        waterSource != null &&
        weightSource != null &&
        SourceNameService.sameProvider(waterSource, weightSource)) {
      final percent = (pounds / weight * 100).clamp(0, 100);
      return '${percent.toStringAsFixed(1)}% • ${pounds.toStringAsFixed(1)} lb';
    }
    return '${pounds.toStringAsFixed(1)} lb';
  }

"""
body = replace_required(body, helper_anchor, helpers + helper_anchor, "body source helpers")
write("lib/screens/body_screen.dart", body)

# ---- Vitals page: each metric shows its own actual source -----------------
vitals = r"""import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/formatters.dart';
import '../../services/source_name_service.dart';
import '../../state/app_state.dart';
import 'health_shell.dart';

class HealthVitalsScreen extends ConsumerWidget {
  const HealthVitalsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final app = ref.watch(appStateProvider);
    final h = app.health;

    String sourceFor(String metric) {
      final key = h.resolvedSources[metric];
      if (key == null || key.isEmpty) return 'No connected source';
      return h.sourceLabels[key] ?? SourceNameService.friendly(key);
    }

    String detailFor(String metric) {
      final fresh = h.freshness[metric];
      final source = sourceFor(metric);
      return fresh == null ? source : '$source • ${relativeAge(fresh)}';
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
      children: [
        const Text(
          'Vitals',
          style: TextStyle(
            color: HealthPalette.textPrimary,
            fontSize: 28,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 5),
        const Text(
          'Each vital shows the provider that actually supplied that metric.',
          style: TextStyle(
            color: HealthPalette.textSecondary,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 18),
        _VitalRow(
          icon: Icons.favorite_rounded,
          label: 'Resting heart rate',
          value: h.restingHeartRate == null
              ? '—'
              : '${h.restingHeartRate!.round()} bpm',
          source: detailFor('Resting heart rate'),
        ),
        _VitalRow(
          icon: Icons.insights_rounded,
          label: 'Heart-rate variability',
          value: h.hrvMs == null ? '—' : '${h.hrvMs!.round()} ms',
          source: detailFor('HRV'),
        ),
        _VitalRow(
          icon: Icons.bloodtype_rounded,
          label: 'Blood oxygen',
          value: h.bloodOxygenPercent == null
              ? '—'
              : '${h.bloodOxygenPercent!.toStringAsFixed(1)}%',
          source: detailFor('SpO2'),
        ),
        _VitalRow(
          icon: Icons.air_rounded,
          label: 'Respiratory rate',
          value: h.respiratoryRate == null
              ? '—'
              : '${h.respiratoryRate!.toStringAsFixed(1)} /min',
          source: detailFor('Respiratory rate'),
        ),
        _VitalRow(
          icon: Icons.favorite_border_rounded,
          label: 'Latest heart rate',
          value: h.latestHeartRate == null
              ? '—'
              : '${h.latestHeartRate!.round()} bpm',
          source: detailFor('Heart rate'),
        ),
        const SizedBox(height: 8),
        const Text(
          'These are connected health signals, not diagnoses. Healthy Me uses trends and personal baselines where enough history exists.',
          style: TextStyle(
            color: HealthPalette.textMuted,
            fontSize: 12.5,
            height: 1.4,
          ),
        ),
      ],
    );
  }
}

class _VitalRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String source;

  const _VitalRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.source,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: HealthPalette.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: HealthPalette.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: HealthPalette.accent.withValues(alpha: 0.13),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: HealthPalette.accent, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: HealthPalette.textSecondary,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  source,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: HealthPalette.textMuted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            value,
            style: const TextStyle(
              color: HealthPalette.textPrimary,
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}
"""
write("lib/screens/health/health_vitals_screen.dart", vitals)

# ---- Android Health Connect permissions + beta label ----------------------
prep = read("scripts/prepare_android.sh")
prep = replace_required(
    prep,
    '    <uses-permission android:name="android.permission.health.READ_BODY_FAT" />\n',
    '    <uses-permission android:name="android.permission.health.READ_BODY_FAT" />\n'
    '    <uses-permission android:name="android.permission.health.READ_BODY_WATER_MASS" />\n'
    '    <uses-permission android:name="android.permission.health.READ_LEAN_BODY_MASS" />\n',
    "android body permissions",
)
prep = prep.replace(
    'android:label="Healthy Me Beta 0.3.5"',
    'android:label="Healthy Me Beta 0.8"',
)
prep = prep.replace(
    'Healthy Me Beta 0.3.5 Android identity + Health Connect configuration applied.',
    'Healthy Me Beta 0.8 Android identity + Health Connect configuration applied.',
)
write("scripts/prepare_android.sh", prep)

# ---- tests ----------------------------------------------------------------
source_test = read("test/source_name_service_test.dart")
insert_before = "\n}\n"
extra_tests = r"""
  test('recognizes QRing package id for display only', () {
    expect(SourceNameService.friendly('com.app.cq.ring'), 'QRing');
  });

  test('recognizes iMoni package id for display only', () {
    expect(SourceNameService.friendly('com.xs.imoni'), 'iMoni');
  });

  test('stable source key prefers sourceId over sourceName', () {
    expect(
      SourceNameService.key(
        sourceId: 'com.app.cq.ring',
        sourceName: 'QRing',
      ),
      'com.app.cq.ring',
    );
  });

  test('source matching accepts package id or display name', () {
    expect(
      SourceNameService.pointMatches(
        selected: 'QRing',
        sourceId: 'com.app.cq.ring',
        sourceName: 'QRing',
      ),
      isTrue,
    );
  });
"""
idx = source_test.rfind(insert_before)
if idx < 0:
    raise SystemExit("PATCH ERROR: source test closing brace not found")
source_test = source_test[:idx] + "\n" + extra_tests + source_test[idx:]
write("test/source_name_service_test.dart", source_test)


# ---- UI contract: source wording intentionally changed in v0.8 -------------
contract = read("scripts/ui_contract_check.sh")
contract = contract.replace(
    'for required in "Day" "Week" "Month" "Year" "Workouts" "Weekly activity" "Health Connect recommended"; do',
    'for required in "Day" "Week" "Month" "Year" "Workouts" "Weekly activity" "Automatic"; do',
)
contract = contract.replace(
    'grep -q "Health Connect recommended" "$SOURCES_FILE" || fail "source selection must have one clear Health Connect default"',
    'grep -q "Automatic" "$SOURCES_FILE" || fail "source selection must have one clear automatic default"',
)
write("scripts/ui_contract_check.sh", contract)

print("Healthy Me v0.8 health-source patch applied.")
